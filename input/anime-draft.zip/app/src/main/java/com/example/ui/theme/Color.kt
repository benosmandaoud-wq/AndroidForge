package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Anime Arena Palette (Obsidian, Amber Gold, Electric Cyan)
val ArenaObsidian = Color(0xFF090D16)
val ArenaSurface = Color(0xFF111827)
val ArenaSurfaceElevated = Color(0xFF1A2336)
val ArenaSurfaceHighest = Color(0xFF232F46)
val ArenaOutline = Color(0xFF334155)

val GoldPrimary = Color(0xFFF59E0B)
val GoldContainer = Color(0xFF452704)
val OnGoldContainer = Color(0xFFFDE68A)

val CyanSecondary = Color(0xFF22D3EE)
val CyanContainer = Color(0xFF083344)
val OnCyanContainer = Color(0xFFA5F3FC)

val CrimsonTertiary = Color(0xFFFB7185)
val CrimsonContainer = Color(0xFF4C0519)
val OnCrimsonContainer = Color(0xFFFECDD3)

val EmeraldWin = Color(0xFF34D399)
val VioletHax = Color(0xFFA78BFA)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)

// Light Theme Counterparts
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightOutline = Color(0xFFCBD5E1)
val GoldPrimaryLight = Color(0xFFD97706)
val CyanSecondaryLight = Color(0xFF0891B2)
val CrimsonTertiaryLight = Color(0xFFE11D48)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
