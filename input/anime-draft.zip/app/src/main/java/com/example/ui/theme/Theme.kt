package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val ArenaDarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = Color(0xFF1F1300),
    primaryContainer = GoldContainer,
    onPrimaryContainer = OnGoldContainer,
    secondary = CyanSecondary,
    onSecondary = Color(0xFF001F26),
    secondaryContainer = CyanContainer,
    onSecondaryContainer = OnCyanContainer,
    tertiary = CrimsonTertiary,
    onTertiary = Color(0xFF2B000D),
    tertiaryContainer = CrimsonContainer,
    onTertiaryContainer = OnCrimsonContainer,
    background = ArenaObsidian,
    onBackground = TextPrimaryDark,
    surface = ArenaSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = ArenaSurfaceElevated,
    onSurfaceVariant = TextSecondaryDark,
    surfaceContainerHigh = ArenaSurfaceElevated,
    surfaceContainerHighest = ArenaSurfaceHighest,
    outline = ArenaOutline,
    outlineVariant = Color(0xFF1E293B)
)

private val ArenaLightColorScheme = lightColorScheme(
    primary = GoldPrimaryLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFEF3C7),
    onPrimaryContainer = Color(0xFF451A03),
    secondary = CyanSecondaryLight,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFCFFAFE),
    onSecondaryContainer = Color(0xFF083344),
    tertiary = CrimsonTertiaryLight,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFE4E6),
    onTertiaryContainer = Color(0xFF4C0519),
    background = LightBackground,
    onBackground = TextPrimaryLight,
    surface = LightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    outline = LightOutline
)

val ArenaShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun AnimeDraftTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) ArenaDarkColorScheme else ArenaLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AnimeDraftTypography,
        shapes = ArenaShapes,
        content = content
    )
}
