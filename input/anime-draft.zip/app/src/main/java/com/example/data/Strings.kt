package com.example.data

import com.example.model.Language
import com.example.model.LocalizedText

object UiText {
    val appTitle = LocalizedText("ANIME DRAFT", "درافت الأنمي")
    val appSubtitle = LocalizedText("Two-Player Blind & Visible Draft Arena", "نظام الدرافت الثنائي السري والمكشوف")

    val navArena = LocalizedText("Arena", "الساحة")
    val navDraft = LocalizedText("Draft", "الدرافت")
    val navRoster = LocalizedText("Roster", "المقاتلون")
    val navHistory = LocalizedText("History", "السجل")
    val navSettings = LocalizedText("Settings", "الإعدادات")

    val startTwoPlayerDraft = LocalizedText("Start 2-Player Draft", "ابدأ درافت اللاعبين")
    val openDuelLab = LocalizedText("1v1 Duel Lab", "مختبر 1 ضد 1")
    val resumeDraft = LocalizedText("Continue Unfinished Draft", "متابعة الدرافت غير المكتمل")
    val howToPlay = LocalizedText("Draft Rules", "قواعد الدرافت")

    val player1Label = LocalizedText("Player 1 Name", "اسم اللاعب الأول")
    val player2Label = LocalizedText("Player 2 Name", "اسم اللاعب الثاني")
    val roundsAndTeamLabel = LocalizedText("Rounds & Team Size", "عدد الجولات وحجم الفريق")
    val customRoundsLabel = LocalizedText("Custom", "مخصص")
    val comparisonModeLabel = LocalizedText("Team Comparison Mode", "نظام مقارنة الفرق")
    val universeFocusLabel = LocalizedText("Select Anime Universes", "اختر عوالم الأنمي")
    val allUniverses = LocalizedText("All Universes", "كل العوالم")
    val searchPlaceholder = LocalizedText("Search character or move...", "ابحث عن شخصية أو تقنية...")

    val roundPrefix = LocalizedText("Round", "الجولة")
    val visibleCardBadge = LocalizedText("VISIBLE", "مكشوف")
    val hiddenCardBadge = LocalizedText("HIDDEN", "سري")
    val discardedBadge = LocalizedText("DISCARDED", "مُستبعد")
    val compareTeamsBtn = LocalizedText("Compare Teams", "مقارنة الفريقين")
    val restartDraftBtn = LocalizedText("Restart Draft", "إعادة الدرافت")
    val roundHistoryTitle = LocalizedText("Round History", "سجل الجولات")
    val draftCompleteTitle = LocalizedText("Draft Completed!", "اكتمل الدرافت!")

    val victory = LocalizedText("VICTORY", "انتصار")
    val draw = LocalizedText("DRAW", "تعادل")
    val mvpLabel = LocalizedText("Arena MVP", "أفضل مقاتل")
    val tabOverview = LocalizedText("Overview", "نظرة عامة")
    val tabDuels = LocalizedText("Slot Duels", "المواجهات")
    val tabSynergies = LocalizedText("Synergies", "التناغم")
    val rematch = LocalizedText("Rematch", "إعادة المواجهة")
    val newDraft = LocalizedText("New Draft", "درافت جديد")

    val encyclopediaTab = LocalizedText("Encyclopedia", "الموسوعة")
    val duelLabTab = LocalizedText("1v1 Duel Lab", "مبارزة 1 ضد 1")
    val selectFighterA = LocalizedText("Fighter A", "المقاتل الأول")
    val selectFighterB = LocalizedText("Fighter B", "المقاتل الثاني")

    val emptyHistoryTitle = LocalizedText("No Completed Drafts Yet", "لا توجد نتائج مكتملة بعد")
    val emptyHistoryHint = LocalizedText(
        "Complete a 2-player draft to review saved teams and compare them anytime.",
        "أكمل درافت ثنائي لحفظ الفرق ومقارنتها في أي وقت."
    )
    val clearHistory = LocalizedText("Clear All", "مسح السجل")

    val languageTitle = LocalizedText("Language", "اللغة")
    val themeTitle = LocalizedText("Appearance", "المظهر")
    val darkModeLabel = LocalizedText("Obsidian Arena (Dark)", "ساحة الأوبسيديان (داكن)")
    val lightModeLabel = LocalizedText("Daylight Colosseum (Light)", "ساحة النهار (فاتح)")
    val portraitCacheTitle = LocalizedText("Character Portrait Cache", "ذاكرة صور الشخصيات")
    val clearCacheBtn = LocalizedText("Clear Portrait Cache", "مسح ذاكرة الصور")

    val statOffense = LocalizedText("Offense", "الهجوم")
    val statDefense = LocalizedText("Defense", "الدفاع")
    val statSpeed = LocalizedText("Speed", "السرعة")
    val statIntel = LocalizedText("Tactical IQ", "الذكاء")
    val statVersatility = LocalizedText("Versatility", "التنوع")
    val statAura = LocalizedText("Aura", "الهالة")
}
