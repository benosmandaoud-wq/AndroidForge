package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.data.UiText
import com.example.model.Character
import com.example.model.Language
import com.example.model.PowerCategory
import com.example.model.TeamDimensionKey
import com.example.model.TeamDimensionScores
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.VioletHax
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CharacterPortrait(
    character: Character,
    portraitUrl: String?,
    onRequestPortrait: (Character) -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 56.dp,
    borderColor: Color = character.universe.accentColor
) {
    LaunchedEffect(character.id, portraitUrl.isNullOrBlank()) {
        if (portraitUrl.isNullOrBlank()) {
            onRequestPortrait(character)
        }
    }

    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(
                        character.universe.accentColor.copy(alpha = 0.28f),
                        MaterialTheme.colorScheme.surfaceContainerHighest
                    )
                )
            )
            .border(1.5.dp, borderColor.copy(alpha = 0.75f), shape),
        contentAlignment = Alignment.Center
    ) {
        if (!portraitUrl.isNullOrBlank()) {
            SubcomposeAsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(portraitUrl)
                    .crossfade(250)
                    .build(),
                contentDescription = character.name.en,
                contentScale = ContentScale.Crop,
                alignment = Alignment.TopCenter,
                modifier = Modifier.fillMaxSize(),
                loading = {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        PortraitInitialCrest(character)
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp).align(Alignment.BottomEnd).padding(3.dp),
                            strokeWidth = 1.5.dp,
                            color = character.universe.accentColor
                        )
                    }
                },
                error = { PortraitInitialCrest(character) }
            )
        } else {
            PortraitInitialCrest(character)
        }
    }
}

@Composable
private fun PortraitInitialCrest(character: Character) {
    val initials = character.name.en
        .split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercase() }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = initials,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = character.universe.accentColor
        )
        Text(
            text = character.universe.shortCode,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun TierBadge(tier: String, modifier: Modifier = Modifier) {
    val bgColor = when (tier) {
        "S+" -> GoldPrimary.copy(alpha = 0.2f)
        "S" -> CyanSecondary.copy(alpha = 0.18f)
        else -> VioletHax.copy(alpha = 0.18f)
    }
    val textColor = when (tier) {
        "S+" -> GoldPrimary
        "S" -> CyanSecondary
        else -> VioletHax
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(6.dp),
        color = bgColor,
        border = BorderStroke(1.dp, textColor.copy(alpha = 0.55f))
    ) {
        Text(
            text = tier,
            style = MaterialTheme.typography.labelMedium,
            color = textColor,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun PowerCategoryPill(
    category: PowerCategory,
    language: Language,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(6.dp),
        color = category.color.copy(alpha = 0.14f)
    ) {
        Text(
            text = category.label.get(language),
            style = MaterialTheme.typography.labelSmall,
            color = category.color,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun StatBarRow(
    label: String,
    value: Int,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    val animatedFraction by animateFloatAsState(
        targetValue = (value / 100f).coerceIn(0f, 1f),
        animationSpec = spring(dampingRatio = 0.75f),
        label = "stat_bar"
    )
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(88.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Box(
            modifier = Modifier
                .weight(1f)
                .height(8.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceContainerHighest)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(animatedFraction)
                    .height(8.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.horizontalGradient(
                            listOf(accentColor.copy(alpha = 0.7f), accentColor)
                        )
                    )
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = value.toString(),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.width(26.dp)
        )
    }
}

@Composable
fun TeamRadarChart(
    p1Dimensions: TeamDimensionScores,
    p2Dimensions: TeamDimensionScores,
    language: Language,
    modifier: Modifier = Modifier
) {
    val keys = TeamDimensionKey.entries
    val outlineColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
    val goldColor = GoldPrimary
    val cyanColor = CyanSecondary

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(230.dp)
                .padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val maxRadius = (minOf(size.width, size.height) / 2f) * 0.86f
                val stepAngle = (2.0 * PI) / keys.size

                // Web rings
                listOf(0.33f, 0.66f, 1.0f).forEach { ring ->
                    val ringPath = Path()
                    keys.forEachIndexed { idx, _ ->
                        val angle = -PI / 2.0 + idx * stepAngle
                        val r = maxRadius * ring
                        val pt = Offset(
                            center.x + (r * cos(angle)).toFloat(),
                            center.y + (r * sin(angle)).toFloat()
                        )
                        if (idx == 0) ringPath.moveTo(pt.x, pt.y) else ringPath.lineTo(pt.x, pt.y)
                    }
                    ringPath.close()
                    drawPath(ringPath, color = outlineColor, style = Stroke(width = 1.5f))
                }

                // Spokes
                keys.forEachIndexed { idx, _ ->
                    val angle = -PI / 2.0 + idx * stepAngle
                    val end = Offset(
                        center.x + (maxRadius * cos(angle)).toFloat(),
                        center.y + (maxRadius * sin(angle)).toFloat()
                    )
                    drawLine(outlineColor, center, end, strokeWidth = 1.5f)
                }

                // Team 1 Polygon
                val p1Path = Path()
                keys.forEachIndexed { idx, key ->
                    val angle = -PI / 2.0 + idx * stepAngle
                    val ratio = (p1Dimensions.valueFor(key) / 100f).coerceIn(0.1f, 1f)
                    val pt = Offset(
                        center.x + (maxRadius * ratio * cos(angle)).toFloat(),
                        center.y + (maxRadius * ratio * sin(angle)).toFloat()
                    )
                    if (idx == 0) p1Path.moveTo(pt.x, pt.y) else p1Path.lineTo(pt.x, pt.y)
                }
                p1Path.close()
                drawPath(p1Path, color = goldColor.copy(alpha = 0.25f))
                drawPath(p1Path, color = goldColor, style = Stroke(width = 3f, cap = StrokeCap.Round))

                // Team 2 Polygon
                val p2Path = Path()
                keys.forEachIndexed { idx, key ->
                    val angle = -PI / 2.0 + idx * stepAngle
                    val ratio = (p2Dimensions.valueFor(key) / 100f).coerceIn(0.1f, 1f)
                    val pt = Offset(
                        center.x + (maxRadius * ratio * cos(angle)).toFloat(),
                        center.y + (maxRadius * ratio * sin(angle)).toFloat()
                    )
                    if (idx == 0) p2Path.moveTo(pt.x, pt.y) else p2Path.lineTo(pt.x, pt.y)
                }
                p2Path.close()
                drawPath(p2Path, color = cyanColor.copy(alpha = 0.22f))
                drawPath(p2Path, color = cyanColor, style = Stroke(width = 3f, cap = StrokeCap.Round))
            }
        }

        // Dimension Legend Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            keys.forEach { key ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = key.shortLabel.get(language),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${p1Dimensions.valueFor(key)}/${p2Dimensions.valueFor(key)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun CharacterDetailDialog(
    character: Character,
    portraitUrl: String?,
    onRequestPortrait: (Character) -> Unit,
    language: Language,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (language == Language.AR) "إغلاق" else "Close")
            }
        },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CharacterPortrait(
                    character = character,
                    portraitUrl = portraitUrl,
                    onRequestPortrait = onRequestPortrait,
                    size = 56.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = character.name.get(language),
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 2
                    )
                    Text(
                        text = "${character.universe.title.get(language)} • ${character.type.label.get(language)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = character.universe.accentColor
                    )
                }
                TierBadge(tier = character.tier)
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PowerCategoryPill(category = character.powerCategory, language = language)
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHighest
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Star,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "OVR ${character.stats.overall}",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Bolt,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = character.signatureMove.get(language),
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = character.tacticalTrait.get(language),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                StatBarRow(UiText.statOffense.get(language), character.stats.offense, GoldPrimary)
                StatBarRow(UiText.statDefense.get(language), character.stats.defense, CyanSecondary)
                StatBarRow(UiText.statSpeed.get(language), character.stats.speed, character.universe.accentColor)
                StatBarRow(UiText.statIntel.get(language), character.stats.intelligence, VioletHax)
                StatBarRow(UiText.statVersatility.get(language), character.stats.versatility, GoldPrimary)
                StatBarRow(UiText.statAura.get(language), character.stats.aura, CyanSecondary)
            }
        }
    )
}

@Composable
fun HowToPlayDialog(
    language: Language,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (language == Language.AR) "فهمت" else "Got It")
            }
        },
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Shield,
                        contentDescription = null,
                        tint = GoldPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(UiText.howToPlay.get(language), style = MaterialTheme.typography.titleLarge)
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                RuleCard(
                    title = if (language == Language.AR) "1. ثلاث بطاقات في كل جولة" else "1. Three Cards Every Round",
                    body = if (language == Language.AR) {
                        "تظهر في كل جولة 3 شخصيات فريدة: بطاقة واحدة مكشوفة وبطاقتان مخفيتان بعلامة استفهام (؟)."
                    } else {
                        "Each round offers 3 unique fighters: 1 Visible card and 2 Hidden mystery (?) cards."
                    }
                )
                RuleCard(
                    title = if (language == Language.AR) "2. القاعدة أ: اختيار البطاقة المكشوفة" else "2. Rule A: Pick the Visible Card",
                    body = if (language == Language.AR) {
                        "إذا اختار اللاعب المبتدئ البطاقة المكشوفة، يحصل عليها، ويختار الخصم إحدى البطاقتين المخفيتين وتُستبعد الثالثة."
                    } else {
                        "Active player claims the Visible character. Opponent then picks one of the 2 Hidden cards, and the remaining card is discarded."
                    }
                )
                RuleCard(
                    title = if (language == Language.AR) "3. القاعدة ب: اختيار بطاقة مخفية" else "3. Rule B: Pick a Hidden Card",
                    body = if (language == Language.AR) {
                        "إذا اختار اللاعب المبتدئ بطاقة مخفية، يحصل عليها، ويحصل الخصم تلقائياً على البطاقة المكشوفة، وتُستبعد المخفية الأخرى."
                    } else {
                        "Active player receives the chosen Hidden card, the opponent automatically receives the Visible card, and the other Hidden card is discarded."
                    }
                )
                RuleCard(
                    title = if (language == Language.AR) "4. تناوب البداية" else "4. Alternating Turns",
                    body = if (language == Language.AR) {
                        "يبدأ داود الجولة الأولى ومنصف الجولة الثانية ويتناوبان كل جولة. كل جولة تمنح شخصية لكل لاعب."
                    } else {
                        "Player 1 starts Round 1, Player 2 starts Round 2, alternating every round. Each round adds 1 character to each team."
                    }
                )
            }
        }
    )
}

@Composable
private fun RuleCard(title: String, body: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHighest
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = GoldPrimary)
            Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
