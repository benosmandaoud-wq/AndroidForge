package com.example.model

import androidx.compose.ui.graphics.Color
import kotlinx.serialization.Serializable

@Serializable
enum class Language(val code: String, val label: String) {
    EN("en", "English"),
    AR("ar", "العربية")
}

@Serializable
data class LocalizedText(
    val en: String,
    val ar: String
) {
    fun get(lang: Language): String = if (lang == Language.AR) ar else en
}

@Serializable
enum class AnimeUniverse(
    val title: LocalizedText,
    val shortCode: String,
    val accentHex: Long,
    val synergyName: LocalizedText
) {
    NARUTO(
        title = LocalizedText("Naruto", "ناروتو"),
        shortCode = "NR",
        accentHex = 0xFFF97316,
        synergyName = LocalizedText("Shinobi Alliance", "تحالف الشينوبي")
    ),
    ONE_PIECE(
        title = LocalizedText("One Piece", "ون بيس"),
        shortCode = "OP",
        accentHex = 0xFFEF4444,
        synergyName = LocalizedText("Grand Line Crew", "طاقم الجراند لاين")
    ),
    BLEACH(
        title = LocalizedText("Bleach", "بليتش"),
        shortCode = "BL",
        accentHex = 0xFF38BDF8,
        synergyName = LocalizedText("Soul Society Captains", "قادة مجتمع الأرواح")
    ),
    DRAGON_BALL(
        title = LocalizedText("Dragon Ball", "دراغون بول"),
        shortCode = "DB",
        accentHex = 0xFFFACC15,
        synergyName = LocalizedText("Z-Fighter Resonance", "تناغم مقاتلي Z")
    ),
    JUJUTSU_KAISEN(
        title = LocalizedText("Jujutsu Kaisen", "جوجوتسو كايسن"),
        shortCode = "JJK",
        accentHex = 0xFFA855F7,
        synergyName = LocalizedText("Domain Convergence", "تقاطع المجالات")
    ),
    DEMON_SLAYER(
        title = LocalizedText("Demon Slayer", "قاتل الشياطين"),
        shortCode = "DS",
        accentHex = 0xFF10B981,
        synergyName = LocalizedText("Hashira Breathing", "تنفس الهاشيرا")
    ),
    ATTACK_ON_TITAN(
        title = LocalizedText("Attack on Titan", "هجوم العمالقة"),
        shortCode = "AOT",
        accentHex = 0xFF84CC16,
        synergyName = LocalizedText("Survey Corps Formation", "تشكيل فيلق الاستطلاع")
    ),
    HUNTER_X_HUNTER(
        title = LocalizedText("Hunter x Hunter", "هنتر x هنتر"),
        shortCode = "HXH",
        accentHex = 0xFF14B8A6,
        synergyName = LocalizedText("Nen Mastery Pact", "عهد إتقان النين")
    ),
    SOLO_LEVELING(
        title = LocalizedText("Solo Leveling", "سولو ليفلينج"),
        shortCode = "SL",
        accentHex = 0xFF6366F1,
        synergyName = LocalizedText("Shadow Monarch Legion", "فيلق ملك الظلال")
    );

    val accentColor: Color get() = Color(accentHex)
}

@Serializable
enum class CharacterType(val label: LocalizedText) {
    STRIKER(LocalizedText("Striker", "مهاجم")),
    STRATEGIST(LocalizedText("Strategist", "استراتيجي")),
    TANK(LocalizedText("Vanguard", "مدافع")),
    ASSASSIN(LocalizedText("Assassin", "مغتال")),
    SUPPORT(LocalizedText("Support", "داعم")),
    ALL_ROUNDER(LocalizedText("All-Rounder", "شامل"))
}

@Serializable
enum class PowerCategory(val label: LocalizedText, val accentHex: Long) {
    PHYSICAL(LocalizedText("Physical", "جسدي"), 0xFFF97316),
    ENERGY(LocalizedText("Energy", "طاقة"), 0xFF22D3EE),
    ELEMENTAL(LocalizedText("Elemental", "عناصر"), 0xFF34D399),
    HAX(LocalizedText("Hax / Conceptual", "قدرات خاصة"), 0xFFA78BFA),
    SPIRITUAL(LocalizedText("Spiritual", "روحي"), 0xFFF43F5E);

    val color: Color get() = Color(accentHex)
}

@Serializable
data class CharacterStats(
    val offense: Int,
    val defense: Int,
    val speed: Int,
    val intelligence: Int,
    val versatility: Int,
    val aura: Int
) {
    val overall: Int
        get() = ((offense + defense + speed + intelligence + versatility + aura) / 6.0).toInt()
}

@Serializable
data class Character(
    val id: String,
    val name: LocalizedText,
    val universe: AnimeUniverse,
    val type: CharacterType,
    val powerCategory: PowerCategory,
    val tier: String,
    val stats: CharacterStats,
    val signatureMove: LocalizedText,
    val tacticalTrait: LocalizedText,
    val malQuery: String,
    val portraitUrl: String? = null
)

@Serializable
enum class DraftDifficulty(val label: LocalizedText, val description: LocalizedText) {
    CASUAL(
        LocalizedText("Casual", "عادي"),
        LocalizedText("Relaxed AI drafting with balanced picks", "اختيارات عشوائية متوازنة للذكاء الاصطناعي")
    ),
    TACTICAL(
        LocalizedText("Tactical", "تكتيكي"),
        LocalizedText("AI builds universe synergies & role balance", "يبني الذكاء الاصطناعي تناغم العوالم والأدوار")
    ),
    GRANDMASTER(
        LocalizedText("Grandmaster", "أستاذ كبير"),
        LocalizedText("Counter-picks your roster & exploits weaknesses", "يختار مضادات لفريقك ويستغل نقاط الضعف")
    )
}

@Serializable
enum class ComparisonMode(val label: LocalizedText, val description: LocalizedText) {
    BALANCED(
        LocalizedText("Balanced Clash", "صراع متوازن"),
        LocalizedText("Equal weight across power, tactics, and synergy", "وزن متساوٍ للقوة والتكتيك والتناغم")
    ),
    POWER_CLASH(
        LocalizedText("Raw Power", "القوة المطلقة"),
        LocalizedText("Favors offense, aura, and S-tier firepower", "يفضل الهجوم والهالة والقوة التدميرية")
    ),
    TACTICAL_SYNERGY(
        LocalizedText("Tactical IQ", "الذكاء التكتيكي"),
        LocalizedText("Rewards intelligence, versatility, and team synergy", "يكافئ الذكاء والتنوع وتناغم الفريق")
    ),
    SPEED_BLITZ(
        LocalizedText("Speed Blitz", "حرب السرعة"),
        LocalizedText("Speed and first-strike initiative dominate", "تسيطر السرعة والمبادرة الأولى")
    )
}

@Serializable
enum class DraftMode(val label: LocalizedText) {
    VS_AI(LocalizedText("VS AI", "ضد الذكاء الاصطناعي")),
    LOCAL_2P(LocalizedText("2P Pass & Play", "لاعبان محلياً"))
}

@Serializable
enum class PlayerKey(val label: LocalizedText) {
    PLAYER_1(LocalizedText("Team Gold", "الفريق الذهبي")),
    PLAYER_2(LocalizedText("Team Cyan", "الفريق السماوي"))
}

@Serializable
enum class TeamDimensionKey(val label: LocalizedText, val shortLabel: LocalizedText) {
    FIREPOWER(LocalizedText("Firepower", "القوة الهجومية"), LocalizedText("ATK", "هجوم")),
    DURABILITY(LocalizedText("Durability", "التحمل"), LocalizedText("DEF", "دفاع")),
    SPEED(LocalizedText("Speed", "السرعة"), LocalizedText("SPD", "سرعة")),
    TACTICS(LocalizedText("Tactics", "التكتيك"), LocalizedText("TAC", "تكتيك")),
    SYNERGY(LocalizedText("Synergy", "التناغم"), LocalizedText("SYN", "تناغم")),
    CLUTCH(LocalizedText("Clutch Aura", "الهالة الحاسمة"), LocalizedText("AUR", "هالة"))
}

@Serializable
data class TeamDimensionScores(
    val firepower: Int,
    val durability: Int,
    val speed: Int,
    val tactics: Int,
    val synergy: Int,
    val clutch: Int
) {
    fun valueFor(key: TeamDimensionKey): Int = when (key) {
        TeamDimensionKey.FIREPOWER -> firepower
        TeamDimensionKey.DURABILITY -> durability
        TeamDimensionKey.SPEED -> speed
        TeamDimensionKey.TACTICS -> tactics
        TeamDimensionKey.SYNERGY -> synergy
        TeamDimensionKey.CLUTCH -> clutch
    }

    val totalScore: Int
        get() = ((firepower * 1.15) + durability + speed + tactics + (synergy * 1.1) + clutch).toInt()
}

@Serializable
data class MatchupAnalysis(
    val slotIndex: Int,
    val player1Character: Character,
    val player2Character: Character,
    val p1DuelScore: Int,
    val p2DuelScore: Int,
    val winner: PlayerKey?,
    val categoryEdge: PlayerKey?,
    val summary: LocalizedText
)

@Serializable
data class SynergyBonus(
    val title: LocalizedText,
    val description: LocalizedText,
    val bonusPoints: Int
)

@Serializable
data class FinalBattleReport(
    val winner: PlayerKey?,
    val p1TotalScore: Int,
    val p2TotalScore: Int,
    val p1Dimensions: TeamDimensionScores,
    val p2Dimensions: TeamDimensionScores,
    val p1Synergies: List<SynergyBonus>,
    val p2Synergies: List<SynergyBonus>,
    val matchups: List<MatchupAnalysis>,
    val mvpCharacter: Character,
    val mvpOwner: PlayerKey,
    val verdictSummary: LocalizedText,
    val p1WinPercent: Int = 50,
    val p2WinPercent: Int = 50
)

@Serializable
enum class RoundPhase {
    PICK_INITIAL,
    OPPONENT_PICK_HIDDEN,
    ROUND_REVEAL
}

@Serializable
data class DraftCardSlot(
    val slotIndex: Int,
    val character: Character,
    val isVisibleInitial: Boolean,
    val isRevealed: Boolean = isVisibleInitial,
    val claimedBy: PlayerKey? = null,
    val isDiscarded: Boolean = false
)

@Serializable
data class RoundHistoryEntry(
    val roundNumber: Int,
    val startingPlayer: PlayerKey,
    val offeredCharacters: List<Character>,
    val player1Pick: Character,
    val player2Pick: Character,
    val discardedCharacter: Character,
    val ruleApplied: String
)

@Serializable
data class DraftState(
    val draftId: String,
    val player1Name: String = "Daoud",
    val player2Name: String = "Monsef",
    val selectedUniverses: List<AnimeUniverse> = AnimeUniverse.entries,
    val totalRounds: Int = 5,
    val comparisonMode: ComparisonMode = ComparisonMode.BALANCED,
    val remainingPool: List<Character> = emptyList(),
    val team1: List<Character> = emptyList(),
    val team2: List<Character> = emptyList(),
    val currentRound: Int = 1,
    val startingPlayer: PlayerKey = PlayerKey.PLAYER_1,
    val activePlayer: PlayerKey = PlayerKey.PLAYER_1,
    val phase: RoundPhase = RoundPhase.PICK_INITIAL,
    val currentCards: List<DraftCardSlot> = emptyList(),
    val history: List<RoundHistoryEntry> = emptyList(),
    val isComplete: Boolean = false,
    // Kept for comparison report compatibility
    val mode: DraftMode = DraftMode.LOCAL_2P,
    val difficulty: DraftDifficulty = DraftDifficulty.TACTICAL,
    val teamSize: Int = totalRounds
)

@Serializable
data class GameSettings(
    val language: Language = Language.EN,
    val defaultDifficulty: DraftDifficulty = DraftDifficulty.TACTICAL,
    val defaultComparisonMode: ComparisonMode = ComparisonMode.BALANCED,
    val defaultTeamSize: Int = 5,
    val darkTheme: Boolean = true,
    val player1Name: String = "Daoud",
    val player2Name: String = "Monsef"
)

@Serializable
data class SavedDraftRecord(
    val id: String,
    val timestampMillis: Long,
    val mode: DraftMode,
    val difficulty: DraftDifficulty,
    val comparisonMode: ComparisonMode,
    val teamSize: Int,
    val team1: List<Character>,
    val team2: List<Character>,
    val report: FinalBattleReport,
    val player1Name: String = "Daoud",
    val player2Name: String = "Monsef",
    val draftHistory: List<RoundHistoryEntry> = emptyList()
)
