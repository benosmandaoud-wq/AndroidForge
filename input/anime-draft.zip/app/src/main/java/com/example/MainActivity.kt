package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.UiText
import com.example.model.Language
import com.example.model.LocalizedText
import com.example.ui.screens.BattleReportScreen
import com.example.ui.screens.DraftScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.RosterScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AnimeDraftTheme
import com.example.ui.viewmodel.ArenaViewModel
import kotlinx.serialization.Serializable

@Serializable data object RouteHome
@Serializable data object RouteDraft
@Serializable data object RouteReport
@Serializable data class RouteRoster(val initialTab: Int = 0)
@Serializable data object RouteHistory
@Serializable data object RouteSettings

private data class TopDestination(
    val route: Any,
    val label: LocalizedText,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: ArenaViewModel = viewModel(
                factory = ArenaViewModel.Factory(application)
            )
            val settings by viewModel.settings.collectAsStateWithLifecycle()

            val layoutDirection = if (settings.language == Language.AR) {
                LayoutDirection.Rtl
            } else {
                LayoutDirection.Ltr
            }

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                AnimeDraftTheme(darkTheme = settings.darkTheme) {
                    AnimeDraftApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun AnimeDraftApp(viewModel: ArenaViewModel) {
    val navController = rememberNavController()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val activeDraft by viewModel.activeDraft.collectAsStateWithLifecycle()
    val savedDrafts by viewModel.savedDrafts.collectAsStateWithLifecycle()
    val activeReport by viewModel.activeReportRecord.collectAsStateWithLifecycle()
    val portraitUrls by viewModel.portraitUrls.collectAsStateWithLifecycle()
    val duelLab by viewModel.duelLab.collectAsStateWithLifecycle()

    val lang = settings.language
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = backStackEntry?.destination

    val topDestinations = listOf(
        TopDestination(RouteHome, UiText.navArena, Icons.Filled.Home, Icons.Outlined.Home),
        TopDestination(RouteDraft, UiText.navDraft, Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome),
        TopDestination(RouteRoster(0), UiText.navRoster, Icons.Filled.Groups, Icons.Outlined.Groups),
        TopDestination(RouteHistory, UiText.navHistory, Icons.Filled.History, Icons.Outlined.History),
        TopDestination(RouteSettings, UiText.navSettings, Icons.Filled.Settings, Icons.Outlined.Settings)
    )

    fun navigateTopLevel(route: Any) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                if (!useNavRail) {
                    NavigationBar {
                        topDestinations.forEach { dest ->
                            val selected = when (dest.route) {
                                is RouteRoster -> currentDest?.hasRoute<RouteRoster>() == true
                                else -> currentDest?.hasRoute(dest.route::class) == true
                            }
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopLevel(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label.get(lang)
                                    )
                                },
                                label = {
                                    Text(
                                        text = dest.label.get(lang),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavRail) {
                    NavigationRail {
                        topDestinations.forEach { dest ->
                            val selected = when (dest.route) {
                                is RouteRoster -> currentDest?.hasRoute<RouteRoster>() == true
                                else -> currentDest?.hasRoute(dest.route::class) == true
                            }
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopLevel(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label.get(lang)
                                    )
                                },
                                label = {
                                    Text(
                                        text = dest.label.get(lang),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = RouteHome,
                    modifier = Modifier.weight(1f)
                ) {
                    composable<RouteHome> {
                        HomeScreen(
                            settings = settings,
                            activeDraft = activeDraft,
                            recentDraft = savedDrafts.firstOrNull(),
                            onStartDraft = { p1, p2, universes, rounds, compMode ->
                                viewModel.startNewDraft(p1, p2, universes, rounds, compMode)
                                navigateTopLevel(RouteDraft)
                            },
                            onResumeDraft = { navigateTopLevel(RouteDraft) },
                            onOpenDuelLab = {
                                navController.navigate(RouteRoster(initialTab = 1)) {
                                    launchSingleTop = true
                                }
                            },
                            onOpenReport = { record ->
                                viewModel.openSavedReport(record)
                                navController.navigate(RouteReport)
                            }
                        )
                    }

                    composable<RouteDraft> {
                        DraftScreen(
                            draftState = activeDraft,
                            language = lang,
                            portraitUrls = portraitUrls,
                            onRequestPortrait = { viewModel.ensurePortraitResolved(it) },
                            onSelectCard = { viewModel.selectDraftCard(it) },
                            onAdvanceRound = { viewModel.advanceNow() },
                            onRestartDraft = { viewModel.restartCurrentDraft() },
                            onCompareTeams = {
                                val report = viewModel.openComparisonForCompletedDraft()
                                if (report != null) {
                                    navController.navigate(RouteReport)
                                }
                            },
                            onStartDefaultDraft = { viewModel.startNewDraft() }
                        )
                    }

                    composable<RouteReport> {
                        val record = activeReport
                        if (record != null) {
                            BattleReportScreen(
                                record = record,
                                language = lang,
                                portraitUrls = portraitUrls,
                                onRequestPortrait = { viewModel.ensurePortraitResolved(it) },
                                onRematch = {
                                    viewModel.restartCurrentDraft()
                                    navController.popBackStack()
                                    navigateTopLevel(RouteDraft)
                                },
                                onNewDraft = {
                                    navController.popBackStack()
                                    navigateTopLevel(RouteHome)
                                }
                            )
                        }
                    }

                    composable<RouteRoster> { entry ->
                        val args = entry.toRoute<RouteRoster>()
                        RosterScreen(
                            language = lang,
                            portraitUrls = portraitUrls,
                            duelLabState = duelLab,
                            initialTab = args.initialTab,
                            onRequestPortrait = { viewModel.ensurePortraitResolved(it) },
                            onSelectFighterA = { viewModel.updateDuelFighterA(it) },
                            onSelectFighterB = { viewModel.updateDuelFighterB(it) },
                            onSelectDuelMode = { viewModel.updateDuelComparisonMode(it) },
                            onSwapDuelFighters = { viewModel.swapDuelFighters() }
                        )
                    }

                    composable<RouteHistory> {
                        HistoryScreen(
                            records = savedDrafts,
                            language = lang,
                            onOpenRecord = { record ->
                                viewModel.openSavedReport(record)
                                navController.navigate(RouteReport)
                            },
                            onDeleteRecord = { viewModel.deleteSavedReport(it) },
                            onClearAll = { viewModel.clearAllHistory() }
                        )
                    }

                    composable<RouteSettings> {
                        SettingsScreen(
                            settings = settings,
                            cachedPortraitCount = portraitUrls.size,
                            onSelectLanguage = { viewModel.setLanguage(it) },
                            onUpdatePlayerNames = { p1, p2 -> viewModel.setPlayerNames(p1, p2) },
                            onSelectComparisonMode = { viewModel.setDefaultComparisonMode(it) },
                            onSelectTeamSize = { viewModel.setDefaultTeamSize(it) },
                            onToggleDarkTheme = { viewModel.setDarkTheme(it) },
                            onClearPortraitCache = { viewModel.clearPortraitCache() }
                        )
                    }
                }
            }
        }
    }
}
