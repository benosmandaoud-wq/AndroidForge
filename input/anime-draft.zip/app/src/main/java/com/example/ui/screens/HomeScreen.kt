package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.CharacterRoster
import com.example.data.UiText
import com.example.engine.DraftEngine
import com.example.model.AnimeUniverse
import com.example.model.ComparisonMode
import com.example.model.DraftState
import com.example.model.GameSettings
import com.example.model.Language
import com.example.model.PlayerKey
import com.example.model.SavedDraftRecord
import com.example.ui.components.HowToPlayDialog
import com.example.ui.theme.CrimsonTertiary
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldWin
import com.example.ui.theme.GoldPrimary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    settings: GameSettings,
    activeDraft: DraftState?,
    recentDraft: SavedDraftRecord?,
    onStartDraft: (String, String, List<AnimeUniverse>, Int, ComparisonMode) -> Unit,
    onResumeDraft: () -> Unit,
    onOpenDuelLab: () -> Unit,
    onOpenReport: (SavedDraftRecord) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = settings.language
    var player1Name by remember(settings.player1Name) { mutableStateOf(settings.player1Name) }
    var player2Name by remember(settings.player2Name) { mutableStateOf(settings.player2Name) }
    var selectedUniverses by remember { mutableStateOf(AnimeUniverse.entries.toList()) }
    var singleAnimeMode by remember { mutableStateOf(false) }
    var selectedRounds by remember(settings.defaultTeamSize) { mutableIntStateOf(settings.defaultTeamSize) }
    var isCustomRounds by remember { mutableStateOf(settings.defaultTeamSize !in listOf(1, 3, 5, 8, 10)) }
    var selectedMode by remember(settings.defaultComparisonMode) { mutableStateOf(settings.defaultComparisonMode) }
    var showRulesDialog by remember { mutableStateOf(false) }

    val poolCount = remember(selectedUniverses) {
        val active = if (selectedUniverses.isEmpty()) AnimeUniverse.entries else selectedUniverses
        CharacterRoster.allCharacters.count { it.universe in active }
    }
    val maxRoundsSupported = remember(selectedUniverses) {
        DraftEngine.maxRoundsForUniverses(selectedUniverses)
    }
    val hasEnoughCharacters = selectedUniverses.isNotEmpty() && selectedRounds in 1..maxRoundsSupported

    if (showRulesDialog) {
        HowToPlayDialog(language = lang, onDismiss = { showRulesDialog = false })
    }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Banner
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.35f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_arena_hero),
                            contentDescription = UiText.appTitle.get(lang),
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color(0x55090D16), Color(0xEB090D16))
                                    )
                                )
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(18.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = GoldPrimary.copy(alpha = 0.2f),
                                    border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.6f))
                                ) {
                                    Text(
                                        text = if (lang == Language.AR) "نظام 3 بطاقات • لاعبان" else "2P BLIND & VISIBLE DRAFT",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = GoldPrimary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = UiText.appTitle.get(lang),
                                    style = MaterialTheme.typography.headlineLarge,
                                    color = Color.White
                                )
                                Text(
                                    text = UiText.appSubtitle.get(lang),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFFCBD5E1)
                                )
                            }
                            IconButton(
                                onClick = { showRulesDialog = true },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("how_to_play_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.HelpOutline,
                                    contentDescription = UiText.howToPlay.get(lang),
                                    tint = Color.White
                                )
                            }
                        }
                    }
                }
            }

            // Continue Unfinished Draft Banner
            if (activeDraft != null) {
                item {
                    val isDone = activeDraft.isComplete
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDone) EmeraldWin.copy(alpha = 0.14f) else MaterialTheme.colorScheme.primaryContainer
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isDone) EmeraldWin.copy(alpha = 0.6f) else GoldPrimary.copy(alpha = 0.6f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onResumeDraft)
                            .testTag("resume_draft_card")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PlayArrow,
                                contentDescription = null,
                                tint = if (isDone) EmeraldWin else MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isDone) {
                                        if (lang == Language.AR) "عرض الدرافت المكتمل" else "View Completed Draft"
                                    } else {
                                        UiText.resumeDraft.get(lang)
                                    },
                                    style = MaterialTheme.typography.titleSmall,
                                    color = if (isDone) EmeraldWin else MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "${activeDraft.player1Name} (${activeDraft.team1.size}/${activeDraft.totalRounds}) vs ${activeDraft.player2Name} (${activeDraft.team2.size}/${activeDraft.totalRounds}) • ${UiText.roundPrefix.get(lang)} ${activeDraft.currentRound}/${activeDraft.totalRounds}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null
                            )
                        }
                    }
                }
            }

            // Draft Setup Configurator Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Player Names
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = player1Name,
                                onValueChange = { player1Name = it },
                                label = { Text(UiText.player1Label.get(lang)) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("player1_name_input")
                            )
                            OutlinedTextField(
                                value = player2Name,
                                onValueChange = { player2Name = it },
                                label = { Text(UiText.player2Label.get(lang)) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("player2_name_input")
                            )
                        }

                        // Single Anime vs Multi-Anime Universe Selection
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = UiText.universeFocusLabel.get(lang),
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = if (lang == Language.AR) {
                                    "$poolCount مقاتل (أقصى $maxRoundsSupported جولات)"
                                } else {
                                    "$poolCount fighters (max $maxRoundsSupported rounds)"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = if (hasEnoughCharacters) CyanSecondary else CrimsonTertiary
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = singleAnimeMode,
                                onClick = {
                                    singleAnimeMode = true
                                    if (selectedUniverses.size != 1) {
                                        selectedUniverses = listOf(selectedUniverses.firstOrNull() ?: AnimeUniverse.NARUTO)
                                    }
                                    val maxR = DraftEngine.maxRoundsForUniverses(selectedUniverses)
                                    if (selectedRounds > maxR) selectedRounds = maxR
                                },
                                label = { Text(if (lang == Language.AR) "أنمي واحد" else "Single Anime") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GoldPrimary.copy(alpha = 0.22f),
                                    selectedLabelColor = GoldPrimary
                                )
                            )
                            FilterChip(
                                selected = !singleAnimeMode,
                                onClick = {
                                    singleAnimeMode = false
                                    if (selectedUniverses.isEmpty()) {
                                        selectedUniverses = AnimeUniverse.entries.toList()
                                    }
                                },
                                label = { Text(if (lang == Language.AR) "عدة أنميات" else "Multi-Anime") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GoldPrimary.copy(alpha = 0.22f),
                                    selectedLabelColor = GoldPrimary
                                )
                            )
                        }

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (!singleAnimeMode) {
                                val allSelected = selectedUniverses.size == AnimeUniverse.entries.size
                                FilterChip(
                                    selected = allSelected,
                                    onClick = {
                                        selectedUniverses = if (allSelected) emptyList() else AnimeUniverse.entries.toList()
                                    },
                                    leadingIcon = if (allSelected) {
                                        { Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    } else null,
                                    label = { Text(UiText.allUniverses.get(lang)) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = GoldPrimary.copy(alpha = 0.22f),
                                        selectedLabelColor = GoldPrimary
                                    )
                                )
                            }
                            AnimeUniverse.entries.forEach { uni ->
                                val isSelected = uni in selectedUniverses
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        selectedUniverses = if (singleAnimeMode) {
                                            listOf(uni)
                                        } else {
                                            if (isSelected) selectedUniverses - uni else selectedUniverses + uni
                                        }
                                        val maxR = DraftEngine.maxRoundsForUniverses(selectedUniverses)
                                        if (selectedRounds > maxR && maxR >= 1) selectedRounds = maxR
                                    },
                                    label = { Text(uni.title.get(lang)) }
                                )
                            }
                        }

                        // Number of Rounds / Characters Per Team
                        Text(
                            text = UiText.roundsAndTeamLabel.get(lang),
                            style = MaterialTheme.typography.titleSmall
                        )
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(1, 3, 5, 8, 10).forEach { count ->
                                val enabledCount = count <= maxRoundsSupported
                                FilterChip(
                                    selected = !isCustomRounds && selectedRounds == count,
                                    enabled = enabledCount,
                                    onClick = {
                                        isCustomRounds = false
                                        selectedRounds = count
                                    },
                                    label = { Text("$count") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyanSecondary.copy(alpha = 0.2f),
                                        selectedLabelColor = CyanSecondary
                                    )
                                )
                            }
                            FilterChip(
                                selected = isCustomRounds,
                                onClick = { isCustomRounds = true },
                                label = { Text(UiText.customRoundsLabel.get(lang)) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyanSecondary.copy(alpha = 0.2f),
                                    selectedLabelColor = CyanSecondary
                                )
                            )
                        }

                        if (isCustomRounds) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { if (selectedRounds > 1) selectedRounds -= 1 },
                                    contentPadding = PaddingValues(0.dp),
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Filled.Remove, contentDescription = "Decrease rounds")
                                }
                                Text(
                                    text = if (lang == Language.AR) {
                                        "$selectedRounds جولات = $selectedRounds مقاتل لكل فريق"
                                    } else {
                                        "$selectedRounds Rounds = $selectedRounds Fighters Each"
                                    },
                                    style = MaterialTheme.typography.titleSmall,
                                    color = CyanSecondary
                                )
                                OutlinedButton(
                                    onClick = {
                                        val limit = maxRoundsSupported.coerceAtLeast(1)
                                        if (selectedRounds < limit) selectedRounds += 1
                                    },
                                    contentPadding = PaddingValues(0.dp),
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Filled.Add, contentDescription = "Increase rounds")
                                }
                            }
                        } else {
                            val minPoolRequired = selectedRounds * 2 + 1
                            Text(
                                text = if (lang == Language.AR) {
                                    "$selectedRounds جولات = $selectedRounds شخصيات لـ ${player1Name.ifBlank { "Daoud" }} و$selectedRounds لـ ${player2Name.ifBlank { "Monsef" }} (تتطلب $minPoolRequired شخصية على الأقل)."
                                } else {
                                    "$selectedRounds rounds = $selectedRounds fighters for ${player1Name.ifBlank { "Daoud" }} and $selectedRounds for ${player2Name.ifBlank { "Monsef" }} (requires at least $minPoolRequired fighters)."
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (!hasEnoughCharacters) {
                            val minPoolRequired = selectedRounds * 2 + 1
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = CrimsonTertiary.copy(alpha = 0.16f),
                                border = BorderStroke(1.dp, CrimsonTertiary.copy(alpha = 0.5f))
                            ) {
                                Text(
                                    text = if (lang == Language.AR) {
                                        "اختر عوالم إضافية أو قلّل الجولات: عدد الشخصيات المختارة ($poolCount) أقل من المطلوب ($minPoolRequired)."
                                    } else {
                                        "Select more universes or fewer rounds: $poolCount characters available, $minPoolRequired needed to avoid team duplicates."
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CrimsonTertiary,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }

                        // Comparison Mode
                        Text(
                            text = UiText.comparisonModeLabel.get(lang),
                            style = MaterialTheme.typography.titleSmall
                        )
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ComparisonMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = selectedMode == mode,
                                    onClick = { selectedMode = mode },
                                    label = { Text(mode.label.get(lang)) }
                                )
                            }
                        }

                        // Launch Draft CTA
                        Button(
                            onClick = {
                                onStartDraft(
                                    player1Name.ifBlank { "Daoud" },
                                    player2Name.ifBlank { "Monsef" },
                                    selectedUniverses,
                                    selectedRounds,
                                    selectedMode
                                )
                            },
                            enabled = hasEnoughCharacters,
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("start_draft_button")
                        ) {
                            Icon(Icons.Filled.Groups, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = UiText.startTwoPlayerDraft.get(lang),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Quick 1v1 Duel Lab Promo
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onOpenDuelLab)
                        .testTag("open_duel_lab_card")
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(CyanSecondary.copy(alpha = 0.16f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Bolt, contentDescription = null, tint = CyanSecondary)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(UiText.openDuelLab.get(lang), style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = if (lang == Language.AR) "قارن بين أي مقاتلين فوراً" else "Pit any two fighters head-to-head instantly",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                    }
                }
            }

            // Latest Completed Match Card
            if (recentDraft != null) {
                item {
                    val report = recentDraft.report
                    val winLabel = when (report.winner) {
                        PlayerKey.PLAYER_1 -> recentDraft.player1Name
                        PlayerKey.PLAYER_2 -> recentDraft.player2Name
                        null -> UiText.draw.get(lang)
                    }
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        border = BorderStroke(1.dp, EmeraldWin.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenReport(recentDraft) }
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = EmeraldWin)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (lang == Language.AR) "آخر مقارنة • $winLabel" else "Latest Comparison • $winLabel",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = EmeraldWin
                                )
                                Text(
                                    text = "${recentDraft.player1Name} ${report.p1TotalScore} - ${report.p2TotalScore} ${recentDraft.player2Name} • MVP: ${report.mvpCharacter.name.get(lang)}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                        }
                    }
                }
            }
        }
    }
}
