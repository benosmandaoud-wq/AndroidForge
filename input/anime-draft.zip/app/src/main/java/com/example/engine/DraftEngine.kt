package com.example.engine

import com.example.data.CharacterRoster
import com.example.model.AnimeUniverse
import com.example.model.Character
import com.example.model.CharacterType
import com.example.model.ComparisonMode
import com.example.model.DraftCardSlot
import com.example.model.DraftDifficulty
import com.example.model.DraftMode
import com.example.model.DraftState
import com.example.model.FinalBattleReport
import com.example.model.LocalizedText
import com.example.model.MatchupAnalysis
import com.example.model.PlayerKey
import com.example.model.PowerCategory
import com.example.model.RoundHistoryEntry
import com.example.model.RoundPhase
import com.example.model.SynergyBonus
import com.example.model.TeamDimensionScores
import java.util.UUID
import kotlin.math.roundToInt
import kotlin.random.Random

object DraftEngine {

    fun maxRoundsForUniverses(universes: List<AnimeUniverse>): Int {
        val activeUniverses = if (universes.isEmpty()) AnimeUniverse.entries else universes
        val count = CharacterRoster.allCharacters.count { it.universe in activeUniverses }
        if (count < 3) return 0
        // Round R starts with 2*(R-1) drafted characters and needs 3 undrafted cards -> 2R + 1 <= count
        return ((count - 1) / 2).coerceIn(1, 12)
    }

    fun createInitialDraft(
        player1Name: String = "Daoud",
        player2Name: String = "Monsef",
        selectedUniverses: List<AnimeUniverse> = AnimeUniverse.entries,
        totalRounds: Int = 5,
        comparisonMode: ComparisonMode = ComparisonMode.BALANCED,
        random: Random = Random.Default
    ): DraftState {
        val universes = if (selectedUniverses.isEmpty()) AnimeUniverse.entries else selectedUniverses.distinct()
        val eligiblePool = CharacterRoster.allCharacters
            .filter { it.universe in universes }
            .shuffled(random)

        val safeRounds = totalRounds.coerceIn(1, maxRoundsForUniverses(universes))
        val firstThree = eligiblePool.take(3)
        val remaining = eligiblePool.drop(3)

        val cards = firstThree.mapIndexed { idx, character ->
            DraftCardSlot(
                slotIndex = idx,
                character = character,
                isVisibleInitial = (idx == 0),
                isRevealed = (idx == 0)
            )
        }

        return DraftState(
            draftId = UUID.randomUUID().toString(),
            player1Name = player1Name.ifBlank { "Daoud" },
            player2Name = player2Name.ifBlank { "Monsef" },
            selectedUniverses = universes,
            totalRounds = safeRounds,
            comparisonMode = comparisonMode,
            remainingPool = remaining,
            team1 = emptyList(),
            team2 = emptyList(),
            currentRound = 1,
            startingPlayer = PlayerKey.PLAYER_1,
            activePlayer = PlayerKey.PLAYER_1,
            phase = RoundPhase.PICK_INITIAL,
            currentCards = cards,
            history = emptyList(),
            isComplete = false,
            mode = DraftMode.LOCAL_2P,
            difficulty = DraftDifficulty.TACTICAL,
            teamSize = safeRounds
        )
    }

    fun selectDraftCard(state: DraftState, slotIndex: Int): DraftState {
        if (state.isComplete || state.phase == RoundPhase.ROUND_REVEAL) return state
        val selectedSlot = state.currentCards.find { it.slotIndex == slotIndex } ?: return state

        val currentPlayer = state.activePlayer
        val opponent = if (currentPlayer == PlayerKey.PLAYER_1) PlayerKey.PLAYER_2 else PlayerKey.PLAYER_1

        return when (state.phase) {
            RoundPhase.PICK_INITIAL -> {
                if (selectedSlot.isVisibleInitial) {
                    // RULE A: Active player receives visible character; opponent chooses between the 2 hidden cards.
                    val updatedCards = state.currentCards.map { card ->
                        if (card.slotIndex == slotIndex) {
                            card.copy(claimedBy = currentPlayer, isRevealed = true)
                        } else {
                            card
                        }
                    }
                    state.copy(
                        activePlayer = opponent,
                        phase = RoundPhase.OPPONENT_PICK_HIDDEN,
                        currentCards = updatedCards
                    )
                } else {
                    // RULE B: Active player receives chosen hidden card; opponent gets visible card; other hidden discarded.
                    val visibleCard = state.currentCards.first { it.isVisibleInitial }
                    val otherHidden = state.currentCards.first { !it.isVisibleInitial && it.slotIndex != slotIndex }

                    val updatedCards = state.currentCards.map { card ->
                        when (card.slotIndex) {
                            slotIndex -> card.copy(claimedBy = currentPlayer, isRevealed = true)
                            visibleCard.slotIndex -> card.copy(claimedBy = opponent, isRevealed = true)
                            else -> card.copy(isDiscarded = true, isRevealed = true)
                        }
                    }

                    val p1Pick = if (currentPlayer == PlayerKey.PLAYER_1) selectedSlot.character else visibleCard.character
                    val p2Pick = if (currentPlayer == PlayerKey.PLAYER_2) selectedSlot.character else visibleCard.character

                    val historyEntry = RoundHistoryEntry(
                        roundNumber = state.currentRound,
                        startingPlayer = state.startingPlayer,
                        offeredCharacters = state.currentCards.map { it.character },
                        player1Pick = p1Pick,
                        player2Pick = p2Pick,
                        discardedCharacter = otherHidden.character,
                        ruleApplied = "RULE_B"
                    )

                    state.copy(
                        team1 = state.team1 + p1Pick,
                        team2 = state.team2 + p2Pick,
                        phase = RoundPhase.ROUND_REVEAL,
                        currentCards = updatedCards,
                        history = state.history + historyEntry
                    )
                }
            }

            RoundPhase.OPPONENT_PICK_HIDDEN -> {
                // Opponent must choose one of the two hidden cards (never the already-claimed visible card)
                if (selectedSlot.isVisibleInitial || selectedSlot.claimedBy != null) return state

                val visibleCard = state.currentCards.first { it.isVisibleInitial }
                val starter = visibleCard.claimedBy ?: state.startingPlayer
                val discardedCard = state.currentCards.first { !it.isVisibleInitial && it.slotIndex != slotIndex }

                val updatedCards = state.currentCards.map { card ->
                    when (card.slotIndex) {
                        slotIndex -> card.copy(claimedBy = currentPlayer, isRevealed = true)
                        discardedCard.slotIndex -> card.copy(isDiscarded = true, isRevealed = true)
                        else -> card.copy(isRevealed = true)
                    }
                }

                val p1Pick = if (starter == PlayerKey.PLAYER_1) visibleCard.character else selectedSlot.character
                val p2Pick = if (starter == PlayerKey.PLAYER_2) visibleCard.character else selectedSlot.character

                val historyEntry = RoundHistoryEntry(
                    roundNumber = state.currentRound,
                    startingPlayer = state.startingPlayer,
                    offeredCharacters = state.currentCards.map { it.character },
                    player1Pick = p1Pick,
                    player2Pick = p2Pick,
                    discardedCharacter = discardedCard.character,
                    ruleApplied = "RULE_A"
                )

                state.copy(
                    team1 = state.team1 + p1Pick,
                    team2 = state.team2 + p2Pick,
                    phase = RoundPhase.ROUND_REVEAL,
                    currentCards = updatedCards,
                    history = state.history + historyEntry
                )
            }

            RoundPhase.ROUND_REVEAL -> state
        }
    }

    fun advanceToNextRound(state: DraftState, random: Random = Random.Default): DraftState {
        if (state.isComplete) return state
        if (state.phase != RoundPhase.ROUND_REVEAL) return state

        if (state.currentRound >= state.totalRounds) {
            return state.copy(isComplete = true)
        }

        // Never allow any character already drafted onto Team 1 or Team 2 to appear again.
        val draftedIds = (state.team1 + state.team2).map { it.id }.toSet()
        var pool = state.remainingPool.filterNot { it.id in draftedIds }

        if (pool.size < 3) {
            val alreadyInPoolIds = pool.map { it.id }.toSet()
            val replenishedFromDiscards = CharacterRoster.allCharacters
                .filter { it.universe in state.selectedUniverses && it.id !in draftedIds && it.id !in alreadyInPoolIds }
                .shuffled(random)
            pool = pool + replenishedFromDiscards
        }

        if (pool.size < 3) {
            return state.copy(isComplete = true)
        }

        val nextRound = state.currentRound + 1
        val nextStarter = if (nextRound % 2 == 1) PlayerKey.PLAYER_1 else PlayerKey.PLAYER_2
        val nextThree = pool.take(3)
        val remaining = pool.drop(3)

        val nextCards = nextThree.mapIndexed { idx, character ->
            DraftCardSlot(
                slotIndex = idx,
                character = character,
                isVisibleInitial = (idx == 0),
                isRevealed = (idx == 0)
            )
        }

        return state.copy(
            remainingPool = remaining,
            currentRound = nextRound,
            startingPlayer = nextStarter,
            activePlayer = nextStarter,
            phase = RoundPhase.PICK_INITIAL,
            currentCards = nextCards
        )
    }

    fun modeWeightedStat(character: Character, mode: ComparisonMode): Double {
        val s = character.stats
        return when (mode) {
            ComparisonMode.BALANCED -> s.overall.toDouble()
            ComparisonMode.POWER_CLASH -> (s.offense * 0.35 + s.aura * 0.30 + s.defense * 0.20 + s.speed * 0.15)
            ComparisonMode.TACTICAL_SYNERGY -> (s.intelligence * 0.35 + s.versatility * 0.35 + s.defense * 0.15 + s.aura * 0.15)
            ComparisonMode.SPEED_BLITZ -> (s.speed * 0.45 + s.offense * 0.25 + s.versatility * 0.15 + s.aura * 0.15)
        }
    }

    /**
     * Circular + tactical PowerCategory edge:
     * PHYSICAL > ENERGY > ELEMENTAL > SPIRITUAL > HAX > PHYSICAL
     */
    fun hasCategoryAdvantage(attacker: PowerCategory, defender: PowerCategory): Boolean {
        return when (attacker) {
            PowerCategory.PHYSICAL -> defender == PowerCategory.ENERGY
            PowerCategory.ENERGY -> defender == PowerCategory.ELEMENTAL
            PowerCategory.ELEMENTAL -> defender == PowerCategory.SPIRITUAL
            PowerCategory.SPIRITUAL -> defender == PowerCategory.HAX
            PowerCategory.HAX -> defender == PowerCategory.PHYSICAL
        }
    }

    fun analyzeIndividualMatchup(
        c1: Character,
        c2: Character,
        mode: ComparisonMode,
        slotIndex: Int = 0
    ): MatchupAnalysis {
        val p1Base = modeWeightedStat(c1, mode)
        val p2Base = modeWeightedStat(c2, mode)

        val p1Adv = hasCategoryAdvantage(c1.powerCategory, c2.powerCategory)
        val p2Adv = hasCategoryAdvantage(c2.powerCategory, c1.powerCategory)

        val p1CategoryBonus = if (p1Adv) 4.5 else 0.0
        val p2CategoryBonus = if (p2Adv) 4.5 else 0.0

        val p1Score = (p1Base + p1CategoryBonus).roundToInt()
        val p2Score = (p2Base + p2CategoryBonus).roundToInt()

        val winner = when {
            p1Score > p2Score -> PlayerKey.PLAYER_1
            p2Score > p1Score -> PlayerKey.PLAYER_2
            else -> null
        }

        val categoryEdge = when {
            p1Adv -> PlayerKey.PLAYER_1
            p2Adv -> PlayerKey.PLAYER_2
            else -> null
        }

        val summary = buildMatchupSummary(c1, c2, p1Score, p2Score, winner, categoryEdge)

        return MatchupAnalysis(
            slotIndex = slotIndex,
            player1Character = c1,
            player2Character = c2,
            p1DuelScore = p1Score,
            p2DuelScore = p2Score,
            winner = winner,
            categoryEdge = categoryEdge,
            summary = summary
        )
    }

    private fun buildMatchupSummary(
        c1: Character,
        c2: Character,
        p1Score: Int,
        p2Score: Int,
        winner: PlayerKey?,
        categoryEdge: PlayerKey?
    ): LocalizedText {
        val margin = kotlin.math.abs(p1Score - p2Score)
        return when (winner) {
            PlayerKey.PLAYER_1 -> {
                val edgeNoteEn = if (categoryEdge == PlayerKey.PLAYER_1) " with a ${c1.powerCategory.label.en} style edge" else ""
                val edgeNoteAr = if (categoryEdge == PlayerKey.PLAYER_1) " مع أفضلية فئة ${c1.powerCategory.label.ar}" else ""
                LocalizedText(
                    en = "${c1.name.en} claims the duel (+$margin pts)$edgeNoteEn using ${c1.signatureMove.en}.",
                    ar = "يحسم ${c1.name.ar} المواجهة (+$margin نقطة)$edgeNoteAr عبر ${c1.signatureMove.ar}."
                )
            }
            PlayerKey.PLAYER_2 -> {
                val edgeNoteEn = if (categoryEdge == PlayerKey.PLAYER_2) " with a ${c2.powerCategory.label.en} style edge" else ""
                val edgeNoteAr = if (categoryEdge == PlayerKey.PLAYER_2) " مع أفضلية فئة ${c2.powerCategory.label.ar}" else ""
                LocalizedText(
                    en = "${c2.name.en} prevails (+$margin pts)$edgeNoteEn by unleashing ${c2.signatureMove.en}.",
                    ar = "يتفوق ${c2.name.ar} (+$margin نقطة)$edgeNoteAr بإطلاق ${c2.signatureMove.ar}."
                )
            }
            null -> LocalizedText(
                en = "Deadlock! ${c1.name.en} and ${c2.name.en} trade blow for blow to a stalemate.",
                ar = "تعادل تام! تبادل ${c1.name.ar} و${c2.name.ar} الضربات حتى النهاية."
            )
        }
    }

    fun computeTeamSynergies(team: List<Character>): List<SynergyBonus> {
        if (team.isEmpty()) return emptyList()
        val bonuses = mutableListOf<SynergyBonus>()

        // Universe synergy: 2+ characters from same universe
        team.groupBy { it.universe }.forEach { (universe, members) ->
            if (members.size >= 2) {
                val pts = if (members.size >= 3) 9 else 5
                bonuses += SynergyBonus(
                    title = universe.synergyName,
                    description = LocalizedText(
                        en = "${members.size}x ${universe.title.en} fighters boost team coordination (+$pts)",
                        ar = "${members.size} مقاتلين من ${universe.title.ar} يعززون التناغم (+$pts)"
                    ),
                    bonusPoints = pts
                )
            }
        }

        // Role diversity synergy
        val distinctRoles = team.map { it.type }.distinct().size
        if (distinctRoles >= 3) {
            val pts = if (distinctRoles >= 4) 7 else 4
            bonuses += SynergyBonus(
                title = LocalizedText("Balanced Formation", "تشكيلة متكاملة"),
                description = LocalizedText(
                    en = "$distinctRoles distinct tactical roles cover offense & defense (+$pts)",
                    ar = "$distinctRoles أدوار قتالية مختلفة تغطي الهجوم والدفاع (+$pts)"
                ),
                bonusPoints = pts
            )
        }

        // Strategist + Striker combo
        val hasStrategist = team.any { it.type == CharacterType.STRATEGIST || it.type == CharacterType.SUPPORT }
        val hasStriker = team.any { it.type == CharacterType.STRIKER || it.type == CharacterType.ASSASSIN }
        if (hasStrategist && hasStriker) {
            bonuses += SynergyBonus(
                title = LocalizedText("Tactical Setup", "تنسيق هجومي ذكي"),
                description = LocalizedText(
                    en = "Playmaker & finisher pairing unlocks lethal openings (+4)",
                    ar = "اقتران المخطط بالمهاجم يفتح ثغرات قاتلة (+4)"
                ),
                bonusPoints = 4
            )
        }

        return bonuses
    }

    fun computeTeamDimensions(team: List<Character>, mode: ComparisonMode): TeamDimensionScores {
        if (team.isEmpty()) return TeamDimensionScores(0, 0, 0, 0, 0, 0)
        val count = team.size.toDouble()
        val synergies = computeTeamSynergies(team)
        val synergyPts = synergies.sumOf { it.bonusPoints }

        val avgOffense = team.sumOf { it.stats.offense } / count
        val avgDefense = team.sumOf { it.stats.defense } / count
        val avgSpeed = team.sumOf { it.stats.speed } / count
        val avgIntel = team.sumOf { it.stats.intelligence } / count
        val avgVersatility = team.sumOf { it.stats.versatility } / count
        val avgAura = team.sumOf { it.stats.aura } / count

        val firepowerBoost = if (mode == ComparisonMode.POWER_CLASH) 1.08 else 1.0
        val speedBoost = if (mode == ComparisonMode.SPEED_BLITZ) 1.10 else 1.0
        val tacticsBoost = if (mode == ComparisonMode.TACTICAL_SYNERGY) 1.10 else 1.0

        val firepower = (avgOffense * firepowerBoost).roundToInt().coerceIn(0, 100)
        val durability = avgDefense.roundToInt().coerceIn(0, 100)
        val speed = (avgSpeed * speedBoost).roundToInt().coerceIn(0, 100)
        val tactics = (((avgIntel * 0.65) + (avgVersatility * 0.35)) * tacticsBoost).roundToInt().coerceIn(0, 100)
        val synergy = (58 + synergyPts * 2.1).roundToInt().coerceIn(0, 100)
        val clutch = ((avgAura * 0.8) + (team.maxOf { it.stats.aura } * 0.2)).roundToInt().coerceIn(0, 100)

        return TeamDimensionScores(
            firepower = firepower,
            durability = durability,
            speed = speed,
            tactics = tactics,
            synergy = synergy,
            clutch = clutch
        )
    }

    fun generateFinalReport(state: DraftState): FinalBattleReport {
        val team1 = state.team1
        val team2 = state.team2
        val pairs = team1.zip(team2).mapIndexed { idx, (c1, c2) ->
            analyzeIndividualMatchup(c1, c2, state.comparisonMode, slotIndex = idx)
        }

        val p1Syn = computeTeamSynergies(team1)
        val p2Syn = computeTeamSynergies(team2)

        val p1Dims = computeTeamDimensions(team1, state.comparisonMode)
        val p2Dims = computeTeamDimensions(team2, state.comparisonMode)

        val p1DuelWins = pairs.count { it.winner == PlayerKey.PLAYER_1 }
        val p2DuelWins = pairs.count { it.winner == PlayerKey.PLAYER_2 }

        val p1Total = p1Dims.totalScore + (p1DuelWins * 12) + p1Syn.sumOf { it.bonusPoints }
        val p2Total = p2Dims.totalScore + (p2DuelWins * 12) + p2Syn.sumOf { it.bonusPoints }

        val winner = when {
            p1Total > p2Total -> PlayerKey.PLAYER_1
            p2Total > p1Total -> PlayerKey.PLAYER_2
            else -> null
        }

        val (p1WinPct, p2WinPct) = computeWinPercentages(
            p1Total = p1Total,
            p2Total = p2Total,
            p1DuelWins = p1DuelWins,
            p2DuelWins = p2DuelWins
        )

        val allEntries = team1.map { it to PlayerKey.PLAYER_1 } + team2.map { it to PlayerKey.PLAYER_2 }
        val (mvpChar, mvpOwner) = allEntries.maxByOrNull { (c, _) ->
            modeWeightedStat(c, state.comparisonMode)
        } ?: (CharacterRoster.allCharacters.first() to PlayerKey.PLAYER_1)

        val verdict = when (winner) {
            PlayerKey.PLAYER_1 -> LocalizedText(
                en = "Team Gold dominates the arena ($p1Total vs $p2Total • $p1WinPct% win rate), winning $p1DuelWins of ${pairs.size} slot duels behind ${mvpChar.name.en}.",
                ar = "يسيطر الفريق الذهبي على الساحة ($p1Total مقابل $p2Total • نسبة الفوز $p1WinPct%)، حاسماً $p1DuelWins من أصل ${pairs.size} مواجهات بقيادة ${mvpChar.name.ar}."
            )
            PlayerKey.PLAYER_2 -> LocalizedText(
                en = "Team Cyan seizes victory ($p2Total vs $p1Total • $p2WinPct% win rate), capturing $p2DuelWins of ${pairs.size} slot duels with superior synergy.",
                ar = "ينتزع الفريق السماوي الفوز ($p2Total مقابل $p1Total • نسبة الفوز $p2WinPct%)، كاسباً $p2DuelWins من أصل ${pairs.size} مواجهات بتناغم متفوق."
            )
            null -> LocalizedText(
                en = "An astonishing draw at $p1Total points apiece (50% - 50%)! Both squads matched blow for blow.",
                ar = "تعادل مذهل عند $p1Total نقطة لكل فريق (50% - 50%)! تكافؤ كامل في القوة والتكتيك."
            )
        }

        return FinalBattleReport(
            winner = winner,
            p1TotalScore = p1Total,
            p2TotalScore = p2Total,
            p1Dimensions = p1Dims,
            p2Dimensions = p2Dims,
            p1Synergies = p1Syn,
            p2Synergies = p2Syn,
            matchups = pairs,
            mvpCharacter = mvpChar,
            mvpOwner = mvpOwner,
            verdictSummary = verdict,
            p1WinPercent = p1WinPct,
            p2WinPercent = p2WinPct
        )
    }

    fun computeWinPercentages(
        p1Total: Int,
        p2Total: Int,
        p1DuelWins: Int,
        p2DuelWins: Int
    ): Pair<Int, Int> {
        val diff = (p1Total - p2Total).toDouble()
        val duelDiff = (p1DuelWins - p2DuelWins).toDouble()
        if (p1Total == p2Total && p1DuelWins == p2DuelWins) {
            return 50 to 50
        }
        val combinedMargin = diff + (duelDiff * 6.0)
        val rawProb = 1.0 / (1.0 + kotlin.math.exp(-combinedMargin / 48.0))
        var p1Pct = (rawProb * 100.0).roundToInt().coerceIn(5, 95)
        if (p1Total > p2Total && p1Pct <= 50) p1Pct = 51
        if (p2Total > p1Total && p1Pct >= 50) p1Pct = 49
        return p1Pct to (100 - p1Pct)
    }
}
