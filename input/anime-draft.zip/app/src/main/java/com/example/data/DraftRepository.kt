package com.example.data

import com.example.data.local.ActiveDraftDao
import com.example.data.local.ActiveDraftEntity
import com.example.data.local.PortraitCacheDao
import com.example.data.local.PortraitCacheEntity
import com.example.data.local.SavedDraftDao
import com.example.data.local.SavedDraftEntity
import com.example.data.local.SettingsDataStore
import com.example.data.network.AniListApiService
import com.example.data.network.AniListCharacterDto
import com.example.data.network.AniListGraphQlRequest
import com.example.data.network.JikanApiService
import com.example.model.AnimeUniverse
import com.example.model.Character
import com.example.model.DraftState
import com.example.model.GameSettings
import com.example.model.SavedDraftRecord
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.concurrent.ConcurrentHashMap

class DraftRepository(
    private val savedDraftDao: SavedDraftDao,
    private val portraitCacheDao: PortraitCacheDao,
    private val activeDraftDao: ActiveDraftDao,
    private val settingsDataStore: SettingsDataStore,
    private val aniListApi: AniListApiService,
    private val jikanApi: JikanApiService
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val inFlightQueries = ConcurrentHashMap<String, Boolean>()
    private val retryBackoffUntil = ConcurrentHashMap<String, Long>()
    private val aniListMutex = Mutex()
    private val jikanMutex = Mutex()
    private var lastAniListMillis = 0L
    private var lastJikanMillis = 0L

    val settingsFlow: Flow<GameSettings> = settingsDataStore.settingsFlow

    val savedDraftsFlow: Flow<List<SavedDraftRecord>> = savedDraftDao.observeAllDrafts().map { list ->
        list.mapNotNull { entity ->
            runCatching { json.decodeFromString<SavedDraftRecord>(entity.payloadJson) }.getOrNull()
        }
    }

    val activeDraftFlow: Flow<DraftState?> = activeDraftDao.observeActiveDraft().map { entity ->
        entity?.let {
            runCatching { json.decodeFromString<DraftState>(it.payloadJson) }.getOrNull()
        }
    }

    val portraitUrlsFlow: Flow<Map<String, String>> = portraitCacheDao.observeAllPortraits().map { list ->
        list.filter { isValidPortraitUrl(it.imageUrl) }
            .associate { it.characterId to it.imageUrl }
    }

    suspend fun updateSettings(transform: (GameSettings) -> GameSettings) {
        settingsDataStore.updateSettings(transform)
    }

    suspend fun saveActiveDraft(state: DraftState) {
        val payload = json.encodeToString(state)
        activeDraftDao.upsertActiveDraft(
            ActiveDraftEntity(
                id = 1,
                payloadJson = payload,
                updatedAtMillis = System.currentTimeMillis()
            )
        )
    }

    suspend fun clearActiveDraft() {
        activeDraftDao.clearActiveDraft()
    }

    suspend fun saveDraftRecord(record: SavedDraftRecord) {
        val payload = json.encodeToString(record)
        savedDraftDao.insertDraft(
            SavedDraftEntity(
                id = record.id,
                timestampMillis = record.timestampMillis,
                payloadJson = payload
            )
        )
    }

    suspend fun deleteDraftRecord(id: String) {
        savedDraftDao.deleteById(id)
    }

    suspend fun clearAllDrafts() {
        savedDraftDao.deleteAll()
    }

    suspend fun clearPortraitCache() {
        retryBackoffUntil.clear()
        portraitCacheDao.clearAll()
    }

    private fun isValidPortraitUrl(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val lower = url.lowercase()
        return !lower.contains("default.jpg") &&
            !lower.contains("default.png") &&
            !lower.contains("questionmark") &&
            !lower.contains("apple-touch-icon") &&
            !lower.contains("noimage")
    }

    private fun universeKeywords(universe: AnimeUniverse): List<String> = when (universe) {
        AnimeUniverse.NARUTO -> listOf("naruto", "boruto", "shippuden")
        AnimeUniverse.ONE_PIECE -> listOf("one piece")
        AnimeUniverse.BLEACH -> listOf("bleach")
        AnimeUniverse.DRAGON_BALL -> listOf("dragon ball")
        AnimeUniverse.JUJUTSU_KAISEN -> listOf("jujutsu kaisen")
        AnimeUniverse.DEMON_SLAYER -> listOf("kimetsu", "demon slayer")
        AnimeUniverse.ATTACK_ON_TITAN -> listOf("shingeki", "attack on titan")
        AnimeUniverse.HUNTER_X_HUNTER -> listOf("hunter x hunter", "hunter × hunter")
        AnimeUniverse.SOLO_LEVELING -> listOf("solo leveling", "na honjaman", "level up")
    }

    private fun pickBestAniListImage(
        candidates: List<AniListCharacterDto>,
        universe: AnimeUniverse
    ): String? {
        val validCandidates = candidates.mapNotNull { dto ->
            val img = dto.image?.large?.takeIf(::isValidPortraitUrl)
                ?: dto.image?.medium?.takeIf(::isValidPortraitUrl)
            if (img != null) dto to img else null
        }
        if (validCandidates.isEmpty()) return null

        val keywords = universeKeywords(universe)
        val universeMatched = validCandidates.firstOrNull { (dto, _) ->
            val titles = dto.media?.nodes.orEmpty().flatMap { node ->
                listOfNotNull(node.title?.romaji, node.title?.english)
            }
            titles.any { title ->
                val lowerTitle = title.lowercase()
                keywords.any { kw -> lowerTitle.contains(kw) }
            }
        }
        return (universeMatched ?: validCandidates.first()).second
    }

    private fun cleanSearchQuery(character: Character): String {
        return when (character.id) {
            "shanks" -> "Shanks"
            "piccolo" -> "Piccolo"
            "sung_jinwoo" -> "Jin-Woo Sung"
            "igris" -> "Igris"
            "beru" -> "Beru"
            "cha_hae_in" -> "Hae-In Cha"
            "genryusai_yamamoto" -> "Genryusai Yamamoto"
            "pain_nagato" -> "Nagato"
            "whitebeard" -> "Edward Newgate"
            "crocodile" -> "Crocodile"
            "kite" -> "Kite"
            "razor" -> "Razor"
            "broly" -> "Broly"
            "future_trunks" -> "Trunks"
            "hit" -> "Hit"
            "cell" -> "Cell"
            "tusk" -> "Kargalgan"
            "tank" -> "Tank"
            "bellion" -> "Bellion"
            "go_gunhee" -> "Gun-Hee Go"
            "antares" -> "Antares"
            "ymir_fritz" -> "Ymir Fritz"
            "raikage_a" -> "A"
            "toppo" -> "Toppo"
            "zamasu" -> "Zamasu"
            "eren_kruger" -> "Eren Kruger"
            "kokichi_muta" -> "Kokichi Muta"
            "iron_shadow" -> "Chul Kim"
            "greed_shadow" -> "Dong-Soo Hwang"
            "alluka_zoldyck" -> "Alluka Zoldyck"
            else -> character.malQuery
                .replace(Regex("\\s*\\([^)]*\\)"), "")
                .trim()
        }
    }

    private suspend fun queryAniList(query: String, universe: AnimeUniverse): String? {
        return runCatching {
            aniListMutex.withLock {
                val elapsed = System.currentTimeMillis() - lastAniListMillis
                if (elapsed < 170L) delay(170L - elapsed)
                lastAniListMillis = System.currentTimeMillis()

                val resp = aniListApi.searchCharacter(
                    AniListGraphQlRequest(
                        query = AniListApiService.SEARCH_CHARACTER_QUERY,
                        variables = mapOf("search" to query)
                    )
                )
                pickBestAniListImage(resp.data?.page?.characters.orEmpty(), universe)
            }
        }.getOrNull()
    }

    private suspend fun queryJikan(query: String): String? {
        return runCatching {
            jikanMutex.withLock {
                val elapsed = System.currentTimeMillis() - lastJikanMillis
                if (elapsed < 380L) delay(380L - elapsed)
                lastJikanMillis = System.currentTimeMillis()

                val response = jikanApi.searchCharacter(query = query, limit = 5)
                response.data.firstNotNullOfOrNull { dto ->
                    dto.images?.jpg?.imageUrl?.takeIf(::isValidPortraitUrl)
                        ?: dto.images?.webp?.imageUrl?.takeIf(::isValidPortraitUrl)
                }
            }
        }.getOrNull()
    }

    suspend fun resolveCharacterPortrait(character: Character): String? {
        if (isValidPortraitUrl(character.portraitUrl)) return character.portraitUrl

        val cached = portraitCacheDao.getPortraitUrl(character.id)
        if (isValidPortraitUrl(cached)) return cached

        val now = System.currentTimeMillis()
        val backoff = retryBackoffUntil[character.id] ?: 0L
        if (now < backoff) return null

        if (inFlightQueries.putIfAbsent(character.id, true) != null) {
            return null
        }

        return try {
            val primaryQuery = cleanSearchQuery(character)
            var resolvedUrl = queryAniList(primaryQuery, character.universe)

            // Retry AniList with simplified first/last token if multi-word query failed
            if (!isValidPortraitUrl(resolvedUrl) && primaryQuery.contains(" ")) {
                val simplified = primaryQuery.split(" ").lastOrNull { it.length >= 3 }
                if (!simplified.isNullOrBlank() && simplified != primaryQuery) {
                    resolvedUrl = queryAniList(simplified, character.universe)
                }
            }

            // Fallback to Jikan v4 MyAnimeList API
            if (!isValidPortraitUrl(resolvedUrl)) {
                resolvedUrl = queryJikan(primaryQuery)
            }

            if (isValidPortraitUrl(resolvedUrl)) {
                val cleanUrl = resolvedUrl!!
                portraitCacheDao.upsertPortrait(
                    PortraitCacheEntity(
                        characterId = character.id,
                        imageUrl = cleanUrl
                    )
                )
                cleanUrl
            } else {
                retryBackoffUntil[character.id] = System.currentTimeMillis() + 8_000L
                null
            }
        } catch (_: Exception) {
            retryBackoffUntil[character.id] = System.currentTimeMillis() + 6_000L
            null
        } finally {
            inFlightQueries.remove(character.id)
        }
    }
}
