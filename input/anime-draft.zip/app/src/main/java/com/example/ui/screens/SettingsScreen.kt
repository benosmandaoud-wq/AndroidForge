package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.UiText
import com.example.model.ComparisonMode
import com.example.model.GameSettings
import com.example.model.Language
import com.example.ui.theme.GoldPrimary

@Composable
fun SettingsScreen(
    settings: GameSettings,
    cachedPortraitCount: Int,
    onSelectLanguage: (Language) -> Unit,
    onUpdatePlayerNames: (String, String) -> Unit,
    onSelectComparisonMode: (ComparisonMode) -> Unit,
    onSelectTeamSize: (Int) -> Unit,
    onToggleDarkTheme: (Boolean) -> Unit,
    onClearPortraitCache: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = settings.language
    var p1Draft by remember(settings.player1Name) { mutableStateOf(settings.player1Name) }
    var p2Draft by remember(settings.player2Name) { mutableStateOf(settings.player2Name) }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Default Player Names
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Person, contentDescription = null, tint = GoldPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (lang == Language.AR) "أسماء اللاعبين الافتراضية" else "Default Player Names",
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = p1Draft,
                                onValueChange = {
                                    p1Draft = it
                                    onUpdatePlayerNames(it, p2Draft)
                                },
                                label = { Text(UiText.player1Label.get(lang)) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = p2Draft,
                                onValueChange = {
                                    p2Draft = it
                                    onUpdatePlayerNames(p1Draft, it)
                                },
                                label = { Text(UiText.player2Label.get(lang)) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Language
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Language, contentDescription = null, tint = GoldPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(UiText.languageTitle.get(lang), style = MaterialTheme.typography.titleMedium)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Language.entries.forEach { itemLang ->
                                FilterChip(
                                    selected = settings.language == itemLang,
                                    onClick = { onSelectLanguage(itemLang) },
                                    label = { Text(itemLang.label) },
                                    modifier = Modifier.testTag("lang_chip_${itemLang.code}")
                                )
                            }
                        }
                    }
                }
            }

            // Theme Appearance
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.DarkMode, contentDescription = null, tint = GoldPrimary)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(UiText.themeTitle.get(lang), style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = if (settings.darkTheme) UiText.darkModeLabel.get(lang) else UiText.lightModeLabel.get(lang),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = settings.darkTheme,
                            onCheckedChange = onToggleDarkTheme,
                            modifier = Modifier.testTag("theme_switch")
                        )
                    }
                }
            }

            // Default Draft Settings
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(UiText.roundsAndTeamLabel.get(lang), style = MaterialTheme.typography.titleSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(3, 5, 8, 10).forEach { size ->
                                FilterChip(
                                    selected = settings.defaultTeamSize == size,
                                    onClick = { onSelectTeamSize(size) },
                                    label = { Text("$size") }
                                )
                            }
                        }

                        Text(UiText.comparisonModeLabel.get(lang), style = MaterialTheme.typography.titleSmall)
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ComparisonMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = settings.defaultComparisonMode == mode,
                                    onClick = { onSelectComparisonMode(mode) },
                                    label = { Text(mode.label.get(lang)) }
                                )
                            }
                        }
                    }
                }
            }

            // Portrait Cache
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Cached, contentDescription = null, tint = GoldPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(UiText.portraitCacheTitle.get(lang), style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            text = if (lang == Language.AR) {
                                "عدد الصور المخزنة محلياً: $cachedPortraitCount"
                            } else {
                                "Cached character portraits: $cachedPortraitCount"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(
                            onClick = onClearPortraitCache,
                            modifier = Modifier.testTag("clear_portrait_cache_button")
                        ) {
                            Text(UiText.clearCacheBtn.get(lang))
                        }
                    }
                }
            }
        }
    }
}
