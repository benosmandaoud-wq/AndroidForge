package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.QuestionMark
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.UiText
import com.example.model.Character
import com.example.model.DraftCardSlot
import com.example.model.DraftState
import com.example.model.Language
import com.example.model.PlayerKey
import com.example.model.RoundHistoryEntry
import com.example.model.RoundPhase
import com.example.ui.components.CharacterPortrait
import com.example.ui.components.PowerCategoryPill
import com.example.ui.components.TierBadge
import com.example.ui.theme.CrimsonTertiary
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldWin
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.VioletHax

@Composable
fun DraftScreen(
    draftState: DraftState?,
    language: Language,
    portraitUrls: Map<String, String>,
    onRequestPortrait: (Character) -> Unit,
    onSelectCard: (Int) -> Unit,
    onAdvanceRound: () -> Unit,
    onRestartDraft: () -> Unit,
    onCompareTeams: () -> Unit,
    onStartDefaultDraft: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (draftState == null) {
        Box(
            modifier = modifier.fillMaxSize().padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.widthIn(max = 420.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(44.dp)
                    )
                    Text(
                        text = if (language == Language.AR) "لا يوجد درافت نشط" else "No Active Draft",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Text(
                        text = if (language == Language.AR) {
                            "ابدأ درافت ثنائي بين داود ومنصف الآن."
                        } else {
                            "Launch a 2-player blind & visible draft between Daoud and Monsef."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Button(
                        onClick = onStartDefaultDraft,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.testTag("quick_start_draft_button")
                    ) {
                        Text(UiText.startTwoPlayerDraft.get(language))
                    }
                }
            }
        }
        return
    }

    if (draftState.isComplete) {
        CompletedDraftSummary(
            draftState = draftState,
            language = language,
            portraitUrls = portraitUrls,
            onRequestPortrait = onRequestPortrait,
            onCompareTeams = onCompareTeams,
            onRestartDraft = onRestartDraft,
            modifier = modifier
        )
        return
    }

    var showHistoryDialog by remember { mutableStateOf(false) }

    if (showHistoryDialog) {
        RoundHistoryDialog(
            draftState = draftState,
            language = language,
            onDismiss = { showHistoryDialog = false }
        )
    }

    val activePlayerName = if (draftState.activePlayer == PlayerKey.PLAYER_1) {
        draftState.player1Name
    } else {
        draftState.player2Name
    }
    val starterName = if (draftState.startingPlayer == PlayerKey.PLAYER_1) {
        draftState.player1Name
    } else {
        draftState.player2Name
    }
    val activeAccent = if (draftState.activePlayer == PlayerKey.PLAYER_1) GoldPrimary else CyanSecondary
    val progress = (draftState.team1.size.toFloat() / draftState.totalRounds.coerceAtLeast(1)).coerceIn(0f, 1f)

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 980.dp)
        ) {
            // ==================== TOP BAR: ROUND, PROGRESS, ACTIVE PLAYER ====================
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerHighest
                            ) {
                                Text(
                                    text = "${UiText.roundPrefix.get(language)} ${draftState.currentRound} / ${draftState.totalRounds}",
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = activeAccent.copy(alpha = 0.18f),
                                border = BorderStroke(1.dp, activeAccent)
                            ) {
                                Text(
                                    text = if (draftState.phase == RoundPhase.ROUND_REVEAL) {
                                        if (language == Language.AR) "كشف البطاقات!" else "ROUND REVEAL"
                                    } else {
                                        if (language == Language.AR) "دور $activePlayerName" else "$activePlayerName's Turn"
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    color = activeAccent,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { showHistoryDialog = true },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("draft_history_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.History,
                                    contentDescription = UiText.roundHistoryTitle.get(language)
                                )
                            }
                            IconButton(
                                onClick = onRestartDraft,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("draft_restart_icon")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = UiText.restartDraftBtn.get(language)
                                )
                            }
                        }
                    }

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape),
                        color = activeAccent,
                        trackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                    )

                    Text(
                        text = when (draftState.phase) {
                            RoundPhase.PICK_INITIAL -> if (language == Language.AR) {
                                "يبدأ $starterName هذه الجولة: اختر البطاقة المكشوفة أو إحدى البطاقتين المخفيتين."
                            } else {
                                "$starterName starts: Pick the Visible card OR choose a Hidden (?) card."
                            }

                            RoundPhase.OPPONENT_PICK_HIDDEN -> if (language == Language.AR) {
                                "القاعدة أ: $starterName اختار المكشوفة — $activePlayerName اختر إحدى البطاقتين المخفيتين."
                            } else {
                                "Rule A: $starterName took Visible — $activePlayerName, pick 1 of the 2 Hidden (?) cards."
                            }

                            RoundPhase.ROUND_REVEAL -> if (language == Language.AR) {
                                "تم تحديث الفريقين! جاري الانتقال للجولة التالية..."
                            } else {
                                "Both picks locked & teams updated! Proceeding to next round..."
                            }
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // ==================== BODY: LEFT (P1) | CENTER (3 CARDS) | RIGHT (P2) ====================
            BoxWithConstraints(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 10.dp)
            ) {
                val isWide = maxWidth >= 600.dp
                val sideWidth = if (isWide) 142.dp else 72.dp

                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // LEFT: Player 1 (Daoud) Team Rail
                    TeamSideRail(
                        playerName = draftState.player1Name,
                        team = draftState.team1,
                        totalRounds = draftState.totalRounds,
                        accent = GoldPrimary,
                        isActive = draftState.activePlayer == PlayerKey.PLAYER_1 && draftState.phase != RoundPhase.ROUND_REVEAL,
                        showNames = isWide,
                        language = language,
                        portraitUrls = portraitUrls,
                        onRequestPortrait = onRequestPortrait,
                        modifier = Modifier
                            .width(sideWidth)
                            .fillMaxHeight()
                    )

                    // CENTER: Three Draft Cards
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val visibleSlot = draftState.currentCards.firstOrNull { it.isVisibleInitial }
                        val hiddenSlots = draftState.currentCards.filter { !it.isVisibleInitial }

                        if (isWide) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                draftState.currentCards.forEach { slot ->
                                    DraftRoundCard(
                                        slot = slot,
                                        phase = draftState.phase,
                                        player1Name = draftState.player1Name,
                                        player2Name = draftState.player2Name,
                                        language = language,
                                        portraitUrls = portraitUrls,
                                        onRequestPortrait = onRequestPortrait,
                                        onSelect = { onSelectCard(slot.slotIndex) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        } else {
                            // Mobile Portrait: Prominent Visible Card on Top + 2 Hidden Cards Side-by-Side
                            if (visibleSlot != null) {
                                DraftRoundCard(
                                    slot = visibleSlot,
                                    phase = draftState.phase,
                                    player1Name = draftState.player1Name,
                                    player2Name = draftState.player2Name,
                                    language = language,
                                    portraitUrls = portraitUrls,
                                    onRequestPortrait = onRequestPortrait,
                                    onSelect = { onSelectCard(visibleSlot.slotIndex) },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                hiddenSlots.forEach { slot ->
                                    DraftRoundCard(
                                        slot = slot,
                                        phase = draftState.phase,
                                        player1Name = draftState.player1Name,
                                        player2Name = draftState.player2Name,
                                        language = language,
                                        portraitUrls = portraitUrls,
                                        onRequestPortrait = onRequestPortrait,
                                        onSelect = { onSelectCard(slot.slotIndex) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }

                        // Reveal Banner with instant Next button alongside auto-advance
                        AnimatedVisibility(
                            visible = draftState.phase == RoundPhase.ROUND_REVEAL,
                            enter = fadeIn() + scaleIn(initialScale = 0.92f),
                            exit = fadeOut()
                        ) {
                            val latest = draftState.history.lastOrNull()
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = EmeraldWin.copy(alpha = 0.14f),
                                border = BorderStroke(1.dp, EmeraldWin.copy(alpha = 0.55f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    if (latest != null) {
                                        Text(
                                            text = "${draftState.player1Name}: ${latest.player1Pick.name.get(language)}  •  ${draftState.player2Name}: ${latest.player2Pick.name.get(language)}",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = EmeraldWin,
                                            textAlign = TextAlign.Center
                                        )
                                        Text(
                                            text = "${UiText.discardedBadge.get(language)}: ${latest.discardedCharacter.name.get(language)}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    TextButton(
                                        onClick = onAdvanceRound,
                                        modifier = Modifier.testTag("next_round_button")
                                    ) {
                                        Text(
                                            text = if (draftState.currentRound >= draftState.totalRounds) {
                                                if (language == Language.AR) "إنهاء وعرض الفرق" else "Finish Draft Now"
                                            } else {
                                                if (language == Language.AR) "الجولة التالية" else "Next Round Now"
                                            },
                                            color = EmeraldWin
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                            contentDescription = null,
                                            tint = EmeraldWin,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // RIGHT: Player 2 (Monsef) Team Rail
                    TeamSideRail(
                        playerName = draftState.player2Name,
                        team = draftState.team2,
                        totalRounds = draftState.totalRounds,
                        accent = CyanSecondary,
                        isActive = draftState.activePlayer == PlayerKey.PLAYER_2 && draftState.phase != RoundPhase.ROUND_REVEAL,
                        showNames = isWide,
                        language = language,
                        portraitUrls = portraitUrls,
                        onRequestPortrait = onRequestPortrait,
                        modifier = Modifier
                            .width(sideWidth)
                            .fillMaxHeight()
                    )
                }
            }
        }
    }
}

@Composable
private fun TeamSideRail(
    playerName: String,
    team: List<Character>,
    totalRounds: Int,
    accent: Color,
    isActive: Boolean,
    showNames: Boolean,
    language: Language,
    portraitUrls: Map<String, String>,
    onRequestPortrait: (Character) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(
            width = if (isActive) 2.dp else 1.dp,
            color = if (isActive) accent else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = playerName,
                style = MaterialTheme.typography.labelLarge,
                color = accent,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = accent.copy(alpha = 0.16f)
            ) {
                Text(
                    text = "${team.size}/$totalRounds",
                    style = MaterialTheme.typography.labelMedium,
                    color = accent,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                itemsIndexed(team, key = { idx, c -> "${c.id}_$idx" }) { _, member ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        CharacterPortrait(
                            character = member,
                            portraitUrl = portraitUrls[member.id],
                            onRequestPortrait = onRequestPortrait,
                            size = if (showNames) 54.dp else 46.dp,
                            borderColor = accent
                        )
                        if (showNames) {
                            Text(
                                text = member.name.get(language),
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DraftRoundCard(
    slot: DraftCardSlot,
    phase: RoundPhase,
    player1Name: String,
    player2Name: String,
    language: Language,
    portraitUrls: Map<String, String>,
    onRequestPortrait: (Character) -> Unit,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    val canSelect = when (phase) {
        RoundPhase.PICK_INITIAL -> true
        RoundPhase.OPPONENT_PICK_HIDDEN -> !slot.isVisibleInitial && slot.claimedBy == null
        RoundPhase.ROUND_REVEAL -> false
    }

    val targetScale = if (slot.claimedBy != null) 1.02f else 1f
    val animatedScale by animateFloatAsState(
        targetValue = targetScale,
        animationSpec = spring(dampingRatio = 0.7f),
        label = "card_scale"
    )

    val borderColor = when {
        slot.claimedBy == PlayerKey.PLAYER_1 -> GoldPrimary
        slot.claimedBy == PlayerKey.PLAYER_2 -> CyanSecondary
        slot.isDiscarded -> CrimsonTertiary.copy(alpha = 0.7f)
        slot.isVisibleInitial -> GoldPrimary.copy(alpha = 0.65f)
        else -> VioletHax.copy(alpha = 0.65f)
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.5.dp, borderColor),
        modifier = modifier
            .scale(animatedScale)
            .clickable(enabled = canSelect, onClick = onSelect)
            .testTag("draft_slot_${slot.slotIndex}")
    ) {
        AnimatedContent(
            targetState = slot.isRevealed,
            transitionSpec = { (fadeIn() + scaleIn(initialScale = 0.9f)) togetherWith fadeOut() },
            label = "card_reveal"
        ) { revealed ->
            if (!revealed) {
                // HIDDEN CARD: Question mark ONLY — NO name, NO portrait, NO abilities!
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(186.dp)
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    VioletHax.copy(alpha = 0.16f),
                                    MaterialTheme.colorScheme.surfaceVariant
                                )
                            )
                        )
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = VioletHax.copy(alpha = 0.2f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.VisibilityOff,
                                contentDescription = null,
                                tint = VioletHax,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = UiText.hiddenCardBadge.get(language),
                                style = MaterialTheme.typography.labelSmall,
                                color = VioletHax
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(VioletHax.copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.QuestionMark,
                            contentDescription = UiText.hiddenCardBadge.get(language),
                            tint = VioletHax,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Text(
                        text = if (language == Language.AR) "اضغط للاختيار" else "Tap to Pick",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                // VISIBLE / REVEALED CARD
                val ch = slot.character
                val statusText = when {
                    slot.claimedBy == PlayerKey.PLAYER_1 -> player1Name
                    slot.claimedBy == PlayerKey.PLAYER_2 -> player2Name
                    slot.isDiscarded -> UiText.discardedBadge.get(language)
                    else -> UiText.visibleCardBadge.get(language)
                }
                val statusColor = when {
                    slot.claimedBy == PlayerKey.PLAYER_1 -> GoldPrimary
                    slot.claimedBy == PlayerKey.PLAYER_2 -> CyanSecondary
                    slot.isDiscarded -> CrimsonTertiary
                    else -> GoldPrimary
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = statusColor.copy(alpha = 0.2f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Visibility,
                                    contentDescription = null,
                                    tint = statusColor,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = statusText,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = statusColor,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        TierBadge(tier = ch.tier)
                    }

                    CharacterPortrait(
                        character = ch,
                        portraitUrl = portraitUrls[ch.id],
                        onRequestPortrait = onRequestPortrait,
                        size = 74.dp,
                        borderColor = statusColor
                    )

                    Text(
                        text = ch.name.get(language),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "${ch.universe.title.get(language)} • ${ch.type.label.get(language)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    PowerCategoryPill(category = ch.powerCategory, language = language)
                }
            }
        }
    }
}

@Composable
private fun CompletedDraftSummary(
    draftState: DraftState,
    language: Language,
    portraitUrls: Map<String, String>,
    onRequestPortrait: (Character) -> Unit,
    onCompareTeams: () -> Unit,
    onRestartDraft: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 900.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = EmeraldWin.copy(alpha = 0.14f)),
                    border = BorderStroke(1.5.dp, EmeraldWin.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.EmojiEvents,
                            contentDescription = null,
                            tint = EmeraldWin,
                            modifier = Modifier.size(38.dp)
                        )
                        Text(
                            text = UiText.draftCompleteTitle.get(language),
                            style = MaterialTheme.typography.headlineMedium,
                            color = EmeraldWin
                        )
                        Text(
                            text = "${draftState.player1Name} (${draftState.team1.size}) vs ${draftState.player2Name} (${draftState.team2.size}) • ${draftState.totalRounds} ${UiText.roundPrefix.get(language)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Primary Action: Compare Teams + Restart Draft
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onCompareTeams,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("compare_teams_button")
                    ) {
                        Icon(Icons.Filled.CompareArrows, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = UiText.compareTeamsBtn.get(language),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = onRestartDraft,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .height(54.dp)
                            .testTag("restart_draft_button")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(UiText.restartDraftBtn.get(language))
                    }
                }
            }

            // Team 1 Complete Roster
            item {
                CompletedTeamCard(
                    playerName = draftState.player1Name,
                    team = draftState.team1,
                    accent = GoldPrimary,
                    language = language,
                    portraitUrls = portraitUrls,
                    onRequestPortrait = onRequestPortrait
                )
            }

            // Team 2 Complete Roster
            item {
                CompletedTeamCard(
                    playerName = draftState.player2Name,
                    team = draftState.team2,
                    accent = CyanSecondary,
                    language = language,
                    portraitUrls = portraitUrls,
                    onRequestPortrait = onRequestPortrait
                )
            }

            // Final Draft History
            item {
                Text(
                    text = UiText.roundHistoryTitle.get(language),
                    style = MaterialTheme.typography.titleLarge
                )
            }

            items(draftState.history, key = { it.roundNumber }) { entry ->
                RoundHistoryCard(
                    entry = entry,
                    player1Name = draftState.player1Name,
                    player2Name = draftState.player2Name,
                    language = language
                )
            }
        }
    }
}

@Composable
private fun CompletedTeamCard(
    playerName: String,
    team: List<Character>,
    accent: Color,
    language: Language,
    portraitUrls: Map<String, String>,
    onRequestPortrait: (Character) -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(playerName, style = MaterialTheme.typography.titleMedium, color = accent)
                Text("${team.size}", style = MaterialTheme.typography.labelMedium, color = accent)
            }

            team.forEach { member ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CharacterPortrait(
                            character = member,
                            portraitUrl = portraitUrls[member.id],
                            onRequestPortrait = onRequestPortrait,
                            size = 46.dp,
                            borderColor = accent
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(member.name.get(language), style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "${member.universe.title.get(language)} • ${member.type.label.get(language)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        TierBadge(member.tier)
                    }
                }
            }
        }
    }
}

@Composable
fun RoundHistoryCard(
    entry: RoundHistoryEntry,
    player1Name: String,
    player2Name: String,
    language: Language
) {
    val starterName = if (entry.startingPlayer == PlayerKey.PLAYER_1) player1Name else player2Name
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${UiText.roundPrefix.get(language)} ${entry.roundNumber} • ${if (language == Language.AR) "بدأ:" else "Starter:"} $starterName",
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = entry.ruleApplied.replace("_", " "),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = if (language == Language.AR) {
                    "المتاحة: ${entry.offeredCharacters.joinToString(" • ") { it.name.get(language) }}"
                } else {
                    "Offered: ${entry.offeredCharacters.joinToString(" • ") { it.name.get(language) }}"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "$player1Name: ${entry.player1Pick.name.get(language)}",
                style = MaterialTheme.typography.bodyMedium,
                color = GoldPrimary
            )
            Text(
                text = "$player2Name: ${entry.player2Pick.name.get(language)}",
                style = MaterialTheme.typography.bodyMedium,
                color = CyanSecondary
            )
            Text(
                text = "${UiText.discardedBadge.get(language)}: ${entry.discardedCharacter.name.get(language)}",
                style = MaterialTheme.typography.bodyMedium,
                color = CrimsonTertiary
            )
        }
    }
}

@Composable
private fun RoundHistoryDialog(
    draftState: DraftState,
    language: Language,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (language == Language.AR) "إغلاق" else "Close")
            }
        },
        title = {
            Text(UiText.roundHistoryTitle.get(language), style = MaterialTheme.typography.titleLarge)
        },
        text = {
            if (draftState.history.isEmpty()) {
                Text(
                    text = if (language == Language.AR) "لم تكتمل أي جولة بعد." else "No completed rounds yet.",
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                LazyColumn(
                    modifier = Modifier.height(360.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(draftState.history.reversed(), key = { it.roundNumber }) { entry ->
                        RoundHistoryCard(
                            entry = entry,
                            player1Name = draftState.player1Name,
                            player2Name = draftState.player2Name,
                            language = language
                        )
                    }
                }
            }
        }
    )
}
