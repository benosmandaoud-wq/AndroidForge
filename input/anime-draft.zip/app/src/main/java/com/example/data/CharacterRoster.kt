package com.example.data

import com.example.model.AnimeUniverse
import com.example.model.Character
import com.example.model.CharacterStats
import com.example.model.CharacterType
import com.example.model.LocalizedText
import com.example.model.PowerCategory

object CharacterRoster {
    private val baseCharacters: List<Character> = listOf(
        // ==================== NARUTO ====================
        Character(
            id = "naruto_uzumaki",
            name = LocalizedText("Naruto Uzumaki", "ناروتو أوزوماكي"),
            universe = AnimeUniverse.NARUTO,
            type = CharacterType.ALL_ROUNDER,
            powerCategory = PowerCategory.ENERGY,
            tier = "S+",
            stats = CharacterStats(offense = 93, defense = 89, speed = 92, intelligence = 76, versatility = 94, aura = 96),
            signatureMove = LocalizedText("Baryon Rasenshuriken", "راسن شوريكن الباريون"),
            tacticalTrait = LocalizedText("Unmatched stamina & shadow clone flanking pressure", "طاقة لا تنضب وضغط هجومي بنسخ الظل"),
            malQuery = "Naruto Uzumaki"
        ),
        Character(
            id = "sasuke_uchiha",
            name = LocalizedText("Sasuke Uchiha", "ساسكي أوتشيها"),
            universe = AnimeUniverse.NARUTO,
            type = CharacterType.ASSASSIN,
            powerCategory = PowerCategory.HAX,
            tier = "S+",
            stats = CharacterStats(offense = 92, defense = 82, speed = 95, intelligence = 91, versatility = 93, aura = 90),
            signatureMove = LocalizedText("Amenotejikara & Indra Arrow", "أمينوتيجيكارا وسهم إندرا"),
            tacticalTrait = LocalizedText("Instant space-swap positioning & Rinnegan counters", "تبديل مكاني فوري ومضادات الرينغان"),
            malQuery = "Sasuke Uchiha"
        ),
        Character(
            id = "itachi_uchiha",
            name = LocalizedText("Itachi Uchiha", "إيتاتشي أوتشيها"),
            universe = AnimeUniverse.NARUTO,
            type = CharacterType.STRATEGIST,
            powerCategory = PowerCategory.HAX,
            tier = "S",
            stats = CharacterStats(offense = 84, defense = 86, speed = 88, intelligence = 98, versatility = 90, aura = 94),
            signatureMove = LocalizedText("Tsukuyomi & Yata Mirror", "تسوكويومي ومرآة ياتا"),
            tacticalTrait = LocalizedText("Disrupts enemy tempo with genjutsu & spiritual shields", "يربك إيقاع الخصم بالوهم ودروع السوسانو"),
            malQuery = "Itachi Uchiha"
        ),
        Character(
            id = "madara_uchiha",
            name = LocalizedText("Madara Uchiha", "مادارا أوتشيها"),
            universe = AnimeUniverse.NARUTO,
            type = CharacterType.STRIKER,
            powerCategory = PowerCategory.ELEMENTAL,
            tier = "S+",
            stats = CharacterStats(offense = 96, defense = 90, speed = 89, intelligence = 93, versatility = 91, aura = 98),
            signatureMove = LocalizedText("Tengai Shinsei & Limbo", "تينغاي شينسي والليمبو"),
            tacticalTrait = LocalizedText("Overwhelms multi-target formations with meteoric AoE", "يسحق التشكيلات المتعددة بهجمات واسعة المدى"),
            malQuery = "Madara Uchiha"
        ),

        // ==================== ONE PIECE ====================
        Character(
            id = "monkey_d_luffy",
            name = LocalizedText("Monkey D. Luffy", "مونكي دي لوفي"),
            universe = AnimeUniverse.ONE_PIECE,
            type = CharacterType.STRIKER,
            powerCategory = PowerCategory.PHYSICAL,
            tier = "S+",
            stats = CharacterStats(offense = 95, defense = 91, speed = 93, intelligence = 74, versatility = 95, aura = 97),
            signatureMove = LocalizedText("Gear 5: Bajrang Gun", "الجير الخامس: مدفع باجرانغ"),
            tacticalTrait = LocalizedText("Toon-physics rubber manipulation turns terrain into weapons", "مرونة مطاطية تحوّل ساحة القتال إلى سلاح"),
            malQuery = "Monkey D. Luffy"
        ),
        Character(
            id = "roronoa_zoro",
            name = LocalizedText("Roronoa Zoro", "رورونوا زورو"),
            universe = AnimeUniverse.ONE_PIECE,
            type = CharacterType.STRIKER,
            powerCategory = PowerCategory.PHYSICAL,
            tier = "S",
            stats = CharacterStats(offense = 94, defense = 88, speed = 86, intelligence = 75, versatility = 80, aura = 93),
            signatureMove = LocalizedText("King of Hell: Three-Sword Dragon", "ملك الجحيم: تنين السيوف الثلاثة"),
            tacticalTrait = LocalizedText("Armor-piercing Conqueror slashes break tank defenses", "ضربات هاكي ملكية تخترق أعتى الدروع"),
            malQuery = "Roronoa Zoro"
        ),
        Character(
            id = "trafalgar_law",
            name = LocalizedText("Trafalgar D. Law", "ترافالغار لو"),
            universe = AnimeUniverse.ONE_PIECE,
            type = CharacterType.SUPPORT,
            powerCategory = PowerCategory.HAX,
            tier = "S",
            stats = CharacterStats(offense = 85, defense = 78, speed = 84, intelligence = 95, versatility = 96, aura = 86),
            signatureMove = LocalizedText("K-Room: Puncture Wille", "غرفة العمليات: اختراق ويلي"),
            tacticalTrait = LocalizedText("Spatial teleportation & internal bypass amplify ally combos", "انتقال مكاني وتجاوز الدفاعات لتعزيز هجمات الحلفاء"),
            malQuery = "Trafalgar Law"
        ),
        Character(
            id = "shanks",
            name = LocalizedText("Red-Haired Shanks", "شانكس ذو الشعر الأحمر"),
            universe = AnimeUniverse.ONE_PIECE,
            type = CharacterType.ALL_ROUNDER,
            powerCategory = PowerCategory.SPIRITUAL,
            tier = "S+",
            stats = CharacterStats(offense = 95, defense = 86, speed = 94, intelligence = 92, versatility = 88, aura = 99),
            signatureMove = LocalizedText("Divine Departure", "الرحيل الإلهي"),
            tacticalTrait = LocalizedText("Observation killing & supreme Conqueror Haki pressure", "إلغاء استشعار الخصم وضغط هاكي مهيمن"),
            malQuery = "Shanks One Piece"
        ),

        // ==================== BLEACH ====================
        Character(
            id = "ichigo_kurosaki",
            name = LocalizedText("Ichigo Kurosaki", "إيتشيغو كوروساكي"),
            universe = AnimeUniverse.BLEACH,
            type = CharacterType.STRIKER,
            powerCategory = PowerCategory.SPIRITUAL,
            tier = "S+",
            stats = CharacterStats(offense = 96, defense = 88, speed = 96, intelligence = 79, versatility = 87, aura = 96),
            signatureMove = LocalizedText("True Bankai: Getsuga Tensho", "بانكاي حقيقي: غيتسوغا تينشو"),
            tacticalTrait = LocalizedText("Blistering shunpo burst & hybrid reiatsu durability", "اندفاع سرعة فائق وقدرة تحمل هجينة"),
            malQuery = "Ichigo Kurosaki"
        ),
        Character(
            id = "sosuke_aizen",
            name = LocalizedText("Sosuke Aizen", "سوسكي آيزن"),
            universe = AnimeUniverse.BLEACH,
            type = CharacterType.STRATEGIST,
            powerCategory = PowerCategory.HAX,
            tier = "S+",
            stats = CharacterStats(offense = 91, defense = 94, speed = 89, intelligence = 99, versatility = 94, aura = 97),
            signatureMove = LocalizedText("Kyoka Suigetsu & Kurohitsugi", "كيوكا سويغيتسو والتعويذة 90"),
            tacticalTrait = LocalizedText("Complete sensory hypnosis controls every opening", "تنويم حسي كامل يتحكم في مجريات الاشتباك"),
            malQuery = "Sosuke Aizen"
        ),
        Character(
            id = "genryusai_yamamoto",
            name = LocalizedText("Genryusai Yamamoto", "جينريوساي ياماموتو"),
            universe = AnimeUniverse.BLEACH,
            type = CharacterType.TANK,
            powerCategory = PowerCategory.ELEMENTAL,
            tier = "S+",
            stats = CharacterStats(offense = 97, defense = 92, speed = 85, intelligence = 90, versatility = 86, aura = 96),
            signatureMove = LocalizedText("Zanka no Tachi", "زانكا نو تاتشي"),
            tacticalTrait = LocalizedText("Sun-core flame cloak vaporizes incoming projectiles", "درع لهب شمسي يبخر الهجمات المقتربة"),
            malQuery = "Genryusai Shigekuni Yamamoto"
        ),
        Character(
            id = "kenpachi_zaraki",
            name = LocalizedText("Kenpachi Zaraki", "كينباتشي زاراكي"),
            universe = AnimeUniverse.BLEACH,
            type = CharacterType.TANK,
            powerCategory = PowerCategory.PHYSICAL,
            tier = "S",
            stats = CharacterStats(offense = 96, defense = 93, speed = 83, intelligence = 65, versatility = 72, aura = 95),
            signatureMove = LocalizedText("Nozarashi Bankai Cleave", "ضربة بانكاي نوزاراشي"),
            tacticalTrait = LocalizedText("Unstoppable berserker poise shrugs off fatal strikes", "صلابة قتالية لا تتراجع أمام الضربات القاضية"),
            malQuery = "Kenpachi Zaraki"
        ),

        // ==================== DRAGON BALL ====================
        Character(
            id = "son_goku",
            name = LocalizedText("Son Goku", "سون غوكو"),
            universe = AnimeUniverse.DRAGON_BALL,
            type = CharacterType.ALL_ROUNDER,
            powerCategory = PowerCategory.ENERGY,
            tier = "S+",
            stats = CharacterStats(offense = 98, defense = 93, speed = 98, intelligence = 82, versatility = 92, aura = 99),
            signatureMove = LocalizedText("Mastered Ultra Instinct", "الغريزة الفائقة المتقنة"),
            tacticalTrait = LocalizedText("Autonomous dodge & escalating combat adaptation", "تفادٍ تلقائي وتكيّف قتالي متصاعد"),
            malQuery = "Son Goku"
        ),
        Character(
            id = "vegeta",
            name = LocalizedText("Vegeta", "فيجيتا"),
            universe = AnimeUniverse.DRAGON_BALL,
            type = CharacterType.STRIKER,
            powerCategory = PowerCategory.ENERGY,
            tier = "S+",
            stats = CharacterStats(offense = 97, defense = 92, speed = 95, intelligence = 86, versatility = 88, aura = 96),
            signatureMove = LocalizedText("Ultra Ego: Final Flash", "الأنا الفائقة: الوميض النهائي"),
            tacticalTrait = LocalizedText("Converts damage taken into surging offensive fury", "يحوّل الضرر المتلقى إلى طاقة هجومية مضاعفة"),
            malQuery = "Vegeta"
        ),
        Character(
            id = "son_gohan",
            name = LocalizedText("Son Gohan", "سون غوهان"),
            universe = AnimeUniverse.DRAGON_BALL,
            type = CharacterType.STRIKER,
            powerCategory = PowerCategory.ENERGY,
            tier = "S+",
            stats = CharacterStats(offense = 96, defense = 88, speed = 93, intelligence = 89, versatility = 86, aura = 95),
            signatureMove = LocalizedText("Beast Special Beam Cannon", "مدفع الوحش الخاص"),
            tacticalTrait = LocalizedText("Explosive latent spike punishes slow starts", "انفجار طاقة كامن يعاقب البدايات البطيئة"),
            malQuery = "Son Gohan"
        ),
        Character(
            id = "piccolo",
            name = LocalizedText("Piccolo", "بيكولو"),
            universe = AnimeUniverse.DRAGON_BALL,
            type = CharacterType.TANK,
            powerCategory = PowerCategory.ENERGY,
            tier = "A",
            stats = CharacterStats(offense = 85, defense = 91, speed = 84, intelligence = 93, versatility = 90, aura = 84),
            signatureMove = LocalizedText("Orange Giant & Hellzone Grenade", "بيكولو البرتقالي وقنبلة الجحيم"),
            tacticalTrait = LocalizedText("Namekian regeneration & battlefield command anchor", "تجدد فوري وقيادة تكتيكية لخط الدفاع"),
            malQuery = "Piccolo Dragon Ball"
        ),

        // ==================== JUJUTSU KAISEN ====================
        Character(
            id = "satoru_gojo",
            name = LocalizedText("Satoru Gojo", "ساتورو غوجو"),
            universe = AnimeUniverse.JUJUTSU_KAISEN,
            type = CharacterType.ALL_ROUNDER,
            powerCategory = PowerCategory.HAX,
            tier = "S+",
            stats = CharacterStats(offense = 94, defense = 98, speed = 95, intelligence = 94, versatility = 96, aura = 99),
            signatureMove = LocalizedText("Unlimited Void & Hollow Purple", "الفراغ اللامحدود والبنفسجي الأجوف"),
            tacticalTrait = LocalizedText("Infinity barrier negates conventional physical contact", "حاجز اللانهاية يمنع الهجمات التقليدية"),
            malQuery = "Satoru Gojo"
        ),
        Character(
            id = "ryomen_sukuna",
            name = LocalizedText("Ryomen Sukuna", "ريومين سوكونا"),
            universe = AnimeUniverse.JUJUTSU_KAISEN,
            type = CharacterType.STRIKER,
            powerCategory = PowerCategory.HAX,
            tier = "S+",
            stats = CharacterStats(offense = 97, defense = 92, speed = 93, intelligence = 95, versatility = 94, aura = 98),
            signatureMove = LocalizedText("Malevolent Shrine & World Slash", "الضريح الخبيث وقطعة العالم"),
            tacticalTrait = LocalizedText("Space-cutting dismantle bypasses static shields", "ضربات تقطع الفضاء وتتجاوز الدروع الثابتة"),
            malQuery = "Sukuna"
        ),
        Character(
            id = "yuta_okkotsu",
            name = LocalizedText("Yuta Okkotsu", "يوتا أوكوتسو"),
            universe = AnimeUniverse.JUJUTSU_KAISEN,
            type = CharacterType.SUPPORT,
            powerCategory = PowerCategory.SPIRITUAL,
            tier = "S",
            stats = CharacterStats(offense = 89, defense = 86, speed = 88, intelligence = 88, versatility = 97, aura = 91),
            signatureMove = LocalizedText("Authentic Mutual Love & Rika", "الحب المتبادل الحقيقي وريكا"),
            tacticalTrait = LocalizedText("Technique mimicry & Reverse Cursed healing", "نسخ التقنيات وعلاج الفريق بالطاقة المعكوسة"),
            malQuery = "Yuta Okkotsu"
        ),
        Character(
            id = "toji_fushiguro",
            name = LocalizedText("Toji Fushiguro", "توجي فوشيغورو"),
            universe = AnimeUniverse.JUJUTSU_KAISEN,
            type = CharacterType.ASSASSIN,
            powerCategory = PowerCategory.PHYSICAL,
            tier = "A",
            stats = CharacterStats(offense = 90, defense = 80, speed = 95, intelligence = 87, versatility = 85, aura = 88),
            signatureMove = LocalizedText("Inverted Spear Ambush", "كمين الرمح المقلوب"),
            tacticalTrait = LocalizedText("Zero-aura stealth breaks domain & barrier casters", "تخفٍ تام يكسر تقنيات الحواجز والمجالات"),
            malQuery = "Toji Fushiguro"
        ),

        // ==================== DEMON SLAYER ====================
        Character(
            id = "yoriichi_tsugikuni",
            name = LocalizedText("Yoriichi Tsugikuni", "يوريتشي تسوغيكوني"),
            universe = AnimeUniverse.DEMON_SLAYER,
            type = CharacterType.ASSASSIN,
            powerCategory = PowerCategory.ELEMENTAL,
            tier = "S+",
            stats = CharacterStats(offense = 95, defense = 84, speed = 98, intelligence = 91, versatility = 86, aura = 96),
            signatureMove = LocalizedText("Sun Breathing: 13th Form", "تنفس الشمس: الهيئة الثالثة عشرة"),
            tacticalTrait = LocalizedText("Transparent World foresight strikes before foes react", "رؤية العالم الشفاف تضرب قبل رد فعل الخصم"),
            malQuery = "Yoriichi Tsugikuni"
        ),
        Character(
            id = "tanjiro_kamado",
            name = LocalizedText("Tanjiro Kamado", "تانجيرو كامادو"),
            universe = AnimeUniverse.DEMON_SLAYER,
            type = CharacterType.ALL_ROUNDER,
            powerCategory = PowerCategory.ELEMENTAL,
            tier = "A",
            stats = CharacterStats(offense = 84, defense = 82, speed = 86, intelligence = 84, versatility = 89, aura = 85),
            signatureMove = LocalizedText("Hinokami Kagura: Clear Blue Sky", "هينوكامي كاغورا: السماء الزرقاء الصافية"),
            tacticalTrait = LocalizedText("Dual Water/Sun breathing adapts mid-duel", "دمج تنفس الماء والشمس للتكيّف أثناء القتال"),
            malQuery = "Tanjiro Kamado"
        ),
        Character(
            id = "gyomei_himejima",
            name = LocalizedText("Gyomei Himejima", "غيومي هيميجيما"),
            universe = AnimeUniverse.DEMON_SLAYER,
            type = CharacterType.TANK,
            powerCategory = PowerCategory.PHYSICAL,
            tier = "S",
            stats = CharacterStats(offense = 89, defense = 94, speed = 82, intelligence = 85, versatility = 83, aura = 90),
            signatureMove = LocalizedText("Stone Breathing: Volcanic Rock", "تنفس الحجر: الصخرة البركانية"),
            tacticalTrait = LocalizedText("Chain-flail zone control anchors frontlines", "تحكم واسع بالمنطقة يثبّت خط المواجهة"),
            malQuery = "Gyomei Himejima"
        ),
        Character(
            id = "muzan_kibutsuji",
            name = LocalizedText("Muzan Kibutsuji", "موزان كيبوتسوجي"),
            universe = AnimeUniverse.DEMON_SLAYER,
            type = CharacterType.TANK,
            powerCategory = PowerCategory.SPIRITUAL,
            tier = "S",
            stats = CharacterStats(offense = 91, defense = 95, speed = 90, intelligence = 89, versatility = 91, aura = 92),
            signatureMove = LocalizedText("Biokinetic Whip Barrage", "وابل السياط الحيوية"),
            tacticalTrait = LocalizedText("Hyper-regeneration sustains extended attrition wars", "تجدد فائق يصمد في معارك الاستنزاف الطويلة"),
            malQuery = "Muzan Kibutsuji"
        ),

        // ==================== ATTACK ON TITAN ====================
        Character(
            id = "levi_ackerman",
            name = LocalizedText("Levi Ackerman", "ليفاي أكرمان"),
            universe = AnimeUniverse.ATTACK_ON_TITAN,
            type = CharacterType.ASSASSIN,
            powerCategory = PowerCategory.PHYSICAL,
            tier = "S",
            stats = CharacterStats(offense = 90, defense = 78, speed = 96, intelligence = 91, versatility = 84, aura = 93),
            signatureMove = LocalizedText("ODM Beyblade Vortex", "دوامة عدة المناورة القتالية"),
            tacticalTrait = LocalizedText("Relentless aerial precision shreds oversized tanks", "دقة جوية فتاكة تمزق المقاتلين الضخام"),
            malQuery = "Levi"
        ),
        Character(
            id = "eren_yeager",
            name = LocalizedText("Eren Yeager", "إيرين ييغر"),
            universe = AnimeUniverse.ATTACK_ON_TITAN,
            type = CharacterType.TANK,
            powerCategory = PowerCategory.PHYSICAL,
            tier = "S",
            stats = CharacterStats(offense = 92, defense = 91, speed = 77, intelligence = 86, versatility = 88, aura = 94),
            signatureMove = LocalizedText("Founding Titan: Rumbling March", "العملاق المؤسس: زحف الدك"),
            tacticalTrait = LocalizedText("Colossal siege pressure crushes defensive lines", "ضغط حصار هائل يحطم خطوط الدفاع"),
            malQuery = "Eren Yeager"
        ),
        Character(
            id = "mikasa_ackerman",
            name = LocalizedText("Mikasa Ackerman", "ميكاسا أكرمان"),
            universe = AnimeUniverse.ATTACK_ON_TITAN,
            type = CharacterType.STRIKER,
            powerCategory = PowerCategory.PHYSICAL,
            tier = "A",
            stats = CharacterStats(offense = 87, defense = 80, speed = 91, intelligence = 82, versatility = 82, aura = 84),
            signatureMove = LocalizedText("Thunder Spear Blitz", "اندفاع رماح الرعد"),
            tacticalTrait = LocalizedText("High-burst vanguard guard & rapid flank follow-ups", "حماية هجومية سريعة وملاحقة الأجنحة"),
            malQuery = "Mikasa Ackerman"
        ),
        Character(
            id = "armin_arlert",
            name = LocalizedText("Armin Arlert", "أرمين أرليرت"),
            universe = AnimeUniverse.ATTACK_ON_TITAN,
            type = CharacterType.STRATEGIST,
            powerCategory = PowerCategory.ENERGY,
            tier = "A",
            stats = CharacterStats(offense = 84, defense = 83, speed = 68, intelligence = 97, versatility = 85, aura = 81),
            signatureMove = LocalizedText("Colossal Detonation", "الانفجار العملاق"),
            tacticalTrait = LocalizedText("Mastermind tactical calls & nuclear transformation reset", "تخطيط عبقري وتحول انفجاري يعيد تشكيل المعركة"),
            malQuery = "Armin Arlert"
        ),

        // ==================== HUNTER X HUNTER ====================
        Character(
            id = "isaac_netero",
            name = LocalizedText("Isaac Netero", "إسحاق نيتيرو"),
            universe = AnimeUniverse.HUNTER_X_HUNTER,
            type = CharacterType.STRIKER,
            powerCategory = PowerCategory.SPIRITUAL,
            tier = "S",
            stats = CharacterStats(offense = 92, defense = 87, speed = 95, intelligence = 91, versatility = 87, aura = 95),
            signatureMove = LocalizedText("100-Type Guanyin Bodhisattva", "بوديساتفا غوانيين ذو المئة نوع"),
            tacticalTrait = LocalizedText("Supersonic palm barrage denies close-range engages", "وابل ضربات أسرع من الصوت يمنع الاقتراب"),
            malQuery = "Isaac Netero"
        ),
        Character(
            id = "meruem",
            name = LocalizedText("Meruem", "ميرويم"),
            universe = AnimeUniverse.HUNTER_X_HUNTER,
            type = CharacterType.ALL_ROUNDER,
            powerCategory = PowerCategory.ENERGY,
            tier = "S+",
            stats = CharacterStats(offense = 95, defense = 96, speed = 94, intelligence = 98, versatility = 91, aura = 95),
            signatureMove = LocalizedText("Photon En & Rage Blast", "هالة الفوتون وانفجار الغضب"),
            tacticalTrait = LocalizedText("Analyzes enemy patterns mid-fight at supercomputer speed", "يحلل أنماط الخصم أثناء القتال بسرعة خارقة"),
            malQuery = "Meruem"
        ),
        Character(
            id = "killua_zoldyck",
            name = LocalizedText("Killua Zoldyck", "كيلوا زولديك"),
            universe = AnimeUniverse.HUNTER_X_HUNTER,
            type = CharacterType.ASSASSIN,
            powerCategory = PowerCategory.ELEMENTAL,
            tier = "S",
            stats = CharacterStats(offense = 86, defense = 79, speed = 97, intelligence = 90, versatility = 89, aura = 87),
            signatureMove = LocalizedText("Godspeed: Whirlwind", "سرعة الإله: الزوبعة"),
            tacticalTrait = LocalizedText("Neural lightning reflexes win first-strike duels", "ردود فعل برق عصبية تحسم الضربة الأولى"),
            malQuery = "Killua Zoldyck"
        ),
        Character(
            id = "kurapika",
            name = LocalizedText("Kurapika", "كورابيكا"),
            universe = AnimeUniverse.HUNTER_X_HUNTER,
            type = CharacterType.STRATEGIST,
            powerCategory = PowerCategory.HAX,
            tier = "A",
            stats = CharacterStats(offense = 83, defense = 84, speed = 85, intelligence = 96, versatility = 93, aura = 86),
            signatureMove = LocalizedText("Emperor Time & Chain Jail", "زمن الإمبراطور وسجن السلاسل"),
            tacticalTrait = LocalizedText("100% category mastery & binding crowd-control chains", "إتقان شامل للفئات وسلاسل تقييد تكتيكية"),
            malQuery = "Kurapika"
        ),

        // ==================== SOLO LEVELING ====================
        Character(
            id = "sung_jinwoo",
            name = LocalizedText("Sung Jinwoo", "سونغ جين وو"),
            universe = AnimeUniverse.SOLO_LEVELING,
            type = CharacterType.ALL_ROUNDER,
            powerCategory = PowerCategory.SPIRITUAL,
            tier = "S+",
            stats = CharacterStats(offense = 96, defense = 91, speed = 96, intelligence = 92, versatility = 98, aura = 99),
            signatureMove = LocalizedText("Shadow Extraction: Arise", "استخراج الظلال: انهض"),
            tacticalTrait = LocalizedText("Summons an immortal shadow army that scales with kills", "يستدعي جيش ظلال خالد يتضخم مع كل مواجهة"),
            malQuery = "Jin-Woo Sung"
        ),
        Character(
            id = "igris",
            name = LocalizedText("Blood-Red Commander Igris", "القائد القرمزي إغريس"),
            universe = AnimeUniverse.SOLO_LEVELING,
            type = CharacterType.STRIKER,
            powerCategory = PowerCategory.PHYSICAL,
            tier = "S",
            stats = CharacterStats(offense = 90, defense = 88, speed = 92, intelligence = 85, versatility = 83, aura = 90),
            signatureMove = LocalizedText("Demon King Telekinetic Cleave", "ضربة سيف ملك الشياطين"),
            tacticalTrait = LocalizedText("Relentless knight duelist with telekinetic blade recall", "مبارز نبيل لا يكلّ مع تحكم عن بُعد بالسيف"),
            malQuery = "Igris Solo Leveling"
        ),
        Character(
            id = "beru",
            name = LocalizedText("Marshal Beru", "المشير بيرو"),
            universe = AnimeUniverse.SOLO_LEVELING,
            type = CharacterType.ASSASSIN,
            powerCategory = PowerCategory.SPIRITUAL,
            tier = "S",
            stats = CharacterStats(offense = 92, defense = 85, speed = 95, intelligence = 81, versatility = 89, aura = 91),
            signatureMove = LocalizedText("Shadow Claw Frenzy", "هيجان مخالب الظل"),
            tacticalTrait = LocalizedText("Hyper-agile predator with emergency ally healing", "مفترس فائق الرشاقة مع قدرة إسعاف طارئة للحلفاء"),
            malQuery = "Beru Solo Leveling"
        ),
        Character(
            id = "cha_hae_in",
            name = LocalizedText("Cha Hae-In", "تشا هاي إن"),
            universe = AnimeUniverse.SOLO_LEVELING,
            type = CharacterType.STRIKER,
            powerCategory = PowerCategory.ELEMENTAL,
            tier = "A",
            stats = CharacterStats(offense = 88, defense = 81, speed = 90, intelligence = 83, versatility = 82, aura = 86),
            signatureMove = LocalizedText("Sword of Light: Quake", "سيف النور: الزلزال"),
            tacticalTrait = LocalizedText("Radiant sword-dance pierces shadow and spirit guards", "رقصة سيف ضوئية تخترق الحواجز الروحية"),
            malQuery = "Hae-In Cha"
        )
    )

    val allCharacters: List<Character> =
        baseCharacters + ExtraRoster.additionalCharacters + ExpandedRoster.moreCharacters

    fun findById(id: String): Character? = allCharacters.find { it.id == id }
}
