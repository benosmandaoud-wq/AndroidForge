package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.CharacterRoster
import com.example.data.UiText
import com.example.model.AnimeUniverse
import com.example.model.Character
import com.example.model.CharacterType
import com.example.model.ComparisonMode
import com.example.model.Language
import com.example.ui.components.CharacterDetailDialog
import com.example.ui.components.CharacterPortrait
import com.example.ui.components.PowerCategoryPill
import com.example.ui.components.StatBarRow
import com.example.ui.components.TierBadge
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.GoldPrimary
import com.example.ui.viewmodel.DuelLabState

@Composable
fun RosterScreen(
    language: Language,
    portraitUrls: Map<String, String>,
    duelLabState: DuelLabState,
    initialTab: Int = 0,
    onRequestPortrait: (Character) -> Unit,
    onSelectFighterA: (Character) -> Unit,
    onSelectFighterB: (Character) -> Unit,
    onSelectDuelMode: (ComparisonMode) -> Unit,
    onSwapDuelFighters: () -> Unit,
    modifier: Modifier = Modifier
) {
    var activeTab by remember(initialTab) { mutableIntStateOf(initialTab) }
    val tabs = listOf(UiText.encyclopediaTab.get(language), UiText.duelLabTab.get(language))

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 920.dp)
        ) {
            TabRow(selectedTabIndex = activeTab) {
                tabs.forEachIndexed { idx, title ->
                    Tab(
                        selected = activeTab == idx,
                        onClick = { activeTab = idx },
                        text = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    )
                }
            }

            if (activeTab == 0) {
                EncyclopediaContent(
                    language = language,
                    portraitUrls = portraitUrls,
                    onRequestPortrait = onRequestPortrait
                )
            } else {
                DuelLabContent(
                    state = duelLabState,
                    language = language,
                    portraitUrls = portraitUrls,
                    onRequestPortrait = onRequestPortrait,
                    onSelectFighterA = onSelectFighterA,
                    onSelectFighterB = onSelectFighterB,
                    onSelectDuelMode = onSelectDuelMode,
                    onSwapFighters = onSwapDuelFighters
                )
            }
        }
    }
}

@Composable
private fun EncyclopediaContent(
    language: Language,
    portraitUrls: Map<String, String>,
    onRequestPortrait: (Character) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var universeFilter by remember { mutableStateOf<AnimeUniverse?>(null) }
    var typeFilter by remember { mutableStateOf<CharacterType?>(null) }
    var selectedCharacter by remember { mutableStateOf<Character?>(null) }

    selectedCharacter?.let { ch ->
        CharacterDetailDialog(
            character = ch,
            portraitUrl = portraitUrls[ch.id],
            onRequestPortrait = onRequestPortrait,
            language = language,
            onDismiss = { selectedCharacter = null }
        )
    }

    val filtered = remember(query, universeFilter, typeFilter) {
        CharacterRoster.allCharacters.filter { ch ->
            val uniMatch = universeFilter == null || ch.universe == universeFilter
            val typeMatch = typeFilter == null || ch.type == typeFilter
            val q = query.trim()
            val qMatch = q.isEmpty() ||
                ch.name.en.contains(q, ignoreCase = true) ||
                ch.name.ar.contains(q, ignoreCase = true) ||
                ch.signatureMove.en.contains(q, ignoreCase = true)
            uniMatch && typeMatch && qMatch
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text(UiText.searchPlaceholder.get(language)) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = universeFilter == null,
                    onClick = { universeFilter = null },
                    label = { Text(UiText.allUniverses.get(language)) }
                )
                AnimeUniverse.entries.forEach { uni ->
                    FilterChip(
                        selected = universeFilter == uni,
                        onClick = { universeFilter = if (universeFilter == uni) null else uni },
                        label = { Text(uni.title.get(language)) }
                    )
                }
            }

            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                CharacterType.entries.forEach { role ->
                    FilterChip(
                        selected = typeFilter == role,
                        onClick = { typeFilter = if (typeFilter == role) null else role },
                        label = { Text(role.label.get(language)) }
                    )
                }
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 164.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(filtered, key = { it.id }) { ch ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, ch.universe.accentColor.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedCharacter = ch }
                        .testTag("roster_card_${ch.id}")
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            CharacterPortrait(
                                character = ch,
                                portraitUrl = portraitUrls[ch.id],
                                onRequestPortrait = onRequestPortrait,
                                size = 50.dp
                            )
                            Column(horizontalAlignment = Alignment.End) {
                                TierBadge(tier = ch.tier)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "OVR ${ch.stats.overall}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = GoldPrimary
                                )
                            }
                        }
                        Text(
                            text = ch.name.get(language),
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${ch.universe.title.get(language)} • ${ch.type.label.get(language)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        PowerCategoryPill(ch.powerCategory, language)
                    }
                }
            }
        }
    }
}

@Composable
private fun DuelLabContent(
    state: DuelLabState,
    language: Language,
    portraitUrls: Map<String, String>,
    onRequestPortrait: (Character) -> Unit,
    onSelectFighterA: (Character) -> Unit,
    onSelectFighterB: (Character) -> Unit,
    onSelectDuelMode: (ComparisonMode) -> Unit,
    onSwapFighters: () -> Unit
) {
    var pickingForSlot by remember { mutableStateOf<Int?>(null) }

    if (pickingForSlot != null) {
        FighterPickerDialog(
            language = language,
            portraitUrls = portraitUrls,
            onRequestPortrait = onRequestPortrait,
            onSelect = { ch ->
                if (pickingForSlot == 1) onSelectFighterA(ch) else onSelectFighterB(ch)
                pickingForSlot = null
            },
            onDismiss = { pickingForSlot = null }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Comparison Mode Selector
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ComparisonMode.entries.forEach { mode ->
                FilterChip(
                    selected = state.comparisonMode == mode,
                    onClick = { onSelectDuelMode(mode) },
                    label = { Text(mode.label.get(language)) }
                )
            }
        }

        // Fighter A vs Fighter B Selector Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FighterSlotCard(
                label = UiText.selectFighterA.get(language),
                character = state.fighterA,
                accent = GoldPrimary,
                language = language,
                portraitUrl = portraitUrls[state.fighterA.id],
                onRequestPortrait = onRequestPortrait,
                onClick = { pickingForSlot = 1 },
                modifier = Modifier.weight(1f)
            )
            IconButton(
                onClick = onSwapFighters,
                modifier = Modifier.testTag("swap_duel_fighters_button")
            ) {
                Icon(Icons.Filled.SwapHoriz, contentDescription = "Swap fighters")
            }
            FighterSlotCard(
                label = UiText.selectFighterB.get(language),
                character = state.fighterB,
                accent = CyanSecondary,
                language = language,
                portraitUrl = portraitUrls[state.fighterB.id],
                onRequestPortrait = onRequestPortrait,
                onClick = { pickingForSlot = 2 },
                modifier = Modifier.weight(1f)
            )
        }

        // Matchup Result Card
        MatchupDuelCard(
            matchup = state.analysis,
            language = language,
            portraitUrls = portraitUrls,
            onRequestPortrait = onRequestPortrait
        )

        // Head-to-Head Stat Breakdown
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = state.fighterA.name.get(language),
                    style = MaterialTheme.typography.titleSmall,
                    color = GoldPrimary
                )
                StatBarRow(UiText.statOffense.get(language), state.fighterA.stats.offense, GoldPrimary)
                StatBarRow(UiText.statDefense.get(language), state.fighterA.stats.defense, GoldPrimary)
                StatBarRow(UiText.statSpeed.get(language), state.fighterA.stats.speed, GoldPrimary)
                StatBarRow(UiText.statAura.get(language), state.fighterA.stats.aura, GoldPrimary)

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = state.fighterB.name.get(language),
                    style = MaterialTheme.typography.titleSmall,
                    color = CyanSecondary
                )
                StatBarRow(UiText.statOffense.get(language), state.fighterB.stats.offense, CyanSecondary)
                StatBarRow(UiText.statDefense.get(language), state.fighterB.stats.defense, CyanSecondary)
                StatBarRow(UiText.statSpeed.get(language), state.fighterB.stats.speed, CyanSecondary)
                StatBarRow(UiText.statAura.get(language), state.fighterB.stats.aura, CyanSecondary)
            }
        }
    }
}

@Composable
private fun FighterSlotCard(
    label: String,
    character: Character,
    accent: Color,
    language: Language,
    portraitUrl: String?,
    onRequestPortrait: (Character) -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.55f)),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = accent,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            CharacterPortrait(
                character = character,
                portraitUrl = portraitUrl,
                onRequestPortrait = onRequestPortrait,
                size = 56.dp,
                borderColor = accent
            )
            Text(
                text = character.name.get(language),
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            TierBadge(character.tier)
        }
    }
}

@Composable
private fun FighterPickerDialog(
    language: Language,
    portraitUrls: Map<String, String>,
    onRequestPortrait: (Character) -> Unit,
    onSelect: (Character) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (language == Language.AR) "إلغاء" else "Cancel")
            }
        },
        title = {
            Text(
                text = if (language == Language.AR) "اختر مقاتلاً" else "Select Fighter",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier.height(380.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(CharacterRoster.allCharacters, key = { it.id }) { ch ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHighest,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(ch) }
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CharacterPortrait(
                                character = ch,
                                portraitUrl = portraitUrls[ch.id],
                                onRequestPortrait = onRequestPortrait,
                                size = 40.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(ch.name.get(language), style = MaterialTheme.typography.titleSmall)
                                Text(
                                    text = ch.universe.title.get(language),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            TierBadge(ch.tier)
                        }
                    }
                }
            }
        }
    )
}
