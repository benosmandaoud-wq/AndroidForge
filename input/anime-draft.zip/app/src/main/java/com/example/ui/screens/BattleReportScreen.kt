package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.UiText
import com.example.engine.DraftEngine
import com.example.model.Character
import com.example.model.Language
import com.example.model.MatchupAnalysis
import com.example.model.PlayerKey
import com.example.model.SavedDraftRecord
import com.example.model.SynergyBonus
import com.example.ui.components.CharacterPortrait
import com.example.ui.components.PowerCategoryPill
import com.example.ui.components.TeamRadarChart
import com.example.ui.components.TierBadge
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldWin
import com.example.ui.theme.GoldPrimary

@Composable
fun BattleReportScreen(
    record: SavedDraftRecord,
    language: Language,
    portraitUrls: Map<String, String>,
    onRequestPortrait: (Character) -> Unit,
    onRematch: () -> Unit,
    onNewDraft: () -> Unit,
    modifier: Modifier = Modifier
) {
    val report = record.report
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        UiText.tabOverview.get(language),
        UiText.tabDuels.get(language),
        UiText.tabSynergies.get(language)
    )

    val p1DuelWins = remember(report) { report.matchups.count { it.winner == PlayerKey.PLAYER_1 } }
    val p2DuelWins = remember(report) { report.matchups.count { it.winner == PlayerKey.PLAYER_2 } }
    val (p1WinPct, p2WinPct) = remember(report) {
        if (report.p1WinPercent + report.p2WinPercent == 100 &&
            (report.p1WinPercent != 50 || report.p1TotalScore == report.p2TotalScore)
        ) {
            report.p1WinPercent to report.p2WinPercent
        } else {
            DraftEngine.computeWinPercentages(
                p1Total = report.p1TotalScore,
                p2Total = report.p2TotalScore,
                p1DuelWins = p1DuelWins,
                p2DuelWins = p2DuelWins
            )
        }
    }

    val winnerColor = when (report.winner) {
        PlayerKey.PLAYER_1 -> GoldPrimary
        PlayerKey.PLAYER_2 -> CyanSecondary
        null -> EmeraldWin
    }
    val winnerLabel = when (report.winner) {
        PlayerKey.PLAYER_1 -> "${record.player1Name} ${UiText.victory.get(language)}"
        PlayerKey.PLAYER_2 -> "${record.player2Name} ${UiText.victory.get(language)}"
        null -> UiText.draw.get(language)
    }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 860.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Winner Hero Banner
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(1.5.dp, winnerColor.copy(alpha = 0.6f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(174.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_duel_banner),
                            contentDescription = winnerLabel,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color(0x88090D16), Color(0xEC090D16))
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(18.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = winnerColor.copy(alpha = 0.22f),
                                    border = BorderStroke(1.dp, winnerColor)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = winnerColor)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = winnerLabel,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = winnerColor
                                        )
                                    }
                                }
                                Text(
                                    text = "${record.comparisonMode.label.get(language)} • ${record.teamSize}v${record.teamSize}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFFCBD5E1)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Column {
                                    Text(
                                        text = record.player1Name,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = GoldPrimary
                                    )
                                    Text(
                                        text = report.p1TotalScore.toString(),
                                        style = MaterialTheme.typography.displayLarge,
                                        color = Color.White
                                    )
                                }
                                Text(
                                    text = "VS",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color(0xFF94A3B8)
                                )
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = record.player2Name,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = CyanSecondary
                                    )
                                    Text(
                                        text = report.p2TotalScore.toString(),
                                        style = MaterialTheme.typography.displayLarge,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Team Win Percentage Card
            item {
                TeamWinProbabilityCard(
                    player1Name = record.player1Name,
                    player2Name = record.player2Name,
                    p1WinPercent = p1WinPct,
                    p2WinPercent = p2WinPct,
                    p1DuelWins = p1DuelWins,
                    p2DuelWins = p2DuelWins,
                    totalDuels = report.matchups.size,
                    language = language
                )
            }

            // Verdict Copy
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = report.verdictSummary.get(language),
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            // Segmented Tabs
            item {
                TabRow(selectedTabIndex = selectedTab) {
                    tabs.forEachIndexed { idx, label ->
                        Tab(
                            selected = selectedTab == idx,
                            onClick = { selectedTab = idx },
                            text = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        )
                    }
                }
            }

            when (selectedTab) {
                0 -> {
                    // Radar Chart
                    item {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (language == Language.AR) "مقارنة الأبعاد الستة" else "Team Dimension Radar",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("● ${record.player1Name}", style = MaterialTheme.typography.labelSmall, color = GoldPrimary)
                                        Text("● ${record.player2Name}", style = MaterialTheme.typography.labelSmall, color = CyanSecondary)
                                    }
                                }
                                TeamRadarChart(
                                    p1Dimensions = report.p1Dimensions,
                                    p2Dimensions = report.p2Dimensions,
                                    language = language
                                )
                            }
                        }
                    }

                    // MVP Spotlight
                    item {
                        val mvpColor = if (report.mvpOwner == PlayerKey.PLAYER_1) GoldPrimary else CyanSecondary
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, mvpColor.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CharacterPortrait(
                                    character = report.mvpCharacter,
                                    portraitUrl = portraitUrls[report.mvpCharacter.id],
                                    onRequestPortrait = onRequestPortrait,
                                    size = 64.dp,
                                    borderColor = mvpColor
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${UiText.mvpLabel.get(language)} • ${report.mvpOwner.label.get(language)}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = mvpColor
                                    )
                                    Text(
                                        text = report.mvpCharacter.name.get(language),
                                        style = MaterialTheme.typography.titleLarge
                                    )
                                    Text(
                                        text = report.mvpCharacter.signatureMove.get(language),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                TierBadge(tier = report.mvpCharacter.tier)
                            }
                        }
                    }
                }

                1 -> {
                    items(report.matchups, key = { it.slotIndex }) { matchup ->
                        MatchupDuelCard(
                            matchup = matchup,
                            language = language,
                            portraitUrls = portraitUrls,
                            onRequestPortrait = onRequestPortrait
                        )
                    }
                }

                2 -> {
                    item {
                        SynergyTeamSection(
                            title = record.player1Name,
                            accent = GoldPrimary,
                            synergies = report.p1Synergies,
                            language = language
                        )
                    }
                    item {
                        SynergyTeamSection(
                            title = record.player2Name,
                            accent = CyanSecondary,
                            synergies = report.p2Synergies,
                            language = language
                        )
                    }
                }
            }

            // Action Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onRematch,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("rematch_button")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(UiText.rematch.get(language))
                    }
                    OutlinedButton(
                        onClick = onNewDraft,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("new_draft_button")
                    ) {
                        Text(UiText.newDraft.get(language))
                    }
                }
            }
        }
    }
}

@Composable
fun MatchupDuelCard(
    matchup: MatchupAnalysis,
    language: Language,
    portraitUrls: Map<String, String>,
    onRequestPortrait: (Character) -> Unit
) {
    val edgeColor = when (matchup.winner) {
        PlayerKey.PLAYER_1 -> GoldPrimary
        PlayerKey.PLAYER_2 -> CyanSecondary
        null -> MaterialTheme.colorScheme.outline
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, edgeColor.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    CharacterPortrait(
                        character = matchup.player1Character,
                        portraitUrl = portraitUrls[matchup.player1Character.id],
                        onRequestPortrait = onRequestPortrait,
                        size = 44.dp,
                        borderColor = GoldPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = matchup.player1Character.name.get(language),
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        PowerCategoryPill(matchup.player1Character.powerCategory, language)
                    }
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = "${matchup.p1DuelScore} - ${matchup.p2DuelScore}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = edgeColor
                    )
                    Text(
                        text = "SLOT ${matchup.slotIndex + 1}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.weight(1f)
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = matchup.player2Character.name.get(language),
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        PowerCategoryPill(matchup.player2Character.powerCategory, language)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    CharacterPortrait(
                        character = matchup.player2Character,
                        portraitUrl = portraitUrls[matchup.player2Character.id],
                        onRequestPortrait = onRequestPortrait,
                        size = 44.dp,
                        borderColor = CyanSecondary
                    )
                }
            }

            Text(
                text = matchup.summary.get(language),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SynergyTeamSection(
    title: String,
    accent: Color,
    synergies: List<SynergyBonus>,
    language: Language
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = accent)
            if (synergies.isEmpty()) {
                Text(
                    text = if (language == Language.AR) "لا توجد مكافآت تناغم إضافية لهذا الفريق." else "No active universe or formation synergies unlocked.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                synergies.forEach { syn ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(syn.title.get(language), style = MaterialTheme.typography.titleSmall)
                                Text(
                                    text = syn.description.get(language),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "+${syn.bonusPoints}",
                                style = MaterialTheme.typography.labelLarge,
                                color = accent
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TeamWinProbabilityCard(
    player1Name: String,
    player2Name: String,
    p1WinPercent: Int,
    p2WinPercent: Int,
    p1DuelWins: Int,
    p2DuelWins: Int,
    totalDuels: Int,
    language: Language
) {
    val animatedShare by animateFloatAsState(
        targetValue = (p1WinPercent / 100f).coerceIn(0.05f, 0.95f),
        animationSpec = spring(dampingRatio = 0.8f, stiffness = 260f),
        label = "win_probability_share"
    )
    val draws = (totalDuels - p1DuelWins - p2DuelWins).coerceAtLeast(0)

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.testTag("team_win_percentage_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Percent,
                        contentDescription = null,
                        tint = GoldPrimary
                    )
                    Text(
                        text = if (language == Language.AR) "نسبة فوز الفريق" else "Team Win Percentage",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
                Text(
                    text = if (language == Language.AR) {
                        "المواجهات: $p1DuelWins - $p2DuelWins" + if (draws > 0) " (تعادل $draws)" else ""
                    } else {
                        "Duels: $p1DuelWins - $p2DuelWins" + if (draws > 0) " ($draws draw)" else ""
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = player1Name,
                        style = MaterialTheme.typography.labelMedium,
                        color = GoldPrimary
                    )
                    Text(
                        text = "$p1WinPercent%",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = GoldPrimary
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = player2Name,
                        style = MaterialTheme.typography.labelMedium,
                        color = CyanSecondary
                    )
                    Text(
                        text = "$p2WinPercent%",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyanSecondary
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(14.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Box(
                    modifier = Modifier
                        .weight(animatedShare)
                        .fillMaxHeight()
                        .background(
                            Brush.horizontalGradient(
                                listOf(GoldPrimary, GoldPrimary.copy(alpha = 0.78f))
                            )
                        )
                )
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .fillMaxHeight()
                        .background(MaterialTheme.colorScheme.surface)
                )
                Box(
                    modifier = Modifier
                        .weight((1f - animatedShare).coerceAtLeast(0.05f))
                        .fillMaxHeight()
                        .background(
                            Brush.horizontalGradient(
                                listOf(CyanSecondary.copy(alpha = 0.78f), CyanSecondary)
                            )
                        )
                )
            }
        }
    }
}
