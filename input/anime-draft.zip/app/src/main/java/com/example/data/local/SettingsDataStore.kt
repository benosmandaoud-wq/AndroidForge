package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.ComparisonMode
import com.example.model.DraftDifficulty
import com.example.model.GameSettings
import com.example.model.Language
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "anime_draft_settings")

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("language")
        val DIFFICULTY = stringPreferencesKey("difficulty")
        val COMPARISON_MODE = stringPreferencesKey("comparison_mode")
        val TEAM_SIZE = intPreferencesKey("team_size")
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val PLAYER1_NAME = stringPreferencesKey("player1_name")
        val PLAYER2_NAME = stringPreferencesKey("player2_name")
    }

    val settingsFlow: Flow<GameSettings> = context.dataStore.data.map { prefs ->
        val lang = prefs[Keys.LANGUAGE]?.let { runCatching { Language.valueOf(it) }.getOrNull() } ?: Language.EN
        val diff = prefs[Keys.DIFFICULTY]?.let { runCatching { DraftDifficulty.valueOf(it) }.getOrNull() } ?: DraftDifficulty.TACTICAL
        val comp = prefs[Keys.COMPARISON_MODE]?.let { runCatching { ComparisonMode.valueOf(it) }.getOrNull() } ?: ComparisonMode.BALANCED
        val teamSize = prefs[Keys.TEAM_SIZE] ?: 5
        val darkTheme = prefs[Keys.DARK_THEME] ?: true
        val p1 = prefs[Keys.PLAYER1_NAME]?.takeIf { it.isNotBlank() } ?: "Daoud"
        val p2 = prefs[Keys.PLAYER2_NAME]?.takeIf { it.isNotBlank() } ?: "Monsef"

        GameSettings(
            language = lang,
            defaultDifficulty = diff,
            defaultComparisonMode = comp,
            defaultTeamSize = teamSize.coerceIn(1, 12),
            darkTheme = darkTheme,
            player1Name = p1,
            player2Name = p2
        )
    }

    suspend fun updateSettings(transform: (GameSettings) -> GameSettings) {
        context.dataStore.edit { prefs ->
            val current = GameSettings(
                language = prefs[Keys.LANGUAGE]?.let { runCatching { Language.valueOf(it) }.getOrNull() } ?: Language.EN,
                defaultDifficulty = prefs[Keys.DIFFICULTY]?.let { runCatching { DraftDifficulty.valueOf(it) }.getOrNull() } ?: DraftDifficulty.TACTICAL,
                defaultComparisonMode = prefs[Keys.COMPARISON_MODE]?.let { runCatching { ComparisonMode.valueOf(it) }.getOrNull() } ?: ComparisonMode.BALANCED,
                defaultTeamSize = prefs[Keys.TEAM_SIZE] ?: 5,
                darkTheme = prefs[Keys.DARK_THEME] ?: true,
                player1Name = prefs[Keys.PLAYER1_NAME]?.takeIf { it.isNotBlank() } ?: "Daoud",
                player2Name = prefs[Keys.PLAYER2_NAME]?.takeIf { it.isNotBlank() } ?: "Monsef"
            )
            val updated = transform(current)
            prefs[Keys.LANGUAGE] = updated.language.name
            prefs[Keys.DIFFICULTY] = updated.defaultDifficulty.name
            prefs[Keys.COMPARISON_MODE] = updated.defaultComparisonMode.name
            prefs[Keys.TEAM_SIZE] = updated.defaultTeamSize
            prefs[Keys.DARK_THEME] = updated.darkTheme
            prefs[Keys.PLAYER1_NAME] = updated.player1Name.ifBlank { "Daoud" }
            prefs[Keys.PLAYER2_NAME] = updated.player2Name.ifBlank { "Monsef" }
        }
    }
}
