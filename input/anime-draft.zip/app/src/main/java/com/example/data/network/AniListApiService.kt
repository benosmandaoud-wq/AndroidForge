package com.example.data.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class AniListGraphQlRequest(
    @Json(name = "query") val query: String,
    @Json(name = "variables") val variables: Map<String, String>
)

@JsonClass(generateAdapter = true)
data class AniListGraphQlResponse(
    @Json(name = "data") val data: AniListDataDto? = null
)

@JsonClass(generateAdapter = true)
data class AniListDataDto(
    @Json(name = "Page") val page: AniListPageDto? = null
)

@JsonClass(generateAdapter = true)
data class AniListPageDto(
    @Json(name = "characters") val characters: List<AniListCharacterDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class AniListCharacterDto(
    @Json(name = "id") val id: Int = 0,
    @Json(name = "image") val image: AniListImageDto? = null,
    @Json(name = "media") val media: AniListMediaConnectionDto? = null
)

@JsonClass(generateAdapter = true)
data class AniListImageDto(
    @Json(name = "large") val large: String? = null,
    @Json(name = "medium") val medium: String? = null
)

@JsonClass(generateAdapter = true)
data class AniListMediaConnectionDto(
    @Json(name = "nodes") val nodes: List<AniListMediaNodeDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class AniListMediaNodeDto(
    @Json(name = "title") val title: AniListMediaTitleDto? = null
)

@JsonClass(generateAdapter = true)
data class AniListMediaTitleDto(
    @Json(name = "romaji") val romaji: String? = null,
    @Json(name = "english") val english: String? = null
)

interface AniListApiService {
    @POST(".")
    suspend fun searchCharacter(@Body body: AniListGraphQlRequest): AniListGraphQlResponse

    companion object {
        const val SEARCH_CHARACTER_QUERY =
            "query (\$search: String) { Page(page: 1, perPage: 6) { characters(search: \$search, sort: FAVOURITES_DESC) { id image { large medium } media(perPage: 4) { nodes { title { romaji english } } } } } }"

        fun create(): AniListApiService {
            val client = OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .addInterceptor { chain ->
                    val req = chain.request().newBuilder()
                        .header("Accept", "application/json")
                        .header("Content-Type", "application/json")
                        .header("User-Agent", "AnimeDraftAndroid/1.0")
                        .build()
                    chain.proceed(req)
                }
                .build()

            return Retrofit.Builder()
                .baseUrl("https://graphql.anilist.co/")
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
                .create(AniListApiService::class.java)
        }
    }
}
