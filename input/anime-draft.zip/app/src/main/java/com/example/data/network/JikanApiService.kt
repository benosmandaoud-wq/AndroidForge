package com.example.data.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class JikanCharacterSearchResponse(
    @Json(name = "data") val data: List<JikanCharacterDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class JikanCharacterDto(
    @Json(name = "mal_id") val malId: Int = 0,
    @Json(name = "name") val name: String = "",
    @Json(name = "images") val images: JikanImagesDto? = null
)

@JsonClass(generateAdapter = true)
data class JikanImagesDto(
    @Json(name = "jpg") val jpg: JikanImageFormatDto? = null,
    @Json(name = "webp") val webp: JikanImageFormatDto? = null
)

@JsonClass(generateAdapter = true)
data class JikanImageFormatDto(
    @Json(name = "image_url") val imageUrl: String? = null
)

interface JikanApiService {
    @GET("v4/characters")
    suspend fun searchCharacter(
        @Query("q") query: String,
        @Query("limit") limit: Int = 1
    ): JikanCharacterSearchResponse

    companion object {
        fun create(): JikanApiService {
            val client = OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .addInterceptor { chain ->
                    val req = chain.request().newBuilder()
                        .header("Accept", "application/json")
                        .header("User-Agent", "AnimeDraftAndroid/1.0")
                        .build()
                    chain.proceed(req)
                }
                .build()

            return Retrofit.Builder()
                .baseUrl("https://api.jikan.moe/")
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
                .create(JikanApiService::class.java)
        }
    }
}
