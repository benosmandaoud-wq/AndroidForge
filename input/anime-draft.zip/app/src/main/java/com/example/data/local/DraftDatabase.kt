package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "saved_drafts")
data class SavedDraftEntity(
    @PrimaryKey val id: String,
    val timestampMillis: Long,
    val payloadJson: String
)

@Entity(tableName = "portrait_cache")
data class PortraitCacheEntity(
    @PrimaryKey val characterId: String,
    val imageUrl: String,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "active_draft")
data class ActiveDraftEntity(
    @PrimaryKey val id: Int = 1,
    val payloadJson: String,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Dao
interface SavedDraftDao {
    @Query("SELECT * FROM saved_drafts ORDER BY timestampMillis DESC")
    fun observeAllDrafts(): Flow<List<SavedDraftEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDraft(entity: SavedDraftEntity)

    @Query("DELETE FROM saved_drafts WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM saved_drafts")
    suspend fun deleteAll()
}

@Dao
interface PortraitCacheDao {
    @Query("SELECT * FROM portrait_cache")
    fun observeAllPortraits(): Flow<List<PortraitCacheEntity>>

    @Query("SELECT imageUrl FROM portrait_cache WHERE characterId = :characterId LIMIT 1")
    suspend fun getPortraitUrl(characterId: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPortrait(entity: PortraitCacheEntity)

    @Query("DELETE FROM portrait_cache")
    suspend fun clearAll()
}

@Dao
interface ActiveDraftDao {
    @Query("SELECT * FROM active_draft WHERE id = 1 LIMIT 1")
    fun observeActiveDraft(): Flow<ActiveDraftEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertActiveDraft(entity: ActiveDraftEntity)

    @Query("DELETE FROM active_draft")
    suspend fun clearActiveDraft()
}

@Database(
    entities = [SavedDraftEntity::class, PortraitCacheEntity::class, ActiveDraftEntity::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun savedDraftDao(): SavedDraftDao
    abstract fun portraitCacheDao(): PortraitCacheDao
    abstract fun activeDraftDao(): ActiveDraftDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "anime_draft_db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
