package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.CharacterRoster
import com.example.data.DraftRepository
import com.example.data.local.AppDatabase
import com.example.data.local.SettingsDataStore
import com.example.data.network.AniListApiService
import com.example.data.network.JikanApiService
import com.example.engine.DraftEngine
import com.example.model.AnimeUniverse
import com.example.model.Character
import com.example.model.ComparisonMode
import com.example.model.DraftMode
import com.example.model.DraftState
import com.example.model.GameSettings
import com.example.model.Language
import com.example.model.MatchupAnalysis
import com.example.model.RoundPhase
import com.example.model.SavedDraftRecord
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DuelLabState(
    val fighterA: Character = CharacterRoster.allCharacters.first(),
    val fighterB: Character = CharacterRoster.allCharacters[1],
    val comparisonMode: ComparisonMode = ComparisonMode.BALANCED,
    val analysis: MatchupAnalysis = DraftEngine.analyzeIndividualMatchup(
        CharacterRoster.allCharacters.first(),
        CharacterRoster.allCharacters[1],
        ComparisonMode.BALANCED
    )
)

class ArenaViewModel(
    application: Application,
    private val repository: DraftRepository
) : AndroidViewModel(application) {

    val settings: StateFlow<GameSettings> = repository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = GameSettings()
    )

    val savedDrafts: StateFlow<List<SavedDraftRecord>> = repository.savedDraftsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val portraitUrls: StateFlow<Map<String, String>> = repository.portraitUrlsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyMap()
    )

    private val _activeDraft = MutableStateFlow<DraftState?>(null)
    val activeDraft: StateFlow<DraftState?> = _activeDraft.asStateFlow()

    private val _activeReportRecord = MutableStateFlow<SavedDraftRecord?>(null)
    val activeReportRecord: StateFlow<SavedDraftRecord?> = _activeReportRecord.asStateFlow()

    private val _duelLab = MutableStateFlow(DuelLabState())
    val duelLab: StateFlow<DuelLabState> = _duelLab.asStateFlow()

    private var autoAdvanceJob: Job? = null
    private var savedCompletedDraftIds = mutableSetOf<String>()

    init {
        viewModelScope.launch {
            val restored = repository.activeDraftFlow.firstOrNull()
            if (restored != null && _activeDraft.value == null) {
                val fixed = if (restored.phase == RoundPhase.ROUND_REVEAL && !restored.isComplete) {
                    DraftEngine.advanceToNextRound(restored)
                } else {
                    restored
                }
                _activeDraft.value = fixed
                if (fixed.isComplete) {
                    savedCompletedDraftIds.add(fixed.draftId)
                }
            }
            // Warm portrait cache in background for popular & active fighters
            CharacterRoster.allCharacters.take(18).forEach { ch ->
                if (!portraitUrls.value.containsKey(ch.id)) {
                    repository.resolveCharacterPortrait(ch)
                }
            }
        }
    }

    fun ensurePortraitResolved(character: Character) {
        if (portraitUrls.value.containsKey(character.id)) return
        viewModelScope.launch {
            repository.resolveCharacterPortrait(character)
        }
    }

    fun startNewDraft(
        player1Name: String = settings.value.player1Name,
        player2Name: String = settings.value.player2Name,
        selectedUniverses: List<AnimeUniverse> = AnimeUniverse.entries,
        totalRounds: Int = settings.value.defaultTeamSize,
        comparisonMode: ComparisonMode = settings.value.defaultComparisonMode
    ) {
        autoAdvanceJob?.cancel()
        val p1 = player1Name.trim().ifBlank { "Daoud" }
        val p2 = player2Name.trim().ifBlank { "Monsef" }

        val draft = DraftEngine.createInitialDraft(
            player1Name = p1,
            player2Name = p2,
            selectedUniverses = selectedUniverses,
            totalRounds = totalRounds,
            comparisonMode = comparisonMode
        )
        _activeDraft.value = draft
        _activeReportRecord.value = null

        viewModelScope.launch {
            repository.updateSettings {
                it.copy(
                    player1Name = p1,
                    player2Name = p2,
                    defaultTeamSize = draft.totalRounds,
                    defaultComparisonMode = comparisonMode
                )
            }
            repository.saveActiveDraft(draft)
            // Prefetch portraits for the current round's 3 cards immediately
            draft.currentCards.forEach { slot ->
                repository.resolveCharacterPortrait(slot.character)
            }
        }
    }

    fun restartCurrentDraft() {
        val current = _activeDraft.value
        if (current != null) {
            startNewDraft(
                player1Name = current.player1Name,
                player2Name = current.player2Name,
                selectedUniverses = current.selectedUniverses,
                totalRounds = current.totalRounds,
                comparisonMode = current.comparisonMode
            )
        } else {
            startNewDraft()
        }
    }

    fun selectDraftCard(slotIndex: Int) {
        val current = _activeDraft.value ?: return
        if (current.isComplete || current.phase == RoundPhase.ROUND_REVEAL) return

        val next = DraftEngine.selectDraftCard(current, slotIndex)
        if (next == current) return
        _activeDraft.value = next

        viewModelScope.launch {
            repository.saveActiveDraft(next)
        }

        if (next.phase == RoundPhase.ROUND_REVEAL) {
            scheduleAutoAdvance()
        }
    }

    private fun scheduleAutoAdvance() {
        autoAdvanceJob?.cancel()
        autoAdvanceJob = viewModelScope.launch {
            delay(1900L)
            advanceNow()
        }
    }

    fun advanceNow() {
        autoAdvanceJob?.cancel()
        val current = _activeDraft.value ?: return
        if (current.phase != RoundPhase.ROUND_REVEAL || current.isComplete) return

        val next = DraftEngine.advanceToNextRound(current)
        _activeDraft.value = next

        viewModelScope.launch {
            repository.saveActiveDraft(next)
            if (next.isComplete && savedCompletedDraftIds.add(next.draftId)) {
                val record = buildSavedRecord(next)
                repository.saveDraftRecord(record)
            } else if (!next.isComplete) {
                (next.currentCards.map { it.character } + next.remainingPool.take(3)).forEach { ch ->
                    repository.resolveCharacterPortrait(ch)
                }
            }
        }
    }

    private fun buildSavedRecord(draft: DraftState): SavedDraftRecord {
        val report = DraftEngine.generateFinalReport(draft)
        return SavedDraftRecord(
            id = draft.draftId,
            timestampMillis = System.currentTimeMillis(),
            mode = DraftMode.LOCAL_2P,
            difficulty = draft.difficulty,
            comparisonMode = draft.comparisonMode,
            teamSize = draft.totalRounds,
            team1 = draft.team1,
            team2 = draft.team2,
            report = report,
            player1Name = draft.player1Name,
            player2Name = draft.player2Name,
            draftHistory = draft.history
        )
    }

    fun openComparisonForCompletedDraft(): SavedDraftRecord? {
        val draft = _activeDraft.value ?: return null
        if (!draft.isComplete) return null

        val record = buildSavedRecord(draft)
        _activeReportRecord.value = record
        if (savedCompletedDraftIds.add(draft.draftId)) {
            viewModelScope.launch {
                repository.saveDraftRecord(record)
            }
        }
        return record
    }

    fun openSavedReport(record: SavedDraftRecord) {
        _activeReportRecord.value = record
    }

    fun deleteSavedReport(id: String) {
        viewModelScope.launch {
            repository.deleteDraftRecord(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllDrafts()
        }
    }

    fun updateDuelFighterA(character: Character) {
        _duelLab.update { state ->
            state.copy(
                fighterA = character,
                analysis = DraftEngine.analyzeIndividualMatchup(character, state.fighterB, state.comparisonMode)
            )
        }
    }

    fun updateDuelFighterB(character: Character) {
        _duelLab.update { state ->
            state.copy(
                fighterB = character,
                analysis = DraftEngine.analyzeIndividualMatchup(state.fighterA, character, state.comparisonMode)
            )
        }
    }

    fun updateDuelComparisonMode(mode: ComparisonMode) {
        _duelLab.update { state ->
            state.copy(
                comparisonMode = mode,
                analysis = DraftEngine.analyzeIndividualMatchup(state.fighterA, state.fighterB, mode)
            )
        }
    }

    fun swapDuelFighters() {
        _duelLab.update { state ->
            val a = state.fighterB
            val b = state.fighterA
            state.copy(
                fighterA = a,
                fighterB = b,
                analysis = DraftEngine.analyzeIndividualMatchup(a, b, state.comparisonMode)
            )
        }
    }

    fun setLanguage(language: Language) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(language = language) }
        }
    }

    fun setPlayerNames(p1: String, p2: String) {
        viewModelScope.launch {
            repository.updateSettings {
                it.copy(
                    player1Name = p1.ifBlank { "Daoud" },
                    player2Name = p2.ifBlank { "Monsef" }
                )
            }
        }
    }

    fun setDefaultComparisonMode(mode: ComparisonMode) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(defaultComparisonMode = mode) }
        }
    }

    fun setDefaultTeamSize(size: Int) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(defaultTeamSize = size.coerceIn(1, 12)) }
        }
    }

    fun setDarkTheme(enabled: Boolean) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(darkTheme = enabled) }
        }
    }

    fun clearPortraitCache() {
        viewModelScope.launch {
            repository.clearPortraitCache()
        }
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val db = AppDatabase.getInstance(application)
            val repository = DraftRepository(
                savedDraftDao = db.savedDraftDao(),
                portraitCacheDao = db.portraitCacheDao(),
                activeDraftDao = db.activeDraftDao(),
                settingsDataStore = SettingsDataStore(application),
                aniListApi = AniListApiService.create(),
                jikanApi = JikanApiService.create()
            )
            return ArenaViewModel(application, repository) as T
        }
    }
}
