package com.example.data

import com.example.model.AnimeUniverse
import com.example.model.Character
import com.example.model.CharacterStats
import com.example.model.CharacterType
import com.example.model.LocalizedText
import com.example.model.PowerCategory

object ExpandedRoster {

    private fun c(
        id: String,
        en: String,
        ar: String,
        universe: AnimeUniverse,
        type: CharacterType,
        power: PowerCategory,
        tier: String,
        off: Int,
        def: Int,
        spd: Int,
        intl: Int,
        ver: Int,
        aura: Int,
        moveEn: String,
        moveAr: String,
        traitEn: String,
        traitAr: String,
        query: String = en
    ) = Character(
        id = id,
        name = LocalizedText(en, ar),
        universe = universe,
        type = type,
        powerCategory = power,
        tier = tier,
        stats = CharacterStats(off, def, spd, intl, ver, aura),
        signatureMove = LocalizedText(moveEn, moveAr),
        tacticalTrait = LocalizedText(traitEn, traitAr),
        malQuery = query
    )

    val moreCharacters: List<Character> = listOf(
        // ==================== NARUTO (+8 => 30 total) ====================
        c("sakura_haruno", "Sakura Haruno", "ساكورا هارونو", AnimeUniverse.NARUTO, CharacterType.SUPPORT, PowerCategory.PHYSICAL, "A", 86, 86, 78, 86, 83, 82, "Byakugo Cherry Blossom Impact", "ختم البياكوغو الساحق", "Katsuyu medical support & ground-shattering strength", "دعم طبي مستمر وقوة تحطيم هائلة"),
        c("kaguya_otsutsuki", "Kaguya Otsutsuki", "كاغويا أوتسوتسوكي", AnimeUniverse.NARUTO, CharacterType.ALL_ROUNDER, PowerCategory.HAX, "S+", 97, 96, 92, 85, 98, 99, "All-Killing Ash Bones", "عظام الرماد القاتلة", "Amenominaka dimension swapping & chakra progenitor", "تبديل الأبعاد وسيدة التشاكرا الأولى"),
        c("kisame_hoshigaki", "Kisame Hoshigaki", "كيسامي هوشيغاكي", AnimeUniverse.NARUTO, CharacterType.TANK, PowerCategory.ELEMENTAL, "S", 88, 91, 82, 83, 86, 89, "Super Shark Bomb", "قنبلة القرش العملاقة", "Samehada absorbs enemy chakra & fuels water domes", "ساميهادا تمتص التشاكرا وتغذي القبة المائية"),
        c("deidara", "Deidara", "ديدارا", AnimeUniverse.NARUTO, CharacterType.STRIKER, PowerCategory.ELEMENTAL, "A", 88, 74, 83, 85, 86, 84, "C4 Karura Micro-Bombs", "قنابل C4 المجهرية", "Aerial clay artillery & cellular-level explosions", "قصف طيني جوي وتفجيرات على المستوى الخلوي"),
        c("sasori", "Sasori", "ساسوري", AnimeUniverse.NARUTO, CharacterType.STRATEGIST, PowerCategory.HAX, "A", 83, 84, 81, 91, 90, 84, "Performance of a Hundred Puppets", "عرض المئة دمية", "Poisoned iron sand & relentless puppet army", "رمال حديدية مسمومة وجيش دمى لا يتوقف"),
        c("konan", "Konan", "كونان", AnimeUniverse.NARUTO, CharacterType.STRATEGIST, PowerCategory.ELEMENTAL, "A", 84, 83, 83, 90, 88, 85, "Sacred Paper Emissary", "بحر الأوراق المتفجرة", "Paper intangibility & 600-billion-tag trap", "تحول ورقي وفخاخ متفجرة متواصلة"),
        c("raikage_a", "Fourth Raikage (A)", "الرايكاغي الرابع (إي)", AnimeUniverse.NARUTO, CharacterType.STRIKER, PowerCategory.ELEMENTAL, "S", 90, 89, 95, 76, 75, 88, "Lariat Lightning Armor", "درع البرق ولارييت", "Lightning cloak boosts reflexes & crushing speed", "درع برق يضاعف السرعة وقوة الاصطدام", "A Naruto"),
        c("onoki", "Onoki", "أونوكي", AnimeUniverse.NARUTO, CharacterType.STRATEGIST, PowerCategory.ENERGY, "S", 91, 80, 79, 91, 89, 88, "Particle Style: Atomic Dismantling", "عنصر الغبار: التفكيك الذري", "Dust-style cubes disintegrate any defense", "مكعبات غبار تفكك أي درع على المستوى الذري"),

        // ==================== ONE PIECE (+8 => 30 total) ====================
        c("usopp", "Usopp", "أوسوب", AnimeUniverse.ONE_PIECE, CharacterType.SUPPORT, PowerCategory.HAX, "B", 76, 72, 79, 90, 91, 80, "Pop Green Impact Wolf", "طلقات الأعشاب القتالية", "Extreme-range sniping & tricky battlefield traps", "قنص بعيد المدى وفخاخ نباتية مخادعة"),
        c("nami", "Nami", "نامي", AnimeUniverse.ONE_PIECE, CharacterType.SUPPORT, PowerCategory.ELEMENTAL, "A", 84, 70, 78, 92, 87, 81, "Zeus Tempo Thunderstorm", "عاصفة زيوس الرعدية", "Weather control & Homie-boosted lightning strikes", "تحكم بالطقس وصواعق زيوس المدمرة"),
        c("tony_tony_chopper", "Tony Tony Chopper", "توني توني تشوبر", AnimeUniverse.ONE_PIECE, CharacterType.SUPPORT, PowerCategory.PHYSICAL, "B", 79, 84, 78, 88, 87, 78, "Monster Point Palm", "هيئة الوحش العملاق", "7 Rumble Ball forms & instant emergency triage", "تحولات متعددة وإسعاف فوري للفريق"),
        c("akainu", "Sakazuki (Akainu)", "أكاينو (ساكازوكي)", AnimeUniverse.ONE_PIECE, CharacterType.STRIKER, PowerCategory.ELEMENTAL, "S+", 96, 92, 85, 88, 86, 95, "Great Eruption: Meigo", "كلب الجحيم البركاني", "Highest-lethality magma Logia melts defenses", "صهارة بركانية تذيب أقوى الدروع", "Sakazuki"),
        c("marco", "Marco the Phoenix", "ماركو العنقاء", AnimeUniverse.ONE_PIECE, CharacterType.SUPPORT, PowerCategory.ELEMENTAL, "S", 85, 95, 90, 88, 90, 89, "Bluebird Phoenix Flames", "لهب العنقاء الأزرق", "Blue flames regenerate self & heal teammates", "نيران زرقاء تعالج الجراح فوراً"),
        c("ben_beckman", "Benn Beckman", "بين بيكمان", AnimeUniverse.ONE_PIECE, CharacterType.STRATEGIST, PowerCategory.PHYSICAL, "S", 90, 86, 89, 96, 88, 91, "Haki-Infused Flintlock", "رصاص الهاكي التكتيكي", "Highest-IQ tactician pins Admirals with Haki rounds", "ذكاء ميداني فائق وطلقات مشبعة بالهاكي"),
        c("enel", "Enel", "إينيل", AnimeUniverse.ONE_PIECE, CharacterType.STRIKER, PowerCategory.ELEMENTAL, "S", 91, 80, 96, 83, 86, 89, "200 Million Volts: Amaru", "200 مليون فولت: أمارو", "Mantra radar + city-wide lightning strikes", "مانترا واسعة وصواعق تضرب الساحة كاملة"),
        c("silvers_rayleigh", "Silvers Rayleigh", "سيلفرز رايلي", AnimeUniverse.ONE_PIECE, CharacterType.ALL_ROUNDER, PowerCategory.PHYSICAL, "S+", 92, 89, 91, 93, 91, 95, "Internal Destruction Haki", "هاكي التدمير الداخلي", "Dark King mastery of all three Haki types", "سيد أنواع الهاكي الثلاثة بمهارة أسطورية"),

        // ==================== HUNTER X HUNTER (+8 => 30 total) ====================
        c("uvogin", "Uvogin", "أوفوغين", AnimeUniverse.HUNTER_X_HUNTER, CharacterType.TANK, PowerCategory.PHYSICAL, "S", 93, 94, 80, 72, 74, 88, "Big Bang Impact", "ضربة الانفجار العظيم", "Missile-proof body & crater-carving Enhancer punch", "جسد مقاوم للرصاص ولكمة تعادل صاروخاً"),
        c("phinks_magcub", "Phinks Magcub", "فينكس ماغكاب", AnimeUniverse.HUNTER_X_HUNTER, CharacterType.STRIKER, PowerCategory.PHYSICAL, "A", 89, 85, 86, 80, 77, 84, "Ripper Cyclotron", "دوامة الذراع المدمرة", "Each arm rotation multiplies punch power steeply", "كل لفة للذراع تضاعف قوة اللكمة"),
        c("shizuku_murasaki", "Shizuku Murasaki", "شيزوكو موراساكي", AnimeUniverse.HUNTER_X_HUNTER, CharacterType.SUPPORT, PowerCategory.HAX, "B", 77, 74, 82, 76, 86, 78, "Blinky Vacuum Drain", "بلينكي (الامتصاص)", "Removes poison, blood & debris cleanly mid-fight", "يمتص السموم والعوائق من الساحة"),
        c("knuckle_bine", "Knuckle Bine", "ناكل باين", AnimeUniverse.HUNTER_X_HUNTER, CharacterType.TANK, PowerCategory.HAX, "A", 83, 87, 86, 85, 88, 83, "Hakoware: Bankruptcy Chapter 7", "هاكواري: إفلاس النين", "Compounding aura debt forces Zetsu shutdown", "تراكم دين الطاقة يفرض إغلاق النين بالكامل"),
        c("shoot_mcmahon", "Shoot McMahon", "شوت ماكماهون", AnimeUniverse.HUNTER_X_HUNTER, CharacterType.STRATEGIST, PowerCategory.HAX, "A", 81, 82, 88, 86, 87, 81, "Hotel Rafflesia", "فندق رافليسيا", "Levitating hands seal captured body parts away", "أيدٍ طائرة تحتجز أجزاء الخصم داخل قفص"),
        c("alluka_zoldyck", "Alluka Zoldyck (Nanika)", "ألوكا زولديك (نانيكا)", AnimeUniverse.HUNTER_X_HUNTER, CharacterType.SUPPORT, PowerCategory.HAX, "S+", 60, 70, 70, 78, 99, 97, "Wish Granting Reality", "تحقيق الأمنية المطلق", "Infinite reality-level healing & teleportation", "قوة أمنيات مطلقة للشفاء والنقل الفوري", "Alluka Zoldyck"),
        c("pakunoda", "Pakunoda", "باكونودا", AnimeUniverse.HUNTER_X_HUNTER, CharacterType.SUPPORT, PowerCategory.SPIRITUAL, "B", 73, 75, 79, 91, 88, 79, "Memory Bomb", "رصاصات الذاكرة", "Extracts intel & shares enemy tactics with allies", "تستخرج الأسرار وتنقل تكتيك الخصم للحلفاء"),
        c("kastro", "Kastro", "كاسترو", AnimeUniverse.HUNTER_X_HUNTER, CharacterType.ASSASSIN, PowerCategory.PHYSICAL, "B", 83, 76, 86, 79, 82, 80, "Tiger Bite Fist & Double", "قبضة النمر والنسخة", "Conjured double creates flanking blindside attacks", "نسخة جسدية تهاجم من الزوايا العمياء"),

        // ==================== DEMON SLAYER (+8 => 30 total) ====================
        c("kanae_kocho", "Kanae Kocho", "كاناي كوتشو", AnimeUniverse.DEMON_SLAYER, CharacterType.ALL_ROUNDER, PowerCategory.ELEMENTAL, "S", 88, 84, 91, 88, 86, 89, "Flower Breathing: Equinoctial", "تنفس الزهرة: الاعتدال", "Graceful Flower Hashira slashes fend off Upper Moons", "براعة هاشيرا الزهرة في صد أقوى الشياطين"),
        c("gyutaro", "Gyutaro", "غيوتارو", AnimeUniverse.DEMON_SLAYER, CharacterType.ASSASSIN, PowerCategory.HAX, "S", 90, 86, 92, 83, 85, 88, "Flying Blood Sickles", "مناجل الدم الطائرة", "Lethal poison blood blades & shared survival core", "مناجل دم مسمومة وبقاء مرتبط بأخته"),
        c("daki", "Daki", "داكي", AnimeUniverse.DEMON_SLAYER, CharacterType.STRATEGIST, PowerCategory.PHYSICAL, "A", 83, 84, 85, 79, 86, 83, "Obi Sash Barrage", "وابل أوشحة الأوبي", "8-layer razor obi sashes trap entire rooms", "أوشحة حادة تحاصر كامل ساحة القتال"),
        c("kaigaku", "Kaigaku", "كايغاكو", AnimeUniverse.DEMON_SLAYER, CharacterType.STRIKER, PowerCategory.ELEMENTAL, "A", 87, 82, 91, 77, 81, 85, "Demon Thunder Breathing", "تنفس الرعد الشيطاني", "Black lightning slashes inflict cracking flesh burns", "رعد أسود يمزق الدفاعات دون توقف"),
        c("urokodaki_sakonji", "Sakonji Urokodaki", "ساكونجي أوروكوداكي", AnimeUniverse.DEMON_SLAYER, CharacterType.STRATEGIST, PowerCategory.ELEMENTAL, "A", 82, 85, 83, 91, 85, 84, "Water Breathing: Whirlpool", "تنفس الماء: الدوامة", "Master trainer senses emotions & sets deadly traps", "معلم تنفس الماء وخبير الفخاخ الميدانية"),
        c("gyokko", "Gyokko", "غيوكو", AnimeUniverse.DEMON_SLAYER, CharacterType.STRATEGIST, PowerCategory.HAX, "A", 85, 83, 82, 81, 90, 84, "Killer Fish Scales", "حراشف السمك القاتلة", "Porcelain pot teleportation & water-prison traps", "تنقل عبر الجرار وسجون مائية خانقة"),
        c("nakime", "Nakime", "ناكيمي", AnimeUniverse.DEMON_SLAYER, CharacterType.SUPPORT, PowerCategory.HAX, "S", 76, 88, 84, 92, 95, 87, "Infinity Castle Biwa", "قلعة اللانهاية: البيوا", "Reshapes rooms & teleports squads with one strum", "تعيد تشكيل القلعة وتنقل الفرق بنقرة واحدة"),
        c("kagaya_ubuyashiki", "Kagaya Ubuyashiki", "كاغايا أوبوياشيكي", AnimeUniverse.DEMON_SLAYER, CharacterType.SUPPORT, PowerCategory.SPIRITUAL, "A", 65, 72, 70, 99, 92, 94, "Hashira Foresight Command", "قيادة الهاشيرا والبصيرة", "Prophetic foresight unites all Slayers flawlessly", "بصيرة استراتيجية توحد صفوف المقاتلين"),

        // ==================== BLEACH (+8 => 30 total) ====================
        c("shinji_hirako", "Shinji Hirako", "شينجي هيراكو", AnimeUniverse.BLEACH, CharacterType.STRATEGIST, PowerCategory.HAX, "S", 86, 84, 88, 92, 91, 89, "Sakanade: Inverted World", "ساكانادي: العالم المعكوس", "Reverses enemy directions, sight & ally-foe perception", "يعكس اتجاهات الخصم ورؤيته تماماً"),
        c("coyote_starrk", "Coyote Starrk", "كويوتي ستارك", AnimeUniverse.BLEACH, CharacterType.STRIKER, PowerCategory.ENERGY, "S+", 92, 85, 92, 90, 88, 93, "Cero Metralleta & Wolves", "سيرو الرشاش والذئاب", "Primera Espada fires infinite rapid Cero volleys", "الإسبادا الأول يطلق وابلاً لا ينتهي من السيرو"),
        c("barragan_louisenbairn", "Barragan Louisenbairn", "باراغان لويزنبيرن", AnimeUniverse.BLEACH, CharacterType.TANK, PowerCategory.HAX, "S+", 91, 93, 81, 87, 88, 93, "Respira: Time Decay", "ريسبيرا: تآكل الزمن", "Age-rot aura disintegrates attacks before contact", "هالة شيخوخة تفتت كل هجوم قبل وصوله"),
        c("tier_harribel", "Tier Harribel", "تير هاريبيل", AnimeUniverse.BLEACH, CharacterType.ALL_ROUNDER, PowerCategory.ELEMENTAL, "S", 89, 87, 89, 86, 86, 89, "Cascada & La Gota", "تسونامي كاسكادا", "Tidal water blasts overwhelm agile rushers", "موجات مائية جارفة تحاصر المهاجمين"),
        c("isshin_kurosaki", "Isshin Kurosaki", "إيشين كوروساكي", AnimeUniverse.BLEACH, CharacterType.ALL_ROUNDER, PowerCategory.SPIRITUAL, "S", 90, 88, 89, 87, 86, 91, "Engetsu: Final Getsuga", "إنغيتسو: غيتسوغا اللهب", "Former Captain blends blazing reiatsu & street grit", "قائد سابق يمزج النار والضغط الروحي"),
        c("sajin_komamura", "Sajin Komamura", "ساجين كومامورا", AnimeUniverse.BLEACH, CharacterType.TANK, PowerCategory.PHYSICAL, "S", 90, 94, 79, 82, 78, 88, "Dangai Joe: Immortal Giant", "بانكاي العملاق الخالد", "Humanization grants invincible giant samurai armor", "هيئة عملاق لا يُقهر بضربات ساحقة"),
        c("ikkaku_madarame", "Ikkaku Madarame", "إيكاكو مادارامي", AnimeUniverse.BLEACH, CharacterType.STRIKER, PowerCategory.PHYSICAL, "A", 86, 81, 85, 76, 78, 84, "Ryumon Hozukimaru", "بانكاي ريومون هوزوكيمارو", "Bankai dragon crest charges up with every clash", "بانكاي يزداد فتكاً مع تصاعد الاشتباك"),
        c("shuhei_hisagi", "Shuhei Hisagi", "شوهي هيساغي", AnimeUniverse.BLEACH, CharacterType.TANK, PowerCategory.HAX, "S", 84, 92, 86, 86, 87, 87, "Fushi no Kojo", "بانكاي سلاسل الخلود", "Chains drain both fighters equally to force stalemates", "سلاسل تربط الخصمين وتمنع السقوط"),

        // ==================== DRAGON BALL (+8 => 30 total) ====================
        c("android_18", "Android 18", "أندرويد 18", AnimeUniverse.DRAGON_BALL, CharacterType.ALL_ROUNDER, PowerCategory.ENERGY, "S", 88, 87, 89, 86, 86, 86, "Infinity Bullet & Accel", "طاقة لانهائية وهجوم متسارع", "Endless stamina & crisp ki combos outlast foes", "طاقة لا تنفد وهجمات متواصلة"),
        c("zamasu", "Fused Zamasu", "زاماسو المندمج", AnimeUniverse.DRAGON_BALL, CharacterType.ALL_ROUNDER, PowerCategory.HAX, "S+", 95, 95, 93, 89, 94, 96, "Holy Wrath & Immortality", "الغضب المقدس والخلود", "Immortal divine regeneration & halo energy blades", "خلود إلهي متجدد وأنصال طاقة مقدسة"),
        c("cooler", "Cooler", "كولر", AnimeUniverse.DRAGON_BALL, CharacterType.STRIKER, PowerCategory.ENERGY, "S", 92, 88, 90, 86, 84, 90, "Supernova Fifth Form", "سوبرنوفا الشكل الخامس", "Armored 5th Form bursts through ki beams head-on", "الشكل الخامس المدرع يخترق الأشعة مباشرة"),
        c("janemba", "Super Janemba", "سوبر جانيمبا", AnimeUniverse.DRAGON_BALL, CharacterType.ASSASSIN, PowerCategory.HAX, "S+", 94, 88, 95, 76, 94, 93, "Dimension Sword Slash", "سيف الأبعاد القاطع", "Bunkai pixel teleportation & space-slicing sword", "انتقال مكاني وسيف يقطع الأبعاد"),
        c("toppo", "Toppo (God of Destruction)", "توبو (إله الدمار)", AnimeUniverse.DRAGON_BALL, CharacterType.TANK, PowerCategory.HAX, "S+", 95, 96, 89, 84, 88, 96, "Hakai Sphere Shield", "درع كرة التدمير هاكاي", "Destruction energy cloak vaporizes incoming blasts", "درع التدمير يمحو الهجمات قبل ملامسته"),
        c("dabura", "Dabura", "دابورا", AnimeUniverse.DRAGON_BALL, CharacterType.STRATEGIST, PowerCategory.HAX, "A", 86, 83, 85, 86, 89, 85, "Stone Spit & Demon Flame", "بصاق التحجير ونار الشيطان", "Demon King petrifies guards & summons dark blades", "ملك الشياطين يحجّر الدفاعات بضربة مفاجئة"),
        c("caulifla", "Caulifla", "كوليفلا", AnimeUniverse.DRAGON_BALL, CharacterType.STRIKER, PowerCategory.ENERGY, "S", 90, 83, 91, 79, 85, 88, "Crush Cannon SSJ2", "مدفع السحق SSJ2", "Prodigy Saiyan adapts mid-fight & pressures relentlessly", "عبقرية سايان تتكيف بسرعة وسط القتال"),
        c("yamcha", "Yamcha", "يامشا", AnimeUniverse.DRAGON_BALL, CharacterType.ASSASSIN, PowerCategory.PHYSICAL, "B", 76, 72, 82, 79, 78, 76, "Wolf Fang Fist & Spirit Ball", "قبضة ناب الذئب وكرة الروح", "Guided Spirit Ball curves around shields", "كرة روح موجهة تلتف حول الدفاعات"),

        // ==================== JUJUTSU KAISEN (+8 => 30 total) ====================
        c("hiromi_higuruma", "Hiromi Higuruma", "هيرومي هيغوروما", AnimeUniverse.JUJUTSU_KAISEN, CharacterType.STRATEGIST, PowerCategory.HAX, "S", 88, 84, 85, 95, 91, 89, "Deadly Sentencing: Executioner", "المحاكمة القاتلة: سيف الجلاد", "Confiscates enemy abilities & wields one-hit sword", "يصادر قدرات الخصم بسيف حاسم من ضربة"),
        c("hanami", "Hanami", "هانامي", AnimeUniverse.JUJUTSU_KAISEN, CharacterType.TANK, PowerCategory.ELEMENTAL, "S", 85, 93, 81, 84, 88, 87, "Cursed Buds & Solar Beam", "البراعم الملعونة والشعاع", "Root armor & energy-draining cursed seeds", "درع جذور وبذور تمتص طاقة الخصم"),
        c("dagon", "Dagon", "داغون", AnimeUniverse.JUJUTSU_KAISEN, CharacterType.TANK, PowerCategory.ELEMENTAL, "S", 86, 90, 82, 81, 86, 87, "Horizon of the Captivating Skandha", "مجال المحيط: شيكيجامي لا نهائي", "Endless shikigami swarms & huge cursed HP pool", "سرب شيكيجامي متواصل وقدرة تحمل عالية"),
        c("naobito_zenin", "Naobito Zenin", "ناوبيتو زينين", AnimeUniverse.JUJUTSU_KAISEN, CharacterType.ASSASSIN, PowerCategory.PHYSICAL, "S", 86, 80, 96, 87, 83, 86, "Projection Sorcery (24 FPS)", "سحر الإسقاط (24 إطاراً)", "24-frame blitz freezes foes inside animation panels", "سرعة 24 إطاراً تجمد الخصم في إطار زمني"),
        c("kokichi_muta", "Mechamaru (Kokichi Muta)", "ميكامارو (كوكيتشي موتا)", AnimeUniverse.JUJUTSU_KAISEN, CharacterType.STRATEGIST, PowerCategory.ENERGY, "A", 88, 86, 78, 91, 90, 86, "Ultimate Mechamaru: Pigeon Viola", "ميكامارو الأقصى: مدفع الطاقة", "17-year cursed charge powers giant mech cannons", "مدافع آلية ضخمة مشحونة لسنوات"),
        c("atsuya_kusakabe", "Atsuya Kusakabe", "أتسويا كوساكابي", AnimeUniverse.JUJUTSU_KAISEN, CharacterType.TANK, PowerCategory.PHYSICAL, "A", 83, 91, 86, 91, 85, 84, "New Shadow Style: Simple Domain", "أسلوب الظل الجديد: المجال البسيط", "Auto-parries slashes & weakens Domain sure-hits", "صد تلقائي للضربات وإبطال تأكيد المجالات"),
        c("takako_uro", "Takako Uro", "تاكاكو أورو", AnimeUniverse.JUJUTSU_KAISEN, CharacterType.ASSASSIN, PowerCategory.HAX, "S", 88, 85, 90, 86, 90, 88, "Sky Manipulation: Thin Ice Breaker", "التلاعب بالسماء: كاسر الجليد", "Bends space like cloth to deflect & shatter guards", "تثني الفضاء لصد الهجمات وتحطيم الدروع"),
        c("kasumi_miwa", "Kasumi Miwa", "كاسومي ميوا", AnimeUniverse.JUJUTSU_KAISEN, CharacterType.SUPPORT, PowerCategory.PHYSICAL, "B", 74, 76, 81, 79, 78, 76, "Batto Sword Drawing", "سحب السيف السريع", "Simple Domain reactive draw catches careless flankers", "رد فعل سريع داخل المجال البسيط"),

        // ==================== ATTACK ON TITAN (+8 => 30 total) ====================
        c("grisha_yeager", "Grisha Yeager", "غريشا ييغر", AnimeUniverse.ATTACK_ON_TITAN, CharacterType.ALL_ROUNDER, PowerCategory.SPIRITUAL, "A", 86, 86, 78, 89, 85, 88, "Attack & Founding Surge", "اندفاع العملاق المهاجم", "Future-memory instincts & double-titan resilience", "بصيرة الذكريات المستقبلية وصلابة عملاقين"),
        c("eren_kruger", "Eren Kruger (The Owl)", "إيرين كروغر (البومة)", AnimeUniverse.ATTACK_ON_TITAN, CharacterType.ASSASSIN, PowerCategory.PHYSICAL, "S", 88, 87, 83, 92, 86, 90, "Attack Titan Piercing Strike", "ضربة العملاق المهاجم الخفية", "Decades of covert mastery & ruthless titan strength", "خبرة تجسس عميقة وقوة عملاق ضاربة"),
        c("lara_tybur", "Lara Tybur", "لارا تايبر", AnimeUniverse.ATTACK_ON_TITAN, CharacterType.STRATEGIST, PowerCategory.PHYSICAL, "S", 90, 91, 80, 85, 91, 88, "War Hammer Crystal Arsenal", "ترسانة عملاق المطرقة", "Remote underground crystal tether & giant spiked warhammer", "مطرقة بلورية وتحكم عن بُعد من تحت الأرض"),
        c("mike_zacharias", "Mike Zacharias", "مايك زاكارياس", AnimeUniverse.ATTACK_ON_TITAN, CharacterType.STRIKER, PowerCategory.PHYSICAL, "A", 87, 82, 89, 84, 82, 85, "Humanity's Second Blade", "ثاني أقوى مقاتل في الفيلق", "Keen titan-scent radar & lethal dual-blade precision", "حاسة شم خارقة ودقة مزدوجة بالشفرات"),
        c("dot_pixis", "Dot Pixis", "دوت بيكسيس", AnimeUniverse.ATTACK_ON_TITAN, CharacterType.SUPPORT, PowerCategory.PHYSICAL, "B", 68, 76, 70, 95, 86, 84, "Trost Garrison Strategy", "خطة استعادة تروست", "Unflinching command optimizes siege defenses", "قيادة حاسمة تنظم الدفاعات تحت الحصار"),
        c("keith_shadis", "Keith Shadis", "كيث شاديس", AnimeUniverse.ATTACK_ON_TITAN, CharacterType.TANK, PowerCategory.PHYSICAL, "B", 78, 82, 81, 86, 80, 82, "Cadet Vanguard Drill", "مناورة المدرب القتالية", "Veteran Survey Corps commander shields rookies", "خبرة قائد استطلاع تحمي الخطوط الأمامية"),
        c("petra_ral", "Petra Ral", "بيترا رال", AnimeUniverse.ATTACK_ON_TITAN, CharacterType.ASSASSIN, PowerCategory.PHYSICAL, "A", 82, 77, 90, 83, 81, 81, "Levi Squad Synchronized Slash", "ضربة فرقة ليفاي المتزامنة", "Elite forest-maneuver precision & squad coordination", "تنسيق احترافي وهجمات جوية متزامنة"),
        c("hannes", "Hannes", "هانيس", AnimeUniverse.ATTACK_ON_TITAN, CharacterType.ALL_ROUNDER, PowerCategory.PHYSICAL, "B", 77, 79, 82, 76, 77, 80, "Garrison Rescue Charge", "اندفاع الإنقاذ الشجاع", "Fearless frontline intercept defends teammates", "تدخل شجاع لحماية الرفاق في الأزمات"),

        // ==================== SOLO LEVELING (+8 => 30 total) ====================
        c("woo_jinchul", "Woo Jinchul", "وو جينتشول", AnimeUniverse.SOLO_LEVELING, CharacterType.ALL_ROUNDER, PowerCategory.PHYSICAL, "A", 84, 85, 86, 90, 84, 85, "Association Chief Counter", "رد فعل رئيس الجمعية", "Top A-Rank discipline & calm tactical interception", "انضباط قتالي عالٍ وتدخل تكتيكي متزن"),
        c("kang_taeshik", "Kang Taeshik", "كانغ تايشيك", AnimeUniverse.SOLO_LEVELING, CharacterType.ASSASSIN, PowerCategory.HAX, "A", 85, 73, 91, 83, 82, 81, "Stealth Dagger Ambush", "كمين الخنجر الخفي", "Invisibility cloak & bleeding critical strikes", "اختفاء كامل وضربات نزيف خاطفة"),
        c("iron_shadow", "Shadow Iron", "آيرون (ظل)", AnimeUniverse.SOLO_LEVELING, CharacterType.TANK, PowerCategory.PHYSICAL, "A", 83, 95, 76, 68, 76, 84, "Taunt Roar & Greatshield", "زئير الاستفزاز والدرع العظيم", "Taunts enemy carries & absorbs heavy damage", "يجبر الخصوم على استهدافه بدرع ضخم", "Kim Chul"),
        c("greed_shadow", "Shadow Greed", "غريد (ظل)", AnimeUniverse.SOLO_LEVELING, CharacterType.STRIKER, PowerCategory.SPIRITUAL, "S", 90, 87, 87, 76, 82, 88, "Shadow S-Rank Rampage", "هيجان ظل الرتبة S", "General-grade shadow brute overwhelms mid-lines", "ظل برتبة جنرال يسحق الخطوط الوسطى", "Hwang Dongsoo"),
        c("min_byung_gyu", "Min Byung-Gyu", "مين بيونغ غيو", AnimeUniverse.SOLO_LEVELING, CharacterType.SUPPORT, PowerCategory.SPIRITUAL, "S", 70, 84, 82, 91, 93, 88, "S-Rank Sanctuary Heal", "علاج ملاذ الرتبة S", "Camouflage + instant S-Rank full-team restoration", "تمويه وعلاج فوري كامل للفريق"),
        c("park_heejin", "Park Heejin", "بارك هيجين", AnimeUniverse.SOLO_LEVELING, CharacterType.SUPPORT, PowerCategory.ELEMENTAL, "B", 77, 76, 80, 84, 83, 78, "Barrier & Wind Slash", "الحاجز وضربة الرياح", "Red Gate veteran mage stabilizes fragile squads", "ساحرة مخضرمة توفر دعماً وحواجز ثابتة"),
        c("lee_joohee", "Lee Joohee", "لي جوهي", AnimeUniverse.SOLO_LEVELING, CharacterType.SUPPORT, PowerCategory.SPIRITUAL, "B", 65, 78, 75, 83, 84, 79, "B-Rank Double-Dungeon Heal", "علاج الزنزانة المزدوجة", "Steady aura restoration keeps tanks standing", "استعادة طاقة مستمرة تحافظ على صمود المدافعين"),
        c("kanae_tawata", "Kanae Tawata", "كاناي تاواتا", AnimeUniverse.SOLO_LEVELING, CharacterType.ASSASSIN, PowerCategory.PHYSICAL, "A", 86, 78, 92, 82, 81, 83, "Twin-Katana Raid Blitz", "ومضة السيفين اليابانية", "Draw-Sword Club S-Rank agile slash barrages", "سرعة قتالية فائقة بسيفي الكاتانا")
    )
}
