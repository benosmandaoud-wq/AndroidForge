package com.example

import com.example.engine.DraftEngine
import com.example.model.AnimeUniverse
import com.example.model.ComparisonMode
import com.example.model.PlayerKey
import com.example.model.PowerCategory
import com.example.model.RoundPhase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class DraftEngineTest {

    @Test
    fun ruleA_and_ruleB_workWithAlternatingStartersAndNoDuplicates() {
        var state = DraftEngine.createInitialDraft(
            player1Name = "Daoud",
            player2Name = "Monsef",
            selectedUniverses = AnimeUniverse.entries,
            totalRounds = 5,
            comparisonMode = ComparisonMode.BALANCED,
            random = Random(42)
        )

        // Round 1: Daoud starts, 3 cards (1 visible, 2 hidden)
        assertEquals(1, state.currentRound)
        assertEquals(PlayerKey.PLAYER_1, state.startingPlayer)
        assertEquals(PlayerKey.PLAYER_1, state.activePlayer)
        assertEquals(RoundPhase.PICK_INITIAL, state.phase)
        assertEquals(3, state.currentCards.size)
        assertEquals(1, state.currentCards.count { it.isVisibleInitial && it.isRevealed })
        assertEquals(2, state.currentCards.count { !it.isVisibleInitial && !it.isRevealed })

        // RULE A: Daoud picks visible card (slot 0)
        val r1Visible = state.currentCards[0].character
        val r1Hidden1 = state.currentCards[1].character
        val r1Hidden2 = state.currentCards[2].character

        state = DraftEngine.selectDraftCard(state, 0)
        assertEquals(PlayerKey.PLAYER_2, state.activePlayer)
        assertEquals(RoundPhase.OPPONENT_PICK_HIDDEN, state.phase)
        // Hidden cards must stay hidden until opponent selects!
        assertFalse(state.currentCards[1].isRevealed)
        assertFalse(state.currentCards[2].isRevealed)

        // Trying to re-select visible card during OPPONENT_PICK_HIDDEN is blocked
        val unchanged = DraftEngine.selectDraftCard(state, 0)
        assertEquals(state, unchanged)

        // Monsef picks hidden slot 1
        state = DraftEngine.selectDraftCard(state, 1)
        assertEquals(RoundPhase.ROUND_REVEAL, state.phase)
        assertTrue(state.currentCards.all { it.isRevealed })
        assertEquals(listOf(r1Visible), state.team1)
        assertEquals(listOf(r1Hidden1), state.team2)
        assertTrue(state.currentCards[2].isDiscarded)
        assertEquals(1, state.history.size)
        assertEquals(r1Hidden2, state.history[0].discardedCharacter)
        assertEquals("RULE_A", state.history[0].ruleApplied)

        // Advance to Round 2 -> Monsef must start
        state = DraftEngine.advanceToNextRound(state)
        assertEquals(2, state.currentRound)
        assertEquals(PlayerKey.PLAYER_2, state.startingPlayer)
        assertEquals(PlayerKey.PLAYER_2, state.activePlayer)
        assertEquals(RoundPhase.PICK_INITIAL, state.phase)

        // RULE B: Monsef picks hidden slot 2 -> Daoud automatically gets visible slot 0
        val r2Visible = state.currentCards[0].character
        val r2Hidden1 = state.currentCards[1].character
        val r2Hidden2 = state.currentCards[2].character

        state = DraftEngine.selectDraftCard(state, 2)
        assertEquals(RoundPhase.ROUND_REVEAL, state.phase)
        assertTrue(state.currentCards.all { it.isRevealed })
        assertEquals(2, state.team1.size)
        assertEquals(2, state.team2.size)
        assertEquals(r2Visible, state.team1[1])
        assertEquals(r2Hidden2, state.team2[1])
        assertEquals(r2Hidden1, state.history[1].discardedCharacter)
        assertEquals("RULE_B", state.history[1].ruleApplied)
    }

    @Test
    fun fullTenRoundDraftHasZeroDuplicateCharactersAndGeneratesComparisonReport() {
        var state = DraftEngine.createInitialDraft(
            player1Name = "Daoud",
            player2Name = "Monsef",
            selectedUniverses = AnimeUniverse.entries,
            totalRounds = 10,
            comparisonMode = ComparisonMode.TACTICAL_SYNERGY,
            random = Random(99)
        )

        for (round in 1..10) {
            val expectedStarter = if (round % 2 == 1) PlayerKey.PLAYER_1 else PlayerKey.PLAYER_2
            assertEquals(expectedStarter, state.startingPlayer)
            assertEquals(expectedStarter, state.activePlayer)

            if (round % 2 == 1) {
                state = DraftEngine.selectDraftCard(state, 0) // Rule A visible
                state = DraftEngine.selectDraftCard(state, 1) // Opponent picks hidden
            } else {
                state = DraftEngine.selectDraftCard(state, 2) // Rule B hidden
            }
            assertEquals(RoundPhase.ROUND_REVEAL, state.phase)
            state = DraftEngine.advanceToNextRound(state)
        }

        assertTrue(state.isComplete)
        assertEquals(10, state.team1.size)
        assertEquals(10, state.team2.size)
        assertEquals(10, state.history.size)

        val allIds = (state.team1 + state.team2 + state.history.map { it.discardedCharacter }).map { it.id }
        assertEquals(30, allIds.size)
        assertEquals(30, allIds.distinct().size)

        val report = DraftEngine.generateFinalReport(state)
        assertEquals(10, report.matchups.size)
        assertTrue(report.p1TotalScore > 0)
        assertTrue(report.p2TotalScore > 0)
    }

    @Test
    fun singleAnimeDraftSupportsUpToTenRoundsWithoutTeamDuplicates() {
        var state = DraftEngine.createInitialDraft(
            player1Name = "Daoud",
            player2Name = "Monsef",
            selectedUniverses = listOf(AnimeUniverse.NARUTO),
            totalRounds = 10,
            comparisonMode = ComparisonMode.BALANCED,
            random = Random(7)
        )

        for (round in 1..10) {
            state = DraftEngine.selectDraftCard(state, 0)
            state = DraftEngine.selectDraftCard(state, 1)
            state = DraftEngine.advanceToNextRound(state, Random(round))
        }

        assertTrue(state.isComplete)
        assertEquals(10, state.team1.size)
        assertEquals(10, state.team2.size)
        assertTrue(state.team1.all { it.universe == AnimeUniverse.NARUTO })
        assertTrue(state.team2.all { it.universe == AnimeUniverse.NARUTO })
        val allTeamIds = (state.team1 + state.team2).map { it.id }
        assertEquals(20, allTeamIds.distinct().size)
    }

    @Test
    fun powerCategoryCycleRemainsConsistent() {
        assertTrue(DraftEngine.hasCategoryAdvantage(PowerCategory.PHYSICAL, PowerCategory.ENERGY))
        assertTrue(DraftEngine.hasCategoryAdvantage(PowerCategory.ENERGY, PowerCategory.ELEMENTAL))
        assertTrue(DraftEngine.hasCategoryAdvantage(PowerCategory.ELEMENTAL, PowerCategory.SPIRITUAL))
        assertTrue(DraftEngine.hasCategoryAdvantage(PowerCategory.SPIRITUAL, PowerCategory.HAX))
        assertTrue(DraftEngine.hasCategoryAdvantage(PowerCategory.HAX, PowerCategory.PHYSICAL))
        assertFalse(DraftEngine.hasCategoryAdvantage(PowerCategory.PHYSICAL, PowerCategory.PHYSICAL))
    }

    @Test
    fun rosterHasThirtyUniqueCharactersPerUniverse() {
        val all = com.example.data.CharacterRoster.allCharacters
        assertEquals(270, all.size)
        assertEquals(270, all.map { it.id }.distinct().size)
        AnimeUniverse.entries.forEach { uni ->
            assertEquals(30, all.count { it.universe == uni })
        }
    }

    @Test
    fun winPercentageSumsToHundredAndFavorsWinner() {
        val (p1Win, p2Win) = DraftEngine.computeWinPercentages(
            p1Total = 640,
            p2Total = 580,
            p1DuelWins = 4,
            p2DuelWins = 1
        )
        assertEquals(100, p1Win + p2Win)
        assertTrue(p1Win > 50)

        val (tie1, tie2) = DraftEngine.computeWinPercentages(
            p1Total = 600,
            p2Total = 600,
            p1DuelWins = 2,
            p2DuelWins = 2
        )
        assertEquals(50, tie1)
        assertEquals(50, tie2)
    }
}
